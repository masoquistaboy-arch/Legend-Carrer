import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as ArrowLeftRight, _ as ChevronRight, a as Shirt, b as Briefcase, c as Plane, d as MapPin, f as House, g as DoorOpen, h as Dumbbell, i as Sparkles, l as Newspaper, m as FastForward, n as Trophy, o as RotateCcw, p as Hash, s as Play, t as UserRound, u as Megaphone, v as ChevronLeft, x as Banknote, y as Camera } from "../_libs/lucide-react.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BofK3ae-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors duration-(--motion-quick) ease-(--ease-out) focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/70 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-gold text-gold-fg hover:bg-gold/90",
			pitch: "bg-pitch text-pitch-fg hover:bg-pitch/90",
			outline: "border border-border bg-transparent text-fg hover:bg-surface-2",
			ghost: "text-fg hover:bg-surface-2",
			danger: "bg-danger text-fg hover:bg-danger/90"
		},
		size: {
			default: "h-11 min-h-11 px-4",
			sm: "h-9 min-h-9 px-3 text-xs",
			lg: "h-12 min-h-12 px-5 text-base",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-md border border-border bg-surface px-3 text-sm text-fg placeholder:text-muted/70", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/70", className),
		...props
	});
}
var NATIONS = [
	{
		id: "bra",
		name: "Brasil",
		code: "BRA"
	},
	{
		id: "arg",
		name: "Argentina",
		code: "ARG"
	},
	{
		id: "por",
		name: "Portugal",
		code: "POR"
	},
	{
		id: "uru",
		name: "Uruguai",
		code: "URU"
	},
	{
		id: "fra",
		name: "Franca",
		code: "FRA"
	},
	{
		id: "esp",
		name: "Espanha",
		code: "ESP"
	},
	{
		id: "eng",
		name: "Inglaterra",
		code: "ENG"
	},
	{
		id: "ger",
		name: "Alemanha",
		code: "GER"
	},
	{
		id: "ita",
		name: "Italia",
		code: "ITA"
	},
	{
		id: "ned",
		name: "Holanda",
		code: "NED"
	},
	{
		id: "bel",
		name: "Belgica",
		code: "BEL"
	},
	{
		id: "cro",
		name: "Croacia",
		code: "CRO"
	},
	{
		id: "nga",
		name: "Nigeria",
		code: "NGA"
	},
	{
		id: "sen",
		name: "Senegal",
		code: "SEN"
	},
	{
		id: "civ",
		name: "Costa do Marfim",
		code: "CIV"
	},
	{
		id: "mar",
		name: "Marrocos",
		code: "MAR"
	},
	{
		id: "jpn",
		name: "Japao",
		code: "JPN"
	},
	{
		id: "kor",
		name: "Coreia do Sul",
		code: "KOR"
	},
	{
		id: "col",
		name: "Colombia",
		code: "COL"
	},
	{
		id: "chi",
		name: "Chile",
		code: "CHI"
	},
	{
		id: "par",
		name: "Paraguai",
		code: "PAR"
	},
	{
		id: "ecu",
		name: "Equador",
		code: "ECU"
	},
	{
		id: "gha",
		name: "Gana",
		code: "GHA"
	},
	{
		id: "cmr",
		name: "Camaroes",
		code: "CMR"
	},
	{
		id: "usa",
		name: "Estados Unidos",
		code: "USA"
	},
	{
		id: "mex",
		name: "Mexico",
		code: "MEX"
	}
];
var POSITIONS = [
	{
		id: "ST",
		name: "Centroavante",
		line: 0,
		slot: 1
	},
	{
		id: "LW",
		name: "Ponta esquerda",
		line: 1,
		slot: 0
	},
	{
		id: "RW",
		name: "Ponta direita",
		line: 1,
		slot: 2
	},
	{
		id: "CAM",
		name: "Meia ofensivo",
		line: 2,
		slot: 1
	},
	{
		id: "LM",
		name: "Meia esquerda",
		line: 3,
		slot: 0
	},
	{
		id: "CM",
		name: "Meio-campo",
		line: 3,
		slot: 1
	},
	{
		id: "RM",
		name: "Meia direita",
		line: 3,
		slot: 2
	},
	{
		id: "CDM",
		name: "Volante",
		line: 4,
		slot: 1
	},
	{
		id: "LB",
		name: "Lateral esquerdo",
		line: 5,
		slot: 0
	},
	{
		id: "CB",
		name: "Zagueiro",
		line: 5,
		slot: 1
	},
	{
		id: "RB",
		name: "Lateral direito",
		line: 5,
		slot: 2
	},
	{
		id: "GK",
		name: "Goleiro",
		line: 6,
		slot: 1
	}
];
var ATTR_LABELS = {
	pace: {
		short: "RIT",
		long: "Ritmo"
	},
	shooting: {
		short: "FIN",
		long: "Finalizacao"
	},
	passing: {
		short: "PAS",
		long: "Passe"
	},
	dribbling: {
		short: "DRI",
		long: "Drible"
	},
	defending: {
		short: "DEF",
		long: "Defesa"
	},
	physical: {
		short: "FIS",
		long: "Fisico"
	},
	vision: {
		short: "QI",
		long: "QI de jogo"
	}
};
var ATTR_KEYS = [
	"pace",
	"shooting",
	"passing",
	"dribbling",
	"defending",
	"physical",
	"vision"
];
var POSITION_WEIGHTS = {
	ST: {
		pace: .16,
		shooting: .3,
		passing: .1,
		dribbling: .16,
		defending: .04,
		physical: .14,
		vision: .1
	},
	LW: {
		pace: .24,
		shooting: .14,
		passing: .14,
		dribbling: .24,
		defending: .04,
		physical: .08,
		vision: .12
	},
	RW: {
		pace: .24,
		shooting: .14,
		passing: .14,
		dribbling: .24,
		defending: .04,
		physical: .08,
		vision: .12
	},
	CAM: {
		pace: .1,
		shooting: .14,
		passing: .22,
		dribbling: .18,
		defending: .06,
		physical: .08,
		vision: .22
	},
	CM: {
		pace: .08,
		shooting: .1,
		passing: .24,
		dribbling: .12,
		defending: .14,
		physical: .14,
		vision: .18
	},
	CDM: {
		pace: .1,
		shooting: .06,
		passing: .18,
		dribbling: .08,
		defending: .26,
		physical: .2,
		vision: .12
	},
	LM: {
		pace: .2,
		shooting: .1,
		passing: .18,
		dribbling: .18,
		defending: .1,
		physical: .1,
		vision: .14
	},
	RM: {
		pace: .2,
		shooting: .1,
		passing: .18,
		dribbling: .18,
		defending: .1,
		physical: .1,
		vision: .14
	},
	CB: {
		pace: .12,
		shooting: .04,
		passing: .12,
		dribbling: .06,
		defending: .32,
		physical: .24,
		vision: .1
	},
	LB: {
		pace: .22,
		shooting: .06,
		passing: .16,
		dribbling: .12,
		defending: .2,
		physical: .14,
		vision: .1
	},
	RB: {
		pace: .22,
		shooting: .06,
		passing: .16,
		dribbling: .12,
		defending: .2,
		physical: .14,
		vision: .1
	},
	GK: {
		pace: .08,
		shooting: .04,
		passing: .14,
		dribbling: .08,
		defending: .3,
		physical: .16,
		vision: .2
	}
};
var PLAY_STYLES = {
	ST: [
		"Cacador",
		"Raposa da area",
		"Homem-alvo",
		"Finalizador"
	],
	LW: [
		"Pontinha",
		"Infiltrador",
		"Extremo classico"
	],
	RW: [
		"Pontinha",
		"Infiltrador",
		"Extremo classico"
	],
	CAM: [
		"Maestro",
		"Camisa 10",
		"Sombra"
	],
	CM: [
		"Box-to-box",
		"Organizador",
		"Motorzinho"
	],
	CDM: [
		"Destruidor",
		"Primeiro passe",
		"Ancora"
	],
	LM: [
		"Corredor",
		"Apoio",
		"Aberto"
	],
	RM: [
		"Corredor",
		"Apoio",
		"Aberto"
	],
	CB: [
		"Libero",
		"Brucutu",
		"Bola longa"
	],
	LB: [
		"Sobreposto",
		"Marcador",
		"Wing-back"
	],
	RB: [
		"Sobreposto",
		"Marcador",
		"Wing-back"
	],
	GK: [
		"Sweeper",
		"Classico",
		"Passador"
	]
};
var CLUBS = [
	{
		id: "fla",
		name: "Flamengo",
		shortName: "FLA",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 84,
		wageBudget: 9e4,
		colors: ["#C41E3A", "#1a1a1a"]
	},
	{
		id: "pal",
		name: "Palmeiras",
		shortName: "PAL",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 85,
		wageBudget: 85e3,
		colors: ["#006437", "#ffffff"]
	},
	{
		id: "sao",
		name: "Sao Paulo",
		shortName: "SAO",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 78,
		wageBudget: 55e3,
		colors: ["#fe0000", "#ffffff"]
	},
	{
		id: "cor",
		name: "Corinthians",
		shortName: "COR",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 77,
		wageBudget: 5e4,
		colors: ["#000000", "#ffffff"]
	},
	{
		id: "san",
		name: "Santos",
		shortName: "SAN",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 72,
		wageBudget: 28e3,
		colors: ["#ffffff", "#000000"]
	},
	{
		id: "gre",
		name: "Gremio",
		shortName: "GRE",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 76,
		wageBudget: 42e3,
		colors: ["#0d80bf", "#000000"]
	},
	{
		id: "int",
		name: "Internacional",
		shortName: "INT",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 76,
		wageBudget: 42e3,
		colors: ["#c8102e", "#ffffff"]
	},
	{
		id: "cam",
		name: "Atletico-MG",
		shortName: "CAM",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 79,
		wageBudget: 52e3,
		colors: ["#000000", "#ffffff"]
	},
	{
		id: "flu",
		name: "Fluminense",
		shortName: "FLU",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 75,
		wageBudget: 38e3,
		colors: ["#7A0019", "#006633"]
	},
	{
		id: "bot",
		name: "Botafogo",
		shortName: "BOT",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 80,
		wageBudget: 6e4,
		colors: ["#000000", "#ffffff"]
	},
	{
		id: "vas",
		name: "Vasco",
		shortName: "VAS",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 70,
		wageBudget: 22e3,
		colors: ["#000000", "#ffffff"]
	},
	{
		id: "bah",
		name: "Bahia",
		shortName: "BAH",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 73,
		wageBudget: 3e4,
		colors: ["#006cb6", "#ce0e2d"]
	},
	{
		id: "cru",
		name: "Cruzeiro",
		shortName: "CRU",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 74,
		wageBudget: 32e3,
		colors: ["#2b57a3", "#ffffff"]
	},
	{
		id: "cap",
		name: "Athletico-PR",
		shortName: "CAP",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 71,
		wageBudget: 24e3,
		colors: ["#e10600", "#000000"]
	},
	{
		id: "for",
		name: "Fortaleza",
		shortName: "FOR",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 72,
		wageBudget: 26e3,
		colors: ["#1c3c8c", "#e10600"]
	},
	{
		id: "rbb",
		name: "Bragantino",
		shortName: "RBB",
		country: "Brasil",
		countryCode: "BRA",
		league: "Brasileirao",
		reputation: 74,
		wageBudget: 34e3,
		colors: ["#ffffff", "#e10600"]
	},
	{
		id: "riv",
		name: "River Plate",
		shortName: "RIV",
		country: "Argentina",
		countryCode: "ARG",
		league: "Liga Profesional",
		reputation: 82,
		wageBudget: 45e3,
		colors: ["#ffffff", "#e10600"]
	},
	{
		id: "boc",
		name: "Boca Juniors",
		shortName: "BOC",
		country: "Argentina",
		countryCode: "ARG",
		league: "Liga Profesional",
		reputation: 81,
		wageBudget: 42e3,
		colors: ["#0033a0", "#f9be00"]
	},
	{
		id: "rma",
		name: "Real Madrid",
		shortName: "RMA",
		country: "Espanha",
		countryCode: "ESP",
		league: "La Liga",
		reputation: 97,
		wageBudget: 45e4,
		colors: ["#ffffff", "#fbbc04"]
	},
	{
		id: "bar",
		name: "Barcelona",
		shortName: "BAR",
		country: "Espanha",
		countryCode: "ESP",
		league: "La Liga",
		reputation: 95,
		wageBudget: 38e4,
		colors: ["#a50044", "#004d98"]
	},
	{
		id: "atm",
		name: "Atletico Madrid",
		shortName: "ATM",
		country: "Espanha",
		countryCode: "ESP",
		league: "La Liga",
		reputation: 90,
		wageBudget: 22e4,
		colors: ["#ce1727", "#ffffff"]
	},
	{
		id: "mci",
		name: "Manchester City",
		shortName: "MCI",
		country: "Inglaterra",
		countryCode: "ENG",
		league: "Premier League",
		reputation: 97,
		wageBudget: 48e4,
		colors: ["#6cabdd", "#1c2c5b"]
	},
	{
		id: "liv",
		name: "Liverpool",
		shortName: "LIV",
		country: "Inglaterra",
		countryCode: "ENG",
		league: "Premier League",
		reputation: 94,
		wageBudget: 36e4,
		colors: ["#c8102e", "#00b2a9"]
	},
	{
		id: "ars",
		name: "Arsenal",
		shortName: "ARS",
		country: "Inglaterra",
		countryCode: "ENG",
		league: "Premier League",
		reputation: 92,
		wageBudget: 32e4,
		colors: ["#ef0107", "#ffffff"]
	},
	{
		id: "che",
		name: "Chelsea",
		shortName: "CHE",
		country: "Inglaterra",
		countryCode: "ENG",
		league: "Premier League",
		reputation: 88,
		wageBudget: 3e5,
		colors: ["#034694", "#ffffff"]
	},
	{
		id: "mun",
		name: "Manchester United",
		shortName: "MUN",
		country: "Inglaterra",
		countryCode: "ENG",
		league: "Premier League",
		reputation: 87,
		wageBudget: 31e4,
		colors: ["#da291c", "#fbe122"]
	},
	{
		id: "tot",
		name: "Tottenham",
		shortName: "TOT",
		country: "Inglaterra",
		countryCode: "ENG",
		league: "Premier League",
		reputation: 86,
		wageBudget: 24e4,
		colors: ["#132257", "#ffffff"]
	},
	{
		id: "bay",
		name: "Bayern Munique",
		shortName: "BAY",
		country: "Alemanha",
		countryCode: "GER",
		league: "Bundesliga",
		reputation: 94,
		wageBudget: 34e4,
		colors: ["#dc052d", "#0066b2"]
	},
	{
		id: "bvb",
		name: "Borussia Dortmund",
		shortName: "BVB",
		country: "Alemanha",
		countryCode: "GER",
		league: "Bundesliga",
		reputation: 88,
		wageBudget: 18e4,
		colors: ["#fde100", "#000000"]
	},
	{
		id: "lev",
		name: "Bayer Leverkusen",
		shortName: "LEV",
		country: "Alemanha",
		countryCode: "GER",
		league: "Bundesliga",
		reputation: 86,
		wageBudget: 14e4,
		colors: ["#e32219", "#000000"]
	},
	{
		id: "psg",
		name: "Paris Saint-Germain",
		shortName: "PSG",
		country: "Franca",
		countryCode: "FRA",
		league: "Ligue 1",
		reputation: 93,
		wageBudget: 42e4,
		colors: ["#004170", "#da291c"]
	},
	{
		id: "intm",
		name: "Inter de Milao",
		shortName: "INT",
		country: "Italia",
		countryCode: "ITA",
		league: "Serie A",
		reputation: 91,
		wageBudget: 22e4,
		colors: ["#010E80", "#000000"]
	},
	{
		id: "mil",
		name: "Milan",
		shortName: "MIL",
		country: "Italia",
		countryCode: "ITA",
		league: "Serie A",
		reputation: 89,
		wageBudget: 2e5,
		colors: ["#fb090b", "#000000"]
	},
	{
		id: "juv",
		name: "Juventus",
		shortName: "JUV",
		country: "Italia",
		countryCode: "ITA",
		league: "Serie A",
		reputation: 88,
		wageBudget: 21e4,
		colors: ["#000000", "#ffffff"]
	},
	{
		id: "nap",
		name: "Napoli",
		shortName: "NAP",
		country: "Italia",
		countryCode: "ITA",
		league: "Serie A",
		reputation: 87,
		wageBudget: 16e4,
		colors: ["#12A0D7", "#ffffff"]
	},
	{
		id: "ben",
		name: "Benfica",
		shortName: "BEN",
		country: "Portugal",
		countryCode: "POR",
		league: "Liga Portugal",
		reputation: 84,
		wageBudget: 9e4,
		colors: ["#e41e26", "#ffffff"]
	},
	{
		id: "por",
		name: "Porto",
		shortName: "POR",
		country: "Portugal",
		countryCode: "POR",
		league: "Liga Portugal",
		reputation: 83,
		wageBudget: 8e4,
		colors: ["#003087", "#ffffff"]
	},
	{
		id: "scp",
		name: "Sporting",
		shortName: "SCP",
		country: "Portugal",
		countryCode: "POR",
		league: "Liga Portugal",
		reputation: 82,
		wageBudget: 75e3,
		colors: ["#008057", "#ffffff"]
	},
	{
		id: "aja",
		name: "Ajax",
		shortName: "AJA",
		country: "Holanda",
		countryCode: "NED",
		league: "Eredivisie",
		reputation: 82,
		wageBudget: 7e4,
		colors: ["#d2122e", "#ffffff"]
	}
];
var FILLER_OPPONENTS = {
	Brasileirao: [
		{
			name: "Cuiaba",
			rep: 64
		},
		{
			name: "Goias",
			rep: 66
		},
		{
			name: "Coritiba",
			rep: 65
		},
		{
			name: "Ceara",
			rep: 67
		},
		{
			name: "Sport",
			rep: 68
		},
		{
			name: "Vitoria",
			rep: 66
		},
		{
			name: "Juventude",
			rep: 64
		},
		{
			name: "Atletico-GO",
			rep: 65
		}
	],
	"Liga Profesional": [
		{
			name: "Racing",
			rep: 74
		},
		{
			name: "Independiente",
			rep: 73
		},
		{
			name: "San Lorenzo",
			rep: 72
		},
		{
			name: "Estudiantes",
			rep: 74
		},
		{
			name: "Velez",
			rep: 73
		}
	],
	"La Liga": [
		{
			name: "Sevilla",
			rep: 80
		},
		{
			name: "Real Sociedad",
			rep: 82
		},
		{
			name: "Villarreal",
			rep: 81
		},
		{
			name: "Athletic Bilbao",
			rep: 83
		},
		{
			name: "Getafe",
			rep: 74
		},
		{
			name: "Valencia",
			rep: 78
		},
		{
			name: "Betis",
			rep: 80
		}
	],
	"Premier League": [
		{
			name: "Newcastle",
			rep: 84
		},
		{
			name: "Aston Villa",
			rep: 84
		},
		{
			name: "Brighton",
			rep: 80
		},
		{
			name: "West Ham",
			rep: 79
		},
		{
			name: "Fulham",
			rep: 78
		},
		{
			name: "Crystal Palace",
			rep: 77
		},
		{
			name: "Wolves",
			rep: 76
		},
		{
			name: "Everton",
			rep: 76
		},
		{
			name: "Brentford",
			rep: 78
		}
	],
	Bundesliga: [
		{
			name: "RB Leipzig",
			rep: 85
		},
		{
			name: "Stuttgart",
			rep: 80
		},
		{
			name: "Frankfurt",
			rep: 81
		},
		{
			name: "Wolfsburg",
			rep: 78
		},
		{
			name: "Gladbach",
			rep: 77
		},
		{
			name: "Freiburg",
			rep: 79
		}
	],
	"Ligue 1": [
		{
			name: "Monaco",
			rep: 84
		},
		{
			name: "Marseille",
			rep: 82
		},
		{
			name: "Lyon",
			rep: 80
		},
		{
			name: "Lille",
			rep: 81
		},
		{
			name: "Nice",
			rep: 79
		},
		{
			name: "Lens",
			rep: 78
		}
	],
	"Serie A": [
		{
			name: "Roma",
			rep: 84
		},
		{
			name: "Lazio",
			rep: 82
		},
		{
			name: "Atalanta",
			rep: 85
		},
		{
			name: "Fiorentina",
			rep: 80
		},
		{
			name: "Torino",
			rep: 76
		},
		{
			name: "Bologna",
			rep: 79
		}
	],
	"Liga Portugal": [
		{
			name: "Braga",
			rep: 78
		},
		{
			name: "Vitoria Guimaraes",
			rep: 74
		},
		{
			name: "Boavista",
			rep: 70
		},
		{
			name: "Gil Vicente",
			rep: 68
		}
	],
	Eredivisie: [
		{
			name: "PSV",
			rep: 84
		},
		{
			name: "Feyenoord",
			rep: 83
		},
		{
			name: "AZ Alkmaar",
			rep: 76
		},
		{
			name: "Twente",
			rep: 74
		}
	]
};
var INJURY_TABLE = [
	{
		name: "Contusao",
		severity: "leve",
		weeks: [1, 2]
	},
	{
		name: "Estiramento",
		severity: "leve",
		weeks: [2, 3]
	},
	{
		name: "Entorse de tornozelo",
		severity: "media",
		weeks: [4, 6]
	},
	{
		name: "Lesao muscular",
		severity: "media",
		weeks: [5, 8]
	},
	{
		name: "Rompimento de ligamento",
		severity: "grave",
		weeks: [12, 24]
	},
	{
		name: "Fratura",
		severity: "grave",
		weeks: [10, 18]
	},
	{
		name: "Joelho cronico",
		severity: "cronica",
		weeks: [8, 14]
	}
];
var SPONSOR_BRANDS = [
	"Nike",
	"Adidas",
	"Puma",
	"New Balance",
	"Umbro",
	"Gatorade",
	"EA Sports"
];
function clubById(id) {
	const club = CLUBS.find((c) => c.id === id);
	if (!club) throw new Error(`Clube inexistente: ${id}`);
	return club;
}
function nationById(id) {
	const n = NATIONS.find((x) => x.id === id);
	if (!n) throw new Error(`Nacao inexistente: ${id}`);
	return n;
}
function defaultShirt(position) {
	return {
		GK: 1,
		CB: 4,
		LB: 6,
		RB: 2,
		CDM: 5,
		CM: 8,
		CAM: 10,
		LM: 11,
		RM: 7,
		LW: 11,
		RW: 7,
		ST: 9
	}[position];
}
var NATION_ISO = {
	bra: "br",
	arg: "ar",
	por: "pt",
	uru: "uy",
	fra: "fr",
	esp: "es",
	eng: "gb",
	ger: "de",
	ita: "it",
	ned: "nl",
	bel: "be",
	cro: "hr",
	nga: "ng",
	sen: "sn",
	civ: "ci",
	mar: "ma",
	jpn: "jp",
	kor: "kr",
	col: "co",
	chi: "cl",
	par: "py",
	ecu: "ec",
	gha: "gh",
	cmr: "cm",
	usa: "us",
	mex: "mx"
};
function flagUrl(nationId) {
	return `https://flagcdn.com/w80/${NATION_ISO[nationId] ?? "un"}.png`;
}
/** Transfermarkt crest IDs — real club badges. Fallback is a color shield. */
var CLUB_LOGOS = {
	fla: "https://tmssl.akamaized.net/images/wappen/head/614.png",
	pal: "https://tmssl.akamaized.net/images/wappen/head/1023.png",
	sao: "https://tmssl.akamaized.net/images/wappen/head/585.png",
	cor: "https://tmssl.akamaized.net/images/wappen/head/199.png",
	san: "https://tmssl.akamaized.net/images/wappen/head/221.png",
	gre: "https://tmssl.akamaized.net/images/wappen/head/210.png",
	int: "https://tmssl.akamaized.net/images/wappen/head/6600.png",
	cam: "https://tmssl.akamaized.net/images/wappen/head/330.png",
	flu: "https://tmssl.akamaized.net/images/wappen/head/2462.png",
	bot: "https://tmssl.akamaized.net/images/wappen/head/537.png",
	vas: "https://tmssl.akamaized.net/images/wappen/head/475.png",
	bah: "https://tmssl.akamaized.net/images/wappen/head/10010.png",
	cru: "https://tmssl.akamaized.net/images/wappen/head/609.png",
	cap: "https://tmssl.akamaized.net/images/wappen/head/679.png",
	for: "https://tmssl.akamaized.net/images/wappen/head/10870.png",
	rbb: "https://tmssl.akamaized.net/images/wappen/head/8793.png",
	riv: "https://tmssl.akamaized.net/images/wappen/head/209.png",
	boc: "https://tmssl.akamaized.net/images/wappen/head/189.png",
	rma: "https://tmssl.akamaized.net/images/wappen/head/418.png",
	bar: "https://tmssl.akamaized.net/images/wappen/head/131.png",
	atm: "https://tmssl.akamaized.net/images/wappen/head/13.png",
	mci: "https://tmssl.akamaized.net/images/wappen/head/281.png",
	liv: "https://tmssl.akamaized.net/images/wappen/head/31.png",
	ars: "https://tmssl.akamaized.net/images/wappen/head/11.png",
	che: "https://tmssl.akamaized.net/images/wappen/head/631.png",
	mun: "https://tmssl.akamaized.net/images/wappen/head/985.png",
	tot: "https://tmssl.akamaized.net/images/wappen/head/148.png",
	bay: "https://tmssl.akamaized.net/images/wappen/head/27.png",
	bvb: "https://tmssl.akamaized.net/images/wappen/head/16.png",
	lev: "https://tmssl.akamaized.net/images/wappen/head/15.png",
	psg: "https://tmssl.akamaized.net/images/wappen/head/583.png",
	intm: "https://tmssl.akamaized.net/images/wappen/head/46.png",
	mil: "https://tmssl.akamaized.net/images/wappen/head/5.png",
	juv: "https://tmssl.akamaized.net/images/wappen/head/506.png",
	nap: "https://tmssl.akamaized.net/images/wappen/head/6195.png",
	ben: "https://tmssl.akamaized.net/images/wappen/head/294.png",
	por: "https://tmssl.akamaized.net/images/wappen/head/720.png",
	scp: "https://tmssl.akamaized.net/images/wappen/head/336.png",
	aja: "https://tmssl.akamaized.net/images/wappen/head/610.png"
};
function clubLogo(id) {
	return CLUB_LOGOS[id];
}
var GATEWAY_ACADEMY = [
	"aja",
	"scp",
	"por",
	"ben",
	"rbb",
	"vas",
	"san",
	"flu"
];
function academyPool(nationId) {
	const nation = nationById(nationId);
	const home = CLUBS.filter((c) => c.countryCode === nation.code);
	if (home.length >= 2) {
		const modest = home.filter((c) => c.reputation <= 80);
		return modest.length >= 2 ? modest : home;
	}
	return GATEWAY_ACADEMY.map((id) => clubById(id));
}
var LEGENDS = [
	{
		id: "ronaldo",
		name: "Ronaldo Fenomeno",
		positions: ["ST"],
		signature: {
			pace: 94,
			shooting: 96,
			dribbling: 90
		},
		blurb: "Explosao e finalizacao",
		nation: "BRA",
		era: "90-00",
		number: 9,
		colors: ["#ffdf00", "#009c3b"],
		iconic: true
	},
	{
		id: "pele",
		name: "Pele",
		positions: ["ST", "CAM"],
		signature: {
			shooting: 93,
			passing: 88,
			dribbling: 90,
			vision: 92
		},
		blurb: "Jogo completo",
		nation: "BRA",
		era: "58-77",
		number: 10,
		colors: ["#ffdf00", "#002776"],
		iconic: true
	},
	{
		id: "romario",
		name: "Romario",
		positions: ["ST"],
		signature: {
			shooting: 95,
			dribbling: 88,
			pace: 86
		},
		blurb: "Raposa da area",
		nation: "BRA",
		era: "85-00",
		number: 11,
		colors: ["#ffdf00", "#009c3b"],
		iconic: true
	},
	{
		id: "messi",
		name: "Lionel Messi",
		positions: [
			"RW",
			"CAM",
			"ST"
		],
		signature: {
			dribbling: 97,
			passing: 93,
			vision: 96,
			shooting: 92
		},
		blurb: "Toque e visao",
		nation: "ARG",
		era: "04-22",
		number: 10,
		colors: ["#75aadb", "#ffffff"],
		iconic: true
	},
	{
		id: "cr7",
		name: "Cristiano Ronaldo",
		positions: ["ST", "LW"],
		signature: {
			shooting: 95,
			pace: 90,
			physical: 88
		},
		blurb: "Salto e chute",
		nation: "POR",
		era: "03-22",
		number: 7,
		colors: ["#006600", "#d0103a"],
		iconic: true
	},
	{
		id: "ronaldinho",
		name: "Ronaldinho",
		positions: [
			"CAM",
			"LW",
			"LM"
		],
		signature: {
			dribbling: 96,
			passing: 90,
			vision: 91
		},
		blurb: "Magia no um contra um",
		nation: "BRA",
		era: "99-11",
		number: 10,
		colors: ["#a50044", "#004d98"],
		iconic: true
	},
	{
		id: "neymar",
		name: "Neymar",
		positions: ["LW", "CAM"],
		signature: {
			dribbling: 95,
			pace: 90,
			passing: 86
		},
		blurb: "Gingado e ruptura",
		nation: "BRA",
		era: "09-22",
		number: 10,
		colors: ["#ffdf00", "#009c3b"],
		iconic: true
	},
	{
		id: "mbappe",
		name: "Kylian Mbappe",
		positions: [
			"ST",
			"LW",
			"RW"
		],
		signature: {
			pace: 97,
			shooting: 89,
			dribbling: 88
		},
		blurb: "Velocidade pura",
		nation: "FRA",
		era: "16-",
		number: 7,
		colors: ["#002395", "#ed2939"],
		iconic: false
	},
	{
		id: "zidane",
		name: "Zinedine Zidane",
		positions: ["CAM", "CM"],
		signature: {
			passing: 94,
			vision: 95,
			dribbling: 88
		},
		blurb: "Primeiro toque",
		nation: "FRA",
		era: "92-06",
		number: 5,
		colors: ["#002395", "#ed2939"],
		iconic: true
	},
	{
		id: "xavi",
		name: "Xavi",
		positions: ["CM", "CAM"],
		signature: {
			passing: 96,
			vision: 97
		},
		blurb: "Ritmo de posse",
		nation: "ESP",
		era: "98-15",
		number: 6,
		colors: ["#a50044", "#004d98"],
		iconic: true
	},
	{
		id: "iniesta",
		name: "Andres Iniesta",
		positions: [
			"CM",
			"CAM",
			"LM"
		],
		signature: {
			passing: 93,
			dribbling: 91,
			vision: 94
		},
		blurb: "Entre linhas",
		nation: "ESP",
		era: "02-18",
		number: 8,
		colors: ["#a50044", "#004d98"],
		iconic: true
	},
	{
		id: "kaka",
		name: "Kaka",
		positions: ["CAM"],
		signature: {
			pace: 88,
			passing: 90,
			shooting: 86,
			dribbling: 88
		},
		blurb: "Arrancada de 10",
		nation: "BRA",
		era: "01-14",
		number: 8,
		colors: ["#fb090b", "#000000"],
		iconic: false
	},
	{
		id: "vieira",
		name: "Patrick Vieira",
		positions: ["CDM", "CM"],
		signature: {
			physical: 93,
			defending: 90,
			passing: 82
		},
		blurb: "Presenca e pulmao",
		nation: "FRA",
		era: "95-10",
		number: 4,
		colors: ["#ef0107", "#ffffff"],
		iconic: false
	},
	{
		id: "makelele",
		name: "Claude Makelele",
		positions: ["CDM"],
		signature: {
			defending: 92,
			physical: 86,
			passing: 80
		},
		blurb: "Cobre o buraco",
		nation: "FRA",
		era: "92-08",
		number: 4,
		colors: ["#034694", "#ffffff"],
		iconic: false
	},
	{
		id: "maldini",
		name: "Paolo Maldini",
		positions: ["CB", "LB"],
		signature: {
			defending: 96,
			vision: 88,
			pace: 78
		},
		blurb: "Leitura e classe",
		nation: "ITA",
		era: "85-09",
		number: 3,
		colors: ["#fb090b", "#000000"],
		iconic: true
	},
	{
		id: "cannavaro",
		name: "Fabio Cannavaro",
		positions: ["CB"],
		signature: {
			defending: 94,
			physical: 84
		},
		blurb: "Antecipacao",
		nation: "ITA",
		era: "92-10",
		number: 5,
		colors: ["#0066cc", "#ffffff"],
		iconic: false
	},
	{
		id: "cafu",
		name: "Cafu",
		positions: ["RB"],
		signature: {
			pace: 90,
			passing: 84,
			physical: 86
		},
		blurb: "Sobe a faixa",
		nation: "BRA",
		era: "90-06",
		number: 2,
		colors: ["#ffdf00", "#009c3b"],
		iconic: true
	},
	{
		id: "carlos",
		name: "Roberto Carlos",
		positions: ["LB"],
		signature: {
			pace: 91,
			shooting: 86,
			physical: 84
		},
		blurb: "Bomba e sobreposicao",
		nation: "BRA",
		era: "93-07",
		number: 6,
		colors: ["#ffffff", "#fbbc04"],
		iconic: true
	},
	{
		id: "alves",
		name: "Dani Alves",
		positions: ["RB"],
		signature: {
			pace: 88,
			passing: 86,
			dribbling: 84
		},
		blurb: "Lateral ofensivo",
		nation: "BRA",
		era: "03-19",
		number: 2,
		colors: ["#a50044", "#004d98"],
		iconic: false
	},
	{
		id: "yashin",
		name: "Lev Yashin",
		positions: ["GK"],
		signature: {
			defending: 95,
			vision: 90,
			physical: 86
		},
		blurb: "Aranha negra",
		nation: "URS",
		era: "50-70",
		number: 1,
		colors: ["#111111", "#e4c15a"],
		iconic: true
	},
	{
		id: "buffon",
		name: "Gianluigi Buffon",
		positions: ["GK"],
		signature: {
			defending: 94,
			vision: 88,
			physical: 84
		},
		blurb: "Posicao e pulso",
		nation: "ITA",
		era: "95-18",
		number: 1,
		colors: ["#000000", "#ffffff"],
		iconic: true
	},
	{
		id: "henry",
		name: "Thierry Henry",
		positions: ["ST", "LW"],
		signature: {
			pace: 94,
			shooting: 91,
			dribbling: 88
		},
		blurb: "Diagonais letais",
		nation: "FRA",
		era: "97-10",
		number: 14,
		colors: ["#ef0107", "#ffffff"],
		iconic: true
	},
	{
		id: "maradona",
		name: "Diego Maradona",
		positions: ["CAM", "ST"],
		signature: {
			dribbling: 97,
			passing: 90,
			vision: 94,
			shooting: 88
		},
		blurb: "Genio com a bola",
		nation: "ARG",
		era: "76-94",
		number: 10,
		colors: ["#75aadb", "#ffffff"],
		iconic: true
	},
	{
		id: "zico",
		name: "Zico",
		positions: ["CAM", "ST"],
		signature: {
			passing: 93,
			shooting: 90,
			vision: 92
		},
		blurb: "Camisa 10 classico",
		nation: "BRA",
		era: "71-89",
		number: 10,
		colors: ["#c41e3a", "#1a1a1a"],
		iconic: true
	},
	{
		id: "garrincha",
		name: "Garrincha",
		positions: ["RW"],
		signature: {
			dribbling: 96,
			pace: 88
		},
		blurb: "Drible torto",
		nation: "BRA",
		era: "53-66",
		number: 7,
		colors: ["#ffdf00", "#009c3b"],
		iconic: true
	},
	{
		id: "beckenbauer",
		name: "Franz Beckenbauer",
		positions: ["CB", "CDM"],
		signature: {
			defending: 92,
			passing: 90,
			vision: 93
		},
		blurb: "Libero",
		nation: "GER",
		era: "64-77",
		number: 5,
		colors: ["#ffffff", "#dd0000"],
		iconic: true
	},
	{
		id: "cruyff",
		name: "Johan Cruyff",
		positions: [
			"CAM",
			"ST",
			"LW"
		],
		signature: {
			dribbling: 93,
			passing: 91,
			vision: 96,
			pace: 88
		},
		blurb: "Futebol total",
		nation: "NED",
		era: "64-78",
		number: 14,
		colors: ["#f36c21", "#ffffff"],
		iconic: true
	},
	{
		id: "vanbasten",
		name: "Marco van Basten",
		positions: ["ST"],
		signature: {
			shooting: 95,
			dribbling: 88,
			physical: 84
		},
		blurb: "Voleio e classe",
		nation: "NED",
		era: "82-93",
		number: 9,
		colors: ["#f36c21", "#ffffff"],
		iconic: true
	},
	{
		id: "eusebio",
		name: "Eusebio",
		positions: ["ST"],
		signature: {
			pace: 92,
			shooting: 94,
			dribbling: 86
		},
		blurb: "Pantera negra",
		nation: "POR",
		era: "57-73",
		number: 13,
		colors: ["#e41e26", "#ffffff"],
		iconic: true
	},
	{
		id: "distefano",
		name: "Alfredo Di Stefano",
		positions: ["ST", "CAM"],
		signature: {
			shooting: 92,
			passing: 90,
			vision: 93,
			physical: 86
		},
		blurb: "O jogador completo",
		nation: "ARG",
		era: "45-66",
		number: 9,
		colors: ["#ffffff", "#fbbc04"],
		iconic: true
	},
	{
		id: "puskas",
		name: "Ferenc Puskas",
		positions: ["ST", "CAM"],
		signature: {
			shooting: 96,
			passing: 88,
			vision: 90
		},
		blurb: "Esquerda de ouro",
		nation: "HUN",
		era: "43-66",
		number: 10,
		colors: ["#ffffff", "#fbbc04"],
		iconic: true
	},
	{
		id: "best",
		name: "George Best",
		positions: ["RW", "LW"],
		signature: {
			dribbling: 95,
			pace: 90,
			shooting: 86
		},
		blurb: "Quinto Beatle",
		nation: "NIR",
		era: "63-74",
		number: 7,
		colors: ["#da291c", "#fbe122"],
		iconic: true
	},
	{
		id: "platini",
		name: "Michel Platini",
		positions: ["CAM", "CM"],
		signature: {
			passing: 94,
			shooting: 91,
			vision: 93
		},
		blurb: "Camisa 10 europeu",
		nation: "FRA",
		era: "72-87",
		number: 10,
		colors: ["#002395", "#ed2939"],
		iconic: true
	},
	{
		id: "modric",
		name: "Luka Modric",
		positions: ["CM", "CAM"],
		signature: {
			passing: 93,
			vision: 94,
			dribbling: 88
		},
		blurb: "Motor e visao",
		nation: "CRO",
		era: "06-22",
		number: 10,
		colors: ["#ffffff", "#c8102e"],
		iconic: false
	},
	{
		id: "kroos",
		name: "Toni Kroos",
		positions: ["CM", "CDM"],
		signature: {
			passing: 95,
			vision: 93
		},
		blurb: "Passe laser",
		nation: "GER",
		era: "07-24",
		number: 8,
		colors: ["#ffffff", "#fbbc04"],
		iconic: false
	},
	{
		id: "pirlo",
		name: "Andrea Pirlo",
		positions: [
			"CM",
			"CDM",
			"CAM"
		],
		signature: {
			passing: 96,
			vision: 95
		},
		blurb: "Regista",
		nation: "ITA",
		era: "98-15",
		number: 21,
		colors: ["#000000", "#ffffff"],
		iconic: false
	},
	{
		id: "gerrard",
		name: "Steven Gerrard",
		positions: ["CM", "CAM"],
		signature: {
			passing: 90,
			shooting: 88,
			physical: 86,
			vision: 88
		},
		blurb: "Box-to-box de final",
		nation: "ENG",
		era: "98-15",
		number: 8,
		colors: ["#c8102e", "#00b2a9"],
		iconic: false
	},
	{
		id: "lampard",
		name: "Frank Lampard",
		positions: ["CM", "CAM"],
		signature: {
			shooting: 90,
			passing: 86,
			vision: 86
		},
		blurb: "Chegada na area",
		nation: "ENG",
		era: "95-15",
		number: 8,
		colors: ["#034694", "#ffffff"],
		iconic: false
	},
	{
		id: "scholes",
		name: "Paul Scholes",
		positions: ["CM"],
		signature: {
			passing: 93,
			shooting: 88,
			vision: 92
		},
		blurb: "Passe e chute de longe",
		nation: "ENG",
		era: "94-13",
		number: 18,
		colors: ["#da291c", "#fbe122"],
		iconic: false
	},
	{
		id: "socrates",
		name: "Socrates",
		positions: ["CAM", "CM"],
		signature: {
			passing: 92,
			vision: 94,
			shooting: 84
		},
		blurb: "Doutor e 10",
		nation: "BRA",
		era: "74-89",
		number: 8,
		colors: ["#c41e3a", "#1a1a1a"],
		iconic: false
	},
	{
		id: "rivaldo",
		name: "Rivaldo",
		positions: [
			"CAM",
			"LW",
			"ST"
		],
		signature: {
			shooting: 91,
			dribbling: 90,
			passing: 86
		},
		blurb: "Perna esquerda",
		nation: "BRA",
		era: "91-03",
		number: 10,
		colors: ["#a50044", "#004d98"],
		iconic: false
	},
	{
		id: "baggio",
		name: "Roberto Baggio",
		positions: ["CAM", "ST"],
		signature: {
			dribbling: 93,
			shooting: 90,
			vision: 90
		},
		blurb: "Divino",
		nation: "ITA",
		era: "86-04",
		number: 10,
		colors: ["#000000", "#ffffff"],
		iconic: false
	},
	{
		id: "totti",
		name: "Francesco Totti",
		positions: ["CAM", "ST"],
		signature: {
			passing: 91,
			shooting: 88,
			vision: 92
		},
		blurb: "Rei de Roma",
		nation: "ITA",
		era: "93-17",
		number: 10,
		colors: ["#8e1f2f", "#f0bc42"],
		iconic: false
	},
	{
		id: "figo",
		name: "Luis Figo",
		positions: ["RW", "RM"],
		signature: {
			dribbling: 90,
			passing: 88,
			pace: 86
		},
		blurb: "Extremo classico",
		nation: "POR",
		era: "91-09",
		number: 7,
		colors: ["#ffffff", "#fbbc04"],
		iconic: false
	},
	{
		id: "jairzinho",
		name: "Jairzinho",
		positions: ["RW"],
		signature: {
			pace: 92,
			dribbling: 90,
			shooting: 86
		},
		blurb: "Furacao da copa",
		nation: "BRA",
		era: "64-74",
		number: 7,
		colors: ["#ffdf00", "#009c3b"],
		iconic: false
	},
	{
		id: "rivelino",
		name: "Rivelino",
		positions: ["LW", "CAM"],
		signature: {
			shooting: 90,
			passing: 88,
			dribbling: 88
		},
		blurb: "Elástico e bomba",
		nation: "BRA",
		era: "65-78",
		number: 11,
		colors: ["#ffdf00", "#009c3b"],
		iconic: false
	},
	{
		id: "salah",
		name: "Mohamed Salah",
		positions: ["RW"],
		signature: {
			pace: 93,
			shooting: 90,
			dribbling: 88
		},
		blurb: "Corte pra dentro",
		nation: "EGY",
		era: "14-",
		number: 11,
		colors: ["#c8102e", "#00b2a9"],
		iconic: false
	},
	{
		id: "hazard",
		name: "Eden Hazard",
		positions: ["LW", "CAM"],
		signature: {
			dribbling: 94,
			pace: 88,
			passing: 86
		},
		blurb: "Baixo centro",
		nation: "BEL",
		era: "07-19",
		number: 10,
		colors: ["#034694", "#ffffff"],
		iconic: false
	},
	{
		id: "suarez",
		name: "Luis Suarez",
		positions: ["ST"],
		signature: {
			shooting: 92,
			dribbling: 86,
			physical: 84
		},
		blurb: "Fome de gol",
		nation: "URU",
		era: "05-22",
		number: 9,
		colors: ["#a50044", "#004d98"],
		iconic: false
	},
	{
		id: "lewa",
		name: "Robert Lewandowski",
		positions: ["ST"],
		signature: {
			shooting: 94,
			physical: 86,
			vision: 84
		},
		blurb: "Maquina de gol",
		nation: "POL",
		era: "08-",
		number: 9,
		colors: ["#dc052d", "#0066b2"],
		iconic: false
	},
	{
		id: "batistuta",
		name: "Gabriel Batistuta",
		positions: ["ST"],
		signature: {
			shooting: 94,
			physical: 88,
			pace: 82
		},
		blurb: "Batigol",
		nation: "ARG",
		era: "88-03",
		number: 9,
		colors: ["#4203c9", "#d4001f"],
		iconic: false
	},
	{
		id: "raul",
		name: "Raul",
		positions: ["ST", "CAM"],
		signature: {
			shooting: 90,
			vision: 88,
			passing: 84
		},
		blurb: "Capitao branco",
		nation: "ESP",
		era: "94-10",
		number: 7,
		colors: ["#ffffff", "#fbbc04"],
		iconic: false
	},
	{
		id: "sheva",
		name: "Andriy Shevchenko",
		positions: ["ST"],
		signature: {
			shooting: 92,
			pace: 86,
			physical: 82
		},
		blurb: "Movimentacao",
		nation: "UKR",
		era: "94-09",
		number: 7,
		colors: ["#fb090b", "#000000"],
		iconic: false
	},
	{
		id: "ramos",
		name: "Sergio Ramos",
		positions: ["CB"],
		signature: {
			defending: 90,
			physical: 90,
			shooting: 78
		},
		blurb: "Lider e pulmao",
		nation: "ESP",
		era: "04-21",
		number: 4,
		colors: ["#ffffff", "#fbbc04"],
		iconic: false
	},
	{
		id: "puyol",
		name: "Carles Puyol",
		positions: ["CB"],
		signature: {
			defending: 92,
			physical: 90
		},
		blurb: "Capitao de ferro",
		nation: "ESP",
		era: "99-14",
		number: 5,
		colors: ["#a50044", "#004d98"],
		iconic: false
	},
	{
		id: "nesta",
		name: "Alessandro Nesta",
		positions: ["CB"],
		signature: {
			defending: 95,
			pace: 80,
			vision: 86
		},
		blurb: "Antecipa tudo",
		nation: "ITA",
		era: "93-13",
		number: 13,
		colors: ["#fb090b", "#000000"],
		iconic: false
	},
	{
		id: "baresi",
		name: "Franco Baresi",
		positions: ["CB"],
		signature: {
			defending: 96,
			vision: 90,
			passing: 84
		},
		blurb: "Cerebro da zaga",
		nation: "ITA",
		era: "77-97",
		number: 6,
		colors: ["#fb090b", "#000000"],
		iconic: true
	},
	{
		id: "thiago",
		name: "Thiago Silva",
		positions: ["CB"],
		signature: {
			defending: 90,
			vision: 86,
			passing: 82
		},
		blurb: "Leitura moderna",
		nation: "BRA",
		era: "06-22",
		number: 2,
		colors: ["#004170", "#da291c"],
		iconic: false
	},
	{
		id: "lucio",
		name: "Lucio",
		positions: ["CB"],
		signature: {
			defending: 88,
			physical: 92,
			pace: 84
		},
		blurb: "Sobe com a bola",
		nation: "BRA",
		era: "98-13",
		number: 3,
		colors: ["#dc052d", "#0066b2"],
		iconic: false
	},
	{
		id: "lahm",
		name: "Philipp Lahm",
		positions: [
			"RB",
			"LB",
			"CDM"
		],
		signature: {
			defending: 88,
			passing: 90,
			vision: 90,
			pace: 82
		},
		blurb: "O relogio",
		nation: "GER",
		era: "02-17",
		number: 21,
		colors: ["#dc052d", "#0066b2"],
		iconic: false
	},
	{
		id: "marcelo",
		name: "Marcelo",
		positions: ["LB"],
		signature: {
			dribbling: 90,
			passing: 86,
			pace: 86
		},
		blurb: "Lateral-meia",
		nation: "BRA",
		era: "05-22",
		number: 12,
		colors: ["#ffffff", "#fbbc04"],
		iconic: false
	},
	{
		id: "zanetti",
		name: "Javier Zanetti",
		positions: ["RB", "RM"],
		signature: {
			physical: 90,
			defending: 86,
			pace: 84
		},
		blurb: "Pulmao eterno",
		nation: "ARG",
		era: "92-14",
		number: 4,
		colors: ["#010E80", "#000000"],
		iconic: false
	},
	{
		id: "thuram",
		name: "Lilian Thuram",
		positions: ["RB", "CB"],
		signature: {
			defending: 90,
			physical: 90,
			pace: 86
		},
		blurb: "Forca e leitura",
		nation: "FRA",
		era: "91-08",
		number: 15,
		colors: ["#010E80", "#000000"],
		iconic: false
	},
	{
		id: "cole",
		name: "Ashley Cole",
		positions: ["LB"],
		signature: {
			pace: 88,
			defending: 88,
			physical: 82
		},
		blurb: "Lateral de copa",
		nation: "ENG",
		era: "99-14",
		number: 3,
		colors: ["#034694", "#ffffff"],
		iconic: false
	},
	{
		id: "casemiro",
		name: "Casemiro",
		positions: ["CDM"],
		signature: {
			defending: 88,
			physical: 90,
			passing: 80
		},
		blurb: "Destruidor",
		nation: "BRA",
		era: "13-",
		number: 14,
		colors: ["#ffffff", "#fbbc04"],
		iconic: false
	},
	{
		id: "kante",
		name: "N'Golo Kante",
		positions: ["CDM", "CM"],
		signature: {
			defending: 90,
			physical: 86,
			pace: 84
		},
		blurb: "Cobre o campo",
		nation: "FRA",
		era: "12-22",
		number: 7,
		colors: ["#034694", "#ffffff"],
		iconic: false
	},
	{
		id: "busquets",
		name: "Sergio Busquets",
		positions: ["CDM"],
		signature: {
			passing: 90,
			vision: 93,
			defending: 84
		},
		blurb: "Pivô e pausa",
		nation: "ESP",
		era: "08-22",
		number: 5,
		colors: ["#a50044", "#004d98"],
		iconic: false
	},
	{
		id: "rijkaard",
		name: "Frank Rijkaard",
		positions: ["CDM", "CB"],
		signature: {
			defending: 90,
			passing: 86,
			physical: 88
		},
		blurb: "Volante total",
		nation: "NED",
		era: "80-95",
		number: 4,
		colors: ["#fb090b", "#000000"],
		iconic: false
	},
	{
		id: "matthaus",
		name: "Lothar Matthaus",
		positions: [
			"CM",
			"CDM",
			"CB"
		],
		signature: {
			passing: 88,
			physical: 88,
			shooting: 84,
			vision: 88
		},
		blurb: "Box-to-box eterno",
		nation: "GER",
		era: "79-00",
		number: 10,
		colors: ["#ffffff", "#dd0000"],
		iconic: false
	},
	{
		id: "gullit",
		name: "Ruud Gullit",
		positions: [
			"CAM",
			"CM",
			"ST"
		],
		signature: {
			physical: 90,
			passing: 86,
			dribbling: 86,
			vision: 88
		},
		blurb: "Atleta completo",
		nation: "NED",
		era: "79-95",
		number: 10,
		colors: ["#fb090b", "#000000"],
		iconic: false
	},
	{
		id: "kahn",
		name: "Oliver Kahn",
		positions: ["GK"],
		signature: {
			defending: 94,
			physical: 90,
			vision: 84
		},
		blurb: "Titã no gol",
		nation: "GER",
		era: "87-08",
		number: 1,
		colors: ["#dc052d", "#0066b2"],
		iconic: false
	},
	{
		id: "casillas",
		name: "Iker Casillas",
		positions: ["GK"],
		signature: {
			defending: 92,
			vision: 88,
			pace: 78
		},
		blurb: "Reflexo de santo",
		nation: "ESP",
		era: "99-16",
		number: 1,
		colors: ["#ffffff", "#fbbc04"],
		iconic: false
	},
	{
		id: "neuer",
		name: "Manuel Neuer",
		positions: ["GK"],
		signature: {
			defending: 92,
			vision: 94,
			passing: 86
		},
		blurb: "Sweeper-keeper",
		nation: "GER",
		era: "06-",
		number: 1,
		colors: ["#dc052d", "#0066b2"],
		iconic: false
	},
	{
		id: "schmeichel",
		name: "Peter Schmeichel",
		positions: ["GK"],
		signature: {
			defending: 93,
			physical: 92,
			vision: 84
		},
		blurb: "Muralha",
		nation: "DEN",
		era: "87-99",
		number: 1,
		colors: ["#da291c", "#fbe122"],
		iconic: false
	},
	{
		id: "taffarel",
		name: "Claudio Taffarel",
		positions: ["GK"],
		signature: {
			defending: 90,
			vision: 84,
			physical: 82
		},
		blurb: "Penalti e copa",
		nation: "BRA",
		era: "85-98",
		number: 1,
		colors: ["#ffdf00", "#009c3b"],
		iconic: false
	},
	{
		id: "dida",
		name: "Dida",
		positions: ["GK"],
		signature: {
			defending: 88,
			physical: 86,
			vision: 80
		},
		blurb: "Champions e palme",
		nation: "BRA",
		era: "92-10",
		number: 1,
		colors: ["#fb090b", "#000000"],
		iconic: false
	},
	{
		id: "cech",
		name: "Petr Cech",
		positions: ["GK"],
		signature: {
			defending: 91,
			vision: 86,
			physical: 86
		},
		blurb: "Boné e palme",
		nation: "CZE",
		era: "01-15",
		number: 1,
		colors: ["#034694", "#ffffff"],
		iconic: false
	},
	{
		id: "nilton",
		name: "Nilton Santos",
		positions: ["LB"],
		signature: {
			defending: 90,
			passing: 84,
			pace: 82
		},
		blurb: "A Enciclopedia",
		nation: "BRA",
		era: "48-64",
		number: 6,
		colors: ["#000000", "#ffffff"],
		iconic: false
	},
	{
		id: "carlosalberto",
		name: "Carlos Alberto",
		positions: ["RB"],
		signature: {
			pace: 86,
			passing: 86,
			shooting: 80,
			defending: 84
		},
		blurb: "Gol da final",
		nation: "BRA",
		era: "63-77",
		number: 4,
		colors: ["#ffdf00", "#009c3b"],
		iconic: false
	}
];
function legendsFor(position) {
	const list = LEGENDS.filter((l) => l.positions.includes(position));
	return list.length ? list : LEGENDS;
}
function idolsFor(position) {
	const primary = LEGENDS.filter((l) => l.positions.includes(position));
	const extra = LEGENDS.filter((l) => !l.positions.includes(position) && l.iconic);
	return [...primary, ...extra];
}
function legendArt(legend) {
	if (legend.positions.includes("GK")) return "/legend-1.jpg";
	if (legend.positions.includes("ST") && !legend.positions.includes("CAM")) return "/legend-9.jpg";
	if (legend.positions.includes("RW") || legend.positions.includes("LW") || legend.number === 7) return "/legend-7.jpg";
	return "/legend-10.jpg";
}
var FEATURED_LANDING = [
	"pele",
	"ronaldo",
	"maradona",
	"messi",
	"cr7",
	"maldini",
	"yashin",
	"garrincha"
];
function clamp(n, min, max) {
	return Math.max(min, Math.min(max, n));
}
function round1(n) {
	return Math.round(n * 10) / 10;
}
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a = a + 1831565813 >>> 0;
		let t = a;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function rngFrom(state) {
	const rng = mulberry32(state.seed + state.rngCount * 9973);
	state.rngCount += 1;
	return rng;
}
function pick(rng, list) {
	return list[Math.floor(rng() * list.length)];
}
function randInt(rng, min, max) {
	return min + Math.floor(rng() * (max - min + 1));
}
function calcOverall(position, attrs) {
	const w = POSITION_WEIGHTS[position];
	let sum = 0;
	for (const key of ATTR_KEYS) sum += attrs[key] * w[key];
	return clamp(Math.round(sum), 40, 99);
}
function cardFromOverall(overall) {
	if (overall >= 88) return "fenomeno";
	if (overall >= 82) return "rare";
	if (overall >= 75) return "gold";
	if (overall >= 65) return "silver";
	return "bronze";
}
function defaultAppearance() {
	return {
		skin: 2,
		hair: "short",
		facial: "none",
		photo: null
	};
}
function rollAttr(rng, weight) {
	if (weight >= .24) return randInt(rng, 58, 72);
	if (weight >= .16) return randInt(rng, 50, 66);
	if (weight >= .1) return randInt(rng, 42, 58);
	if (weight >= .06) return randInt(rng, 32, 50);
	return randInt(rng, 22, 42);
}
function rollPlayer(opts) {
	const rng = mulberry32(opts.seed ?? Math.floor(Math.random() * 1e9));
	const w = POSITION_WEIGHTS[opts.position];
	const attributes = {};
	for (const key of ATTR_KEYS) attributes[key] = rollAttr(rng, w[key]);
	const pool = legendsFor(opts.position);
	const iconic = LEGENDS.filter((l) => l.iconic);
	const steals = [];
	const usedAttr = /* @__PURE__ */ new Set();
	const usedLegend = /* @__PURE__ */ new Set();
	function stealFrom(legend, rare) {
		if (!legend) return;
		const keys = Object.keys(legend.signature).filter((k) => !usedAttr.has(k));
		if (!keys.length) return;
		const attr = pick(rng, keys);
		usedAttr.add(attr);
		usedLegend.add(legend.id);
		const peak = legend.signature[attr] ?? 85;
		const mul = rare ? .72 + rng() * .14 : .56 + rng() * .14;
		const cap = rare ? 84 : 78;
		attributes[attr] = clamp(Math.round(peak * mul + randInt(rng, -2, 2)), 40, cap);
		steals.push({
			legend: legend.name,
			attr,
			rare
		});
	}
	const first = pick(rng, pool);
	stealFrom(first, false);
	if (rng() > .48) {
		const rest = pool.filter((l) => l.id !== first.id);
		if (rest.length) stealFrom(pick(rng, rest), false);
	}
	if (rng() > .58) {
		const world = LEGENDS.filter((l) => !usedLegend.has(l.id));
		if (world.length) {
			const chosen = pick(rng, world);
			stealFrom(chosen, chosen.iconic);
		}
	}
	if (rng() > .78) {
		const rarePool = iconic.filter((l) => !usedLegend.has(l.id));
		if (rarePool.length) stealFrom(pick(rng, rarePool), true);
	}
	const idol = pool.find((l) => l.id === opts.idolId) ?? LEGENDS.find((l) => l.id === opts.idolId) ?? pick(rng, pool);
	if (idol.signature) for (const key of Object.keys(idol.signature)) attributes[key] = clamp(attributes[key] + randInt(rng, 0, 2), 25, 80);
	const raw = calcOverall(opts.position, attributes);
	const scale = randInt(rng, 56, 64) / Math.max(raw, 1);
	for (const key of ATTR_KEYS) attributes[key] = clamp(Math.round(attributes[key] * scale + randInt(rng, -1, 1)), 22, 78);
	const overall = calcOverall(opts.position, attributes);
	const talent = rng();
	let potential;
	if (talent > .97) potential = randInt(rng, 92, 96);
	else if (talent > .85) potential = randInt(rng, 87, 92);
	else if (talent > .55) potential = randInt(rng, 80, 87);
	else potential = randInt(rng, 74, 82);
	potential = clamp(Math.max(potential, overall + 10), overall + 8, 97);
	return {
		name: opts.name.trim() || "Jogador",
		nationId: opts.nationId,
		position: opts.position,
		shirtNumber: opts.shirtNumber,
		age: 16,
		overall,
		potential,
		attributes,
		cardStyle: "bronze",
		playStyle: pick(rng, PLAY_STYLES[opts.position]),
		idolId: idol.id,
		idolName: idol.name,
		steals,
		appearance: opts.appearance ?? defaultAppearance()
	};
}
function rollAcademy(nationId, seed) {
	return pick(mulberry32(seed + 17), academyPool(nationId));
}
function emptySeasonStats() {
	return {
		appearances: 0,
		starts: 0,
		minutes: 0,
		goals: 0,
		assists: 0,
		cleanSheets: 0,
		yellows: 0,
		reds: 0,
		avgRating: 0,
		ratingSum: 0,
		motm: 0,
		wins: 0,
		draws: 0,
		losses: 0
	};
}
function createCareer(payload, seed = Math.floor(Math.random() * 1e9)) {
	const club = clubById(payload.clubId);
	const player = {
		...payload.player,
		shirtNumber: payload.shirtNumber,
		position: payload.position,
		name: payload.name.trim() || payload.player.name,
		nationId: payload.nationId,
		cardStyle: "bronze"
	};
	player.overall = calcOverall(player.position, player.attributes);
	player.cardStyle = "bronze";
	const wage = startingWage(player.overall, club);
	const followers = 400 + Math.round(player.overall * 18);
	return {
		version: 3,
		mode: payload.mode,
		seed,
		rngCount: 1,
		player,
		clubId: club.id,
		week: 1,
		season: 1,
		year: 2026,
		money: 900,
		weeklyWage: wage,
		fame: clamp(Math.round((player.overall - 52) * 1.1), 2, 14),
		morale: 72,
		form: 58,
		fitness: 86,
		aggression: player.position === "CDM" || player.position === "CB" ? 62 : 48,
		injury: null,
		chronicPenalty: 0,
		contractYearsLeft: 3,
		contractYearsTotal: 3,
		releaseClause: wage * 90,
		stats: {
			...emptySeasonStats(),
			seasons: 0,
			clubs: [club.id]
		},
		seasonStats: emptySeasonStats(),
		titles: [],
		news: [{
			id: "start",
			week: 1,
			season: 1,
			text: `Saiu da base do ${club.name}. Contrato de 3 anos, ${formatMoney(wage, club.countryCode)}/sem. Cartinha bronze.`,
			tone: "neutral"
		}],
		offers: [],
		sponsorships: [],
		agentMood: 70,
		matchLoad: [],
		pendingMatch: null,
		lastMatch: null,
		retired: false,
		retireReason: null,
		overallAtSeasonStart: player.overall,
		leaguePlace: estimatePlace(club.reputation, 0),
		followers,
		seasonPoints: 0,
		peakOverall: player.overall,
		highlights: [],
		pendingRaise: null,
		pendingBrand: null,
		sacked: false,
		coach: null,
		historyRank: null,
		lifeVerdict: null
	};
}
function startingWage(overall, club) {
	return clamp(Math.max(250, Math.round(overall * 12 * (club.reputation / 80))), 250, Math.round(club.wageBudget * .08));
}
function formatMoney(amount, countryCode = "EUR") {
	if (countryCode === "BRA") return new Intl.NumberFormat("pt-BR", {
		style: "currency",
		currency: "BRL",
		maximumFractionDigits: 0
	}).format(Math.round(amount * 6));
	return new Intl.NumberFormat("pt-BR", {
		style: "currency",
		currency: "EUR",
		maximumFractionDigits: 0
	}).format(Math.round(amount));
}
function formatFortune(amount) {
	if (amount >= 1e6) return `€ ${(amount / 1e6).toFixed(2)} mi`;
	if (amount >= 1e3) return `€ ${Math.round(amount / 1e3)} mil`;
	return `€ ${Math.round(amount)}`;
}
function formatFollowers(n) {
	if (n >= 1e6) return `${(n / 1e6).toFixed(1)} mi`;
	if (n >= 1e3) return `${(n / 1e3).toFixed(1)} mil`;
	return `${Math.round(n)}`;
}
function pushNews(state, text, tone) {
	state.news.unshift({
		id: `${state.season}-${state.week}-${state.rngCount}`,
		week: state.week,
		season: state.season,
		text,
		tone
	});
	state.news = state.news.slice(0, 24);
}
function minutesFor(state) {
	if (state.injury) return 0;
	const gap = clubById(state.clubId).reputation - state.player.overall;
	const form = state.form;
	const morale = state.morale;
	if (gap > 14) return form > 70 && morale > 60 ? randInt(rngFrom(state), 8, 28) : randInt(rngFrom(state), 0, 18);
	if (gap > 7) return randInt(rngFrom(state), 25, 70);
	if (gap > 2) return randInt(rngFrom(state), 55, 90);
	return randInt(rngFrom(state), 75, 90);
}
function roleFromGap(overall, clubRep) {
	const gap = clubRep - overall;
	if (gap > 12) return "promessa";
	if (gap > 5) return "rotacao";
	if (overall >= clubRep + 4) return "estrela";
	return "titular";
}
function buildFixture(state) {
	const club = clubById(state.clubId);
	const peers = CLUBS.filter((c) => c.league === club.league && c.id !== club.id);
	const fillers = FILLER_OPPONENTS[club.league] ?? [];
	const rng = rngFrom(state);
	const opp = pick(rng, [...peers.map((c) => ({
		name: c.name,
		rep: c.reputation
	})), ...fillers]);
	const week = state.week;
	const home = week % 2 === 1;
	let importance = "normal";
	let competition = club.league;
	if (week === 12 || week === 28) {
		competition = club.countryCode === "BRA" ? "Copa do Brasil" : "Copa nacional";
		importance = "big";
	}
	if (week === 36) {
		competition = club.reputation >= 82 ? club.countryCode === "BRA" ? "Libertadores" : "Champions" : "Copa nacional";
		importance = "final";
	}
	if (Math.abs(opp.rep - club.reputation) <= 3 && rng() > .55) importance = "big";
	return {
		opponentName: opp.name,
		opponentRep: opp.rep,
		competition,
		home,
		importance,
		week
	};
}
function applyChoice(choice) {
	switch (choice) {
		case "safe": return {
			rating: .1,
			injury: .7,
			goal: .75,
			morale: 0
		};
		case "hero": return {
			rating: .55,
			injury: 1.25,
			goal: 1.35,
			morale: 4
		};
		case "war": return {
			rating: .25,
			injury: 1.9,
			goal: .9,
			morale: 2
		};
		case "pass": return {
			rating: .35,
			injury: .9,
			goal: .7,
			morale: 1
		};
		case "shoot": return {
			rating: .4,
			injury: 1.1,
			goal: 1.5,
			morale: 2
		};
		default: return {
			rating: 0,
			injury: 1,
			goal: 1,
			morale: 0
		};
	}
}
function maybeInjury(state, riskMul) {
	const rng = rngFrom(state);
	const age = state.player.age;
	const load = state.matchLoad.slice(-8).reduce((a, b) => a + b, 0);
	let chance = .028 * riskMul;
	if (age >= 30) chance *= 1.45;
	if (age >= 34) chance *= 1.5;
	if (state.fitness < 52) chance *= 1.7;
	if (load > 6) chance *= 1.45;
	if (state.aggression > 70) chance *= 1.25;
	if (state.player.attributes.physical > 82) chance *= .72;
	if (state.chronicPenalty > 0) chance *= 1.35;
	if (rng() > chance) return null;
	let table = INJURY_TABLE;
	if (age < 24) table = table.filter((t) => t.severity !== "cronica");
	const row = pick(rng, table);
	const weeks = randInt(rng, row.weeks[0], row.weeks[1]);
	return {
		id: `inj-${state.rngCount}`,
		name: row.name,
		severity: row.severity,
		weeksLeft: weeks,
		weeksTotal: weeks,
		chronic: row.severity === "cronica"
	};
}
function goalExpect(position) {
	switch (position) {
		case "ST": return {
			g: .48,
			a: .16
		};
		case "LW":
		case "RW": return {
			g: .26,
			a: .24
		};
		case "CAM": return {
			g: .2,
			a: .32
		};
		case "CM": return {
			g: .08,
			a: .18
		};
		case "LM":
		case "RM": return {
			g: .12,
			a: .2
		};
		case "CDM": return {
			g: .04,
			a: .1
		};
		case "LB":
		case "RB": return {
			g: .05,
			a: .14
		};
		case "CB": return {
			g: .04,
			a: .04
		};
		case "GK": return {
			g: .002,
			a: .01
		};
	}
}
function simulateMatch(state, choice) {
	const preview = state.pendingMatch ?? buildFixture(state);
	const club = clubById(state.clubId);
	const rng = rngFrom(state);
	const ch = applyChoice(choice);
	const minutes = minutesFor(state);
	const ovr = state.player.overall;
	const formMod = (state.form - 50) * .07;
	const moraleMod = (state.morale - 50) * .05;
	const fitMod = (state.fitness - 70) * .05;
	const playerLive = ovr + formMod + moraleMod + fitMod + ch.rating * 4;
	const winP = clamp(.28 + (club.reputation * .72 + playerLive * .28 + (preview.home ? 2.2 : 0) - preview.opponentRep) / 70, .1, .78);
	const drawP = .26;
	const roll = rng();
	const result = roll < winP ? "W" : roll < winP + drawP ? "D" : "L";
	let gf = result === "W" ? randInt(rng, 1, 3) : result === "D" ? randInt(rng, 0, 2) : randInt(rng, 0, 1);
	let ga = result === "W" ? randInt(rng, 0, 1) : result === "D" ? gf : gf + randInt(rng, 1, 3);
	if (result === "D" && gf === 0 && rng() > .4) {
		gf = 1;
		ga = 1;
	}
	const expect = goalExpect(state.player.position);
	const share = clamp(minutes / 90, 0, 1) * clamp(playerLive / 78, .4, 1.35) * ch.goal;
	let goals = 0;
	let assists = 0;
	if (minutes >= 15) {
		if (rng() < expect.g * share) goals = 1;
		if (rng() < expect.g * share * .28) goals += 1;
		if (rng() < expect.a * share) assists = 1;
		if (rng() < expect.a * share * .22) assists += 1;
	}
	if (result === "L") goals = Math.min(goals, gf);
	if (goals + (rng() > .5 ? assists : 0) > gf) assists = Math.max(0, gf - goals);
	let rating = 6.2 + (playerLive - 70) * .045 + minutes / 90 * .3;
	rating += goals * .85 + assists * .55;
	if (result === "W") rating += .25;
	if (result === "L") rating -= .2;
	if (minutes < 20) rating = clamp(rating, 5.7, 7.1);
	rating = clamp(round1(rating + (rng() - .5) * .6), 4.4, 10);
	const yellow = rng() < (choice === "war" ? .22 : .08);
	const red = rng() < (choice === "war" ? .04 : .012);
	const motm = rating >= 8.4 && minutes >= 60;
	const injured = minutes > 0 ? maybeInjury(state, ch.injury) : null;
	const events = buildEvents({
		rng,
		preview,
		clubName: club.shortName,
		result,
		gf,
		ga,
		goals,
		assists,
		yellow,
		red,
		injured,
		minutes,
		playerName: state.player.name.split(" ").slice(-1)[0] ?? state.player.name,
		position: state.player.position
	});
	return {
		preview,
		playerTeam: club.name,
		opponent: preview.opponentName,
		home: preview.home,
		goalsFor: gf,
		goalsAgainst: ga,
		result,
		rating,
		minutes,
		goals,
		assists,
		yellow,
		red,
		motm,
		events,
		choice,
		injured,
		competition: preview.competition
	};
}
function buildEvents(opts) {
	const { rng, preview, clubName, gf, ga, goals, assists, yellow, red, injured, minutes, playerName } = opts;
	const events = [{
		minute: 1,
		text: `Apito inicial. ${clubName} ${preview.home ? "em casa" : "fora"} contra ${preview.opponentName}.`,
		kind: "whistle"
	}];
	if (minutes < 8) events.push({
		minute: 12,
		text: `${playerName} comeca no banco. Poucos minutos hoje.`,
		kind: "play"
	});
	const playerGoalMins = [];
	for (let i = 0; i < goals; i++) playerGoalMins.push(randInt(rng, 8, Math.max(10, minutes - 2)));
	playerGoalMins.sort((a, b) => a - b);
	const otherFor = Math.max(0, gf - goals);
	const forMins = [...playerGoalMins, ...Array.from({ length: otherFor }, () => randInt(rng, 6, 88))].sort((a, b) => a - b);
	const againstMins = Array.from({ length: ga }, () => randInt(rng, 7, 90)).sort((a, b) => a - b);
	for (const m of forMins) {
		const yours = playerGoalMins.includes(m);
		events.push({
			minute: m,
			text: yours ? `GOL DE ${playerName.toUpperCase()}! ${m}'` : `Gol de ${clubName}, ${m}'`,
			kind: yours ? "goal" : "play"
		});
	}
	if (assists > 0) events.push({
		minute: randInt(rng, 10, 80),
		text: `Assistencia de ${playerName}. Visao de jogo.`,
		kind: "assist"
	});
	for (const m of againstMins) events.push({
		minute: m,
		text: `${preview.opponentName} empata o gol, ${m}'`,
		kind: "play"
	});
	if (yellow) events.push({
		minute: randInt(rng, 20, 85),
		text: `Cartao amarelo para ${playerName}.`,
		kind: "card"
	});
	if (red) events.push({
		minute: randInt(rng, 40, 88),
		text: `Vermelho! ${playerName} expulso.`,
		kind: "card"
	});
	if (injured) events.push({
		minute: randInt(rng, 15, 80),
		text: `${playerName} sente ${injured.name.toLowerCase()} e para.`,
		kind: "injury"
	});
	events.push({
		minute: 90,
		text: `Fim de jogo. ${gf}–${ga}.`,
		kind: "whistle"
	});
	events.sort((a, b) => a.minute - b.minute);
	return events;
}
function applyMatchToState(state, match) {
	const s = state.seasonStats;
	if (match.minutes > 0) {
		s.appearances += 1;
		if (match.minutes >= 60) s.starts += 1;
		s.minutes += match.minutes;
		s.goals += match.goals;
		s.assists += match.assists;
		s.ratingSum += match.rating;
		s.avgRating = round1(s.ratingSum / s.appearances);
		if (match.yellow) s.yellows += 1;
		if (match.red) s.reds += 1;
		if (match.motm) s.motm += 1;
		if (match.goalsFor === 0 && match.minutes >= 60 && (state.player.position === "GK" || state.player.position === "CB")) s.cleanSheets += 1;
	}
	if (match.result === "W") s.wins += 1;
	else if (match.result === "D") s.draws += 1;
	else s.losses += 1;
	state.form = clamp(state.form + (match.rating - 6.6) * 3.2, 20, 99);
	state.morale = clamp(state.morale + (match.result === "W" ? 4 : match.result === "D" ? 0 : -4) + (match.motm ? 6 : 0), 15, 99);
	state.fitness = clamp(state.fitness - (match.minutes > 70 ? 8 : match.minutes > 20 ? 5 : 1), 25, 100);
	state.fame = clamp(state.fame + (match.goals * 1.4 + (match.motm ? 2 : 0) + (match.preview.importance === "final" && match.result === "W" ? 4 : 0)), 0, 100);
	if (match.minutes >= 60) growFromMatch(state, match.rating);
	if (match.injured) {
		state.injury = match.injured;
		if (match.injured.chronic) {
			state.chronicPenalty += 1;
			state.player.attributes.physical = clamp(state.player.attributes.physical - 2, 25, 99);
			state.player.attributes.pace = clamp(state.player.attributes.pace - 1, 25, 99);
			recalcOvr(state);
		}
		pushNews(state, `Lesao: ${match.injured.name}. Previsao de ${match.injured.weeksTotal} semana(s).`, "bad");
		state.morale = clamp(state.morale - 8, 10, 99);
	}
	state.matchLoad.push(match.minutes >= 45 ? 1 : 0);
	if (state.matchLoad.length > 12) state.matchLoad.shift();
	state.lastMatch = match;
	state.pendingMatch = null;
	if (match.motm || match.goals >= 2 || match.injured || match.preview.importance === "final" || match.rating >= 8.2) {
		state.highlights.unshift(match);
		state.highlights = state.highlights.slice(0, 16);
	}
	state.followers = clamp(state.followers + match.goals * 1800 + (match.motm ? 4e3 : 0) + Math.round(match.rating * 80), 0, 8e7);
}
function growFromMatch(state, rating) {
	if (state.mode === "complete") return;
	const age = state.player.age;
	if (state.player.potential - state.player.overall <= 0 || age > 32) return;
	const rng = rngFrom(state);
	const speed = age <= 21 ? 1 : age <= 26 ? .55 : .22;
	if (rng() < .35 * speed * clamp(rating / 7.5, .6, 1.4)) {
		const w = POSITION_WEIGHTS[state.player.position];
		const key = pick(rng, ATTR_KEYS.filter((k) => w[k] >= .1));
		state.player.attributes[key] = clamp(state.player.attributes[key] + 1, 25, 99);
		recalcOvr(state);
	}
}
function recalcOvr(state) {
	state.player.overall = calcOverall(state.player.position, state.player.attributes);
	state.player.cardStyle = cardFromOverall(state.player.overall);
	state.peakOverall = Math.max(state.peakOverall, state.player.overall);
}
function trainWeek(state, focus) {
	const rng = rngFrom(state);
	if (focus === "rest") {
		state.fitness = clamp(state.fitness + 14, 25, 100);
		state.morale = clamp(state.morale + 2, 10, 99);
		pushNews(state, "Semana de recuperacao. O corpo agradece.", "neutral");
		return;
	}
	state.fitness = clamp(state.fitness - (focus === "extra" ? 10 : 5), 20, 100);
	const age = state.player.age;
	const room = state.player.potential + 1 - state.player.overall;
	const speed = age <= 21 ? 1.15 : age <= 26 ? .7 : age <= 30 ? .3 : .08;
	if (focus === "extra") {
		const inj = maybeInjury(state, 1.4);
		if (inj) {
			state.injury = inj;
			pushNews(state, `Treino pesado demais: ${inj.name}.`, "bad");
			return;
		}
	}
	if (room > 0 && rng() < .62 * speed) {
		const key = focus === "extra" ? pick(rng, ATTR_KEYS) : focus;
		const bump = rng() > .85 && age <= 20 ? 2 : 1;
		state.player.attributes[key] = clamp(state.player.attributes[key] + bump, 25, 99);
		recalcOvr(state);
		pushNews(state, `Evolucao em ${keyLabel(key)}. Overall ${state.player.overall}.`, "good");
	} else state.form = clamp(state.form + 2, 20, 99);
}
function keyLabel(k) {
	return {
		pace: "ritmo",
		shooting: "finalizacao",
		passing: "passe",
		dribbling: "drible",
		defending: "defesa",
		physical: "fisico",
		vision: "QI de jogo"
	}[k];
}
function payWeek(state) {
	const sponsor = state.sponsorships.reduce((s, x) => s + x.weekly, 0);
	state.money += state.weeklyWage + sponsor;
}
function tickInjury(state) {
	if (!state.injury) return;
	state.injury.weeksLeft -= 1;
	state.fitness = clamp(state.fitness + 4, 20, 90);
	if (state.injury.weeksLeft <= 0) {
		pushNews(state, `Alta medica. ${state.injury.name} ficou para tras.`, "good");
		state.injury = null;
		state.morale = clamp(state.morale + 6, 10, 99);
	}
}
function estimatePlace(rep, playerSwing) {
	const quality = rep + playerSwing;
	return clamp(Math.round(18 - (quality - 64) / 2.1), 1, 20);
}
function seasonTitles(state) {
	const club = clubById(state.clubId);
	const rng = rngFrom(state);
	const swing = (state.seasonStats.avgRating - 6.5) * (state.seasonStats.appearances / 30) * 7;
	const place = estimatePlace(club.reputation, swing + (rng() - .5) * 4);
	state.leaguePlace = place;
	const titles = [];
	const mk = (name, type) => ({
		id: `${state.season}-${name}`,
		season: state.season,
		name,
		clubId: club.id,
		type
	});
	if (place === 1) titles.push(mk(club.league, "liga"));
	if (place <= 2 && club.countryCode === "BRA" && rng() > .65) titles.push(mk("Libertadores", "continental"));
	if (place <= 2 && club.reputation >= 90 && rng() > .7) titles.push(mk("Champions League", "continental"));
	if (place <= 4 && rng() > .72) titles.push(mk(club.countryCode === "BRA" ? "Copa do Brasil" : "Copa nacional", "copa"));
	if (state.seasonStats.goals >= 20 && state.player.position === "ST") titles.push(mk("Artilheiro", "individual"));
	if (state.seasonStats.avgRating >= 7.6 && state.seasonStats.appearances >= 22) titles.push(mk("Craque da temporada", "individual"));
	return titles;
}
function generateOffers(state, window) {
	const rng = rngFrom(state);
	const ovr = state.player.overall;
	const pot = state.player.potential;
	const fame = state.fame;
	const current = clubById(state.clubId);
	return CLUBS.filter((c) => c.id !== current.id).filter((c) => {
		const want = ovr + (pot - ovr) * .35 + fame * .08;
		if (c.reputation > want + 10) return false;
		if (c.reputation + 16 < ovr) return rng() > .7;
		return rng() > .42;
	}).sort(() => rng() - .5).slice(0, randInt(rng, 1, 4)).map((c) => {
		const role = roleFromGap(ovr, c.reputation);
		const wageMul = role === "estrela" ? .55 : role === "titular" ? .32 : role === "rotacao" ? .16 : .07;
		const wage = clamp(Math.round(c.wageBudget * wageMul * (.8 + rng() * .5)), 400, c.wageBudget);
		return {
			id: `off-${c.id}-${state.season}-${window}-${state.rngCount}-${rng()}`,
			clubId: c.id,
			wage,
			years: randInt(rng, 2, 5),
			shirtNumber: state.player.shirtNumber,
			role,
			signingBonus: Math.round(wage * randInt(rng, 8, 22)),
			window,
			releaseClause: Math.round(wage * randInt(rng, 70, 200))
		};
	});
}
function mergeCareerStats(state) {
	const c = state.stats;
	const s = state.seasonStats;
	c.appearances += s.appearances;
	c.starts += s.starts;
	c.minutes += s.minutes;
	c.goals += s.goals;
	c.assists += s.assists;
	c.cleanSheets += s.cleanSheets;
	c.yellows += s.yellows;
	c.reds += s.reds;
	c.motm += s.motm;
	c.wins += s.wins;
	c.draws += s.draws;
	c.losses += s.losses;
	const totalApp = c.appearances;
	c.ratingSum += s.ratingSum;
	c.avgRating = totalApp ? round1(c.ratingSum / totalApp) : 0;
	c.seasons += 1;
}
function agePlayer(state) {
	state.player.age += 1;
	const rng = rngFrom(state);
	const age = state.player.age;
	if (age >= 29) {
		const drop = age >= 34 ? 2 : 1;
		if (rng() > .35) state.player.attributes.pace = clamp(state.player.attributes.pace - drop, 25, 99);
		if (rng() > .5) state.player.attributes.physical = clamp(state.player.attributes.physical - 1, 25, 99);
		recalcOvr(state);
	}
	if (age >= 38 || age >= 35 && state.player.overall < 62 && rng() > .4) {
		state.retired = true;
		state.retireReason = age >= 38 ? "O corpo pediu a aposentadoria aos 38." : "Os clubes pararam de ligar. Fim de linha.";
	}
}
function endSeason(state) {
	const club = clubById(state.clubId);
	const cardFrom = state.player.cardStyle;
	const followersFrom = state.followers;
	const titles = seasonTitles(state);
	state.titles.push(...titles);
	for (const t of titles) {
		pushNews(state, `Titulo: ${t.name}.`, "good");
		state.fame = clamp(state.fame + (t.type === "individual" ? 5 : 8), 0, 100);
		state.money += t.type === "continental" ? 4e5 : t.type === "liga" ? 18e4 : 6e4;
		state.followers += t.type === "continental" ? 25e4 : t.type === "liga" ? 8e4 : 25e3;
	}
	const points = seasonPointsFor(state.seasonStats, titles.length);
	if (state.mode === "complete") state.seasonPoints += points;
	else autoSpend(state, points);
	recalcOvr(state);
	const rng = rngFrom(state);
	const under = state.seasonStats.avgRating < 6.15 && state.seasonStats.appearances >= 10 && club.reputation >= state.player.overall + 5 || state.seasonStats.appearances < 8 && state.player.age >= 19 && club.reputation > 82;
	const sacked = !state.retired && under && rng() > .42;
	if (sacked) {
		state.sacked = true;
		state.contractYearsLeft = 0;
		pushNews(state, `${club.name} rescindiu por baixo rendimento.`, "bad");
		state.morale = clamp(state.morale - 12, 10, 99);
	} else state.sacked = false;
	let raiseOffer = null;
	if (!sacked && state.seasonStats.avgRating >= 7.1 && rng() > .35) {
		raiseOffer = Math.round(state.weeklyWage * (1.12 + rng() * .2));
		state.pendingRaise = raiseOffer;
	} else state.pendingRaise = null;
	let brandOffer = null;
	if (state.fame >= 20 && state.sponsorships.length < 2 && rng() > .45) {
		brandOffer = {
			id: `br-${state.rngCount}`,
			brand: pick(rng, SPONSOR_BRANDS),
			weekly: Math.round(180 + state.fame * 45 * (.7 + rng() * .9)),
			seasonsLeft: 2,
			followersBoost: Math.round(8e3 + state.fame * 900)
		};
		state.pendingBrand = brandOffer;
	} else state.pendingBrand = null;
	const seasonHighlights = state.highlights.filter((h) => h.preview.week >= 1);
	const recap = {
		season: state.season,
		year: state.year,
		clubName: club.name,
		stats: { ...state.seasonStats },
		titles,
		overallFrom: state.overallAtSeasonStart,
		overallTo: state.player.overall,
		leaguePlace: state.leaguePlace,
		nextOffers: generateOffers(state, "fim"),
		points,
		highlights: seasonHighlights.slice(0, 6),
		sacked,
		raiseOffer,
		brandOffer,
		followersFrom,
		followersTo: Math.round(state.followers),
		cardFrom,
		cardTo: state.player.cardStyle
	};
	state.offers = recap.nextOffers;
	mergeCareerStats(state);
	state.seasonStats = emptySeasonStats();
	if (!sacked) state.contractYearsLeft -= 1;
	for (const sp of state.sponsorships) sp.seasonsLeft -= 1;
	state.sponsorships = state.sponsorships.filter((s) => s.seasonsLeft > 0);
	agePlayer(state);
	state.season += 1;
	state.year += 1;
	state.week = 1;
	state.overallAtSeasonStart = state.player.overall;
	state.fitness = 88;
	state.form = clamp(state.form, 40, 80);
	if ((state.contractYearsLeft <= 0 || sacked) && !state.retired) {
		pushNews(state, sacked ? "Voce esta livre. Escolhe o proximo clube." : "Contrato acabou. Escolhe a proxima camisa.", "transfer");
		if (state.offers.length === 0) state.offers = generateOffers(state, "fim");
		if (state.offers.length === 0) {
			const smaller = CLUBS.filter((c) => c.reputation <= state.player.overall + 4).sort((a, b) => b.reputation - a.reputation)[0];
			if (smaller) acceptOffer(state, {
				id: "free",
				clubId: smaller.id,
				wage: startingWage(state.player.overall, smaller),
				years: 2,
				shirtNumber: state.player.shirtNumber,
				role: "rotacao",
				signingBonus: 0,
				window: "fim",
				releaseClause: startingWage(state.player.overall, smaller) * 80
			});
		}
	}
	if (state.mode === "fast" && state.offers.length && !state.retired) {
		const current = clubById(state.clubId);
		const best = [...state.offers].sort((a, b) => clubById(b.clubId).reputation - clubById(a.clubId).reputation)[0];
		if (best && (sacked || state.contractYearsLeft <= 0 || clubById(best.clubId).reputation > current.reputation + 1)) acceptOffer(state, best);
	}
	state.highlights = [];
	if (state.retired) state.historyRank = careerRank(state);
	return recap;
}
function acceptOffer(state, offer) {
	const from = clubById(state.clubId);
	const to = clubById(offer.clubId);
	state.clubId = to.id;
	state.weeklyWage = offer.wage;
	state.contractYearsLeft = offer.years;
	state.contractYearsTotal = offer.years;
	state.releaseClause = offer.releaseClause;
	state.sacked = false;
	state.player.shirtNumber = offer.shirtNumber;
	state.money += offer.signingBonus;
	state.fame = clamp(state.fame + Math.max(0, (to.reputation - from.reputation) / 4), 0, 100);
	state.morale = clamp(state.morale + 8, 10, 99);
	if (!state.stats.clubs.includes(to.id)) state.stats.clubs.push(to.id);
	state.offers = [];
	pushNews(state, `Transferencia: ${from.name} → ${to.name}. ${offer.years} anos, ${formatMoney(offer.wage, to.countryCode)}/sem.`, "transfer");
}
function playWeek(state, choice) {
	if (state.retired) return {
		match: null,
		recap: null
	};
	tickInjury(state);
	payWeek(state);
	let match = null;
	if (!state.injury) {
		if (!state.pendingMatch) state.pendingMatch = buildFixture(state);
		match = simulateMatch(state, choice);
		applyMatchToState(state, match);
	} else {
		state.pendingMatch = null;
		state.form = clamp(state.form - 2, 20, 99);
	}
	if (state.week === 20 && state.offers.length === 0) {
		const mid = generateOffers(state, "meio");
		if (mid.length) {
			state.offers = mid;
			pushNews(state, `${mid.length} proposta(s) na janela do meio da temporada.`, "transfer");
		}
	}
	state.week += 1;
	if (state.week > 38) {
		const recap = endSeason(state);
		return {
			match,
			recap
		};
	}
	return {
		match,
		recap: null
	};
}
function simulateSeasonsTracked(state, years) {
	const overallFrom = state.player.overall;
	const fameFrom = state.fame;
	const money0 = state.money;
	const lines = [];
	for (let y = 0; y < years; y++) {
		if (state.retired) break;
		const clubId = state.clubId;
		const clubName = clubById(clubId).name;
		state.year;
		const seasonNo = state.season;
		const pos = state.player.position;
		let injuryWeeks = 0;
		while (state.week <= 38 && state.season === seasonNo && !state.retired) {
			if (state.injury) injuryWeeks += 1;
			const rng = rngFrom(state);
			const focus = state.fitness < 58 ? "rest" : pick(rng, [
				"shooting",
				"passing",
				"dribbling",
				"pace",
				"defending",
				"physical",
				"vision"
			]);
			if (!state.injury && state.week % 2 === 1) trainWeek(state, focus);
			const { recap } = playWeek(state, null);
			if (recap) {
				lines.push({
					season: recap.season,
					year: recap.year,
					clubId,
					clubName,
					position: pos,
					overall: recap.overallTo,
					appearances: recap.stats.appearances,
					goals: recap.stats.goals,
					assists: recap.stats.assists,
					avgRating: recap.stats.avgRating,
					titles: recap.titles.map((t) => t.name),
					wage: state.weeklyWage,
					fame: state.fame,
					injuryWeeks
				});
				break;
			}
		}
	}
	return {
		years: lines.length,
		lines,
		moneyGained: state.money - money0,
		overallFrom,
		overallTo: state.player.overall,
		fameFrom,
		fameTo: state.fame,
		nextOffers: state.offers
	};
}
function agentReply(state, intent) {
	const rng = rngFrom(state);
	const club = clubById(state.clubId);
	switch (intent) {
		case "raise":
			if ((state.seasonStats.avgRating >= 7.2 || state.fame > 45) && rng() < .55 + state.agentMood / 400) {
				const bump = Math.round(state.weeklyWage * (.12 + rng() * .18));
				state.weeklyWage += bump;
				state.agentMood = clamp(state.agentMood + 4, 10, 99);
				pushNews(state, `Aumento aprovado: +${formatMoney(bump, club.countryCode)}/sem.`, "good");
				return `Fechei. O clube topou ${formatMoney(state.weeklyWage, club.countryCode)} por semana. Nao estraga o momento.`;
			}
			state.agentMood = clamp(state.agentMood - 3, 10, 99);
			return "Agora nao. Joga tres partidas boas e eu volto na diretoria.";
		case "transfer": {
			const offers = generateOffers(state, state.week < 20 ? "meio" : "fim");
			state.offers = offers;
			if (!offers.length) return "Ninguem do seu nivel ligou. Espera a janela.";
			return `${offers.length} clube(s) na mesa. Voce so escolhe sim ou nao.`;
		}
		case "sponsor": {
			if (state.fame < 22) return "Patrocinio pesado exige fama. Marca gols, aparece, depois a gente cobra a Nike.";
			if (state.sponsorships.length >= 2) return "Ja temos contratos no limite. Cumpre esses primeiro.";
			const brand = pick(rng, SPONSOR_BRANDS);
			const weekly = Math.round(200 + state.fame * 40 * (.7 + rng() * .8));
			const sp = {
				id: `sp-${state.rngCount}`,
				brand,
				weekly,
				seasonsLeft: 2,
				followersBoost: Math.round(5e3 + state.fame * 700)
			};
			state.sponsorships.push(sp);
			state.followers += sp.followersBoost;
			pushNews(state, `${brand} no peito. ${formatMoney(weekly, club.countryCode)}/sem.`, "good");
			return `${brand} fechou. ${formatMoney(weekly, club.countryCode)} por semana, duas temporadas.`;
		}
		case "loan": {
			const smaller = CLUBS.filter((c) => c.id !== club.id && c.reputation < club.reputation - 6 && c.reputation > state.player.overall - 12);
			if (!smaller.length) return "Nao tem emprestimo que faça sentido agora.";
			const dest = pick(rng, smaller);
			state.offers = [{
				id: `loan-${dest.id}`,
				clubId: dest.id,
				wage: Math.round(state.weeklyWage * .85),
				years: 1,
				shirtNumber: state.player.shirtNumber,
				role: "titular",
				signingBonus: 0,
				window: "meio",
				releaseClause: Math.round(state.weeklyWage * 40)
			}];
			return `${dest.name} topa te pegar por uma temporada para jogar toda semana. E um emprestimo na pratica.`;
		}
		case "number": return "Numero e vaidade, mas vaidade vende camisa. Escolhe ai que eu resolvo com o departamento.";
		case "position": {
			const chance = (state.player.age <= 21 ? .72 : .42) + (state.player.overall >= 78 ? .12 : 0) + state.agentMood / 500;
			if (rng() > chance) {
				state.agentMood = clamp(state.agentMood - 2, 10, 99);
				return "O tecnico nao topa agora. Joga onde ele mandar mais um pouco.";
			}
			return "Ele aceita conversar. Confirma a nova posicao ai embaixo que eu fecho.";
		}
		case "resign": {
			const cost = Math.round(state.releaseClause * .35);
			if (state.money < cost) return `Rescisao custa ${formatMoney(cost, club.countryCode)}. Sem fortuna para isso.`;
			if (rng() < .35) return "O clube nao abre a porta agora.";
			state.money -= cost;
			state.contractYearsLeft = 0;
			state.offers = generateOffers(state, "fim");
			pushNews(state, "Rescisao paga. Voce esta livre.", "transfer");
			return "Paguei a multa. Escolhe o proximo clube.";
		}
	}
}
function tryChangePosition(state, position) {
	if (position === state.player.position) return "Ja e essa posicao.";
	const rng = rngFrom(state);
	const chance = (state.player.age <= 22 ? .7 : .38) + (state.player.overall >= 78 ? .12 : 0);
	if (rng() > chance) {
		state.agentMood = clamp(state.agentMood - 3, 10, 99);
		pushNews(state, "Pedido de nova posicao recusado.", "neutral");
		return "O tecnico recusou. Sorte nao veio. Tenta de novo depois de uma temporada boa.";
	}
	changePosition(state, position);
	return `Fechado. Voce vira ${position}. Overall agora ${state.player.overall}.`;
}
function changePosition(state, position) {
	if (position === state.player.position) return;
	state.player.position = position;
	recalcOvr(state);
	state.morale = clamp(state.morale - 4, 10, 99);
	pushNews(state, `Nova posicao: ${position}. Overall agora ${state.player.overall}.`, "neutral");
}
function cloneState(state) {
	return structuredClone(state);
}
function seasonPointsFor(stats, titles) {
	const raw = stats.appearances * .12 + stats.goals * .55 + stats.assists * .45 + Math.max(0, stats.avgRating - 6) * 7 + stats.motm * 1.2 + titles * 5;
	return clamp(Math.round(raw), 4, 26);
}
function spendPoint(state, attr) {
	if (state.seasonPoints <= 0) return false;
	const cap = Math.min(99, state.player.potential + 3);
	if (state.player.attributes[attr] >= cap) return false;
	state.player.attributes[attr] += 1;
	state.seasonPoints -= 1;
	recalcOvr(state);
	return true;
}
function autoSpend(state, points) {
	const w = POSITION_WEIGHTS[state.player.position];
	const ranked = [...ATTR_KEYS].sort((a, b) => w[b] - w[a]);
	let left = points;
	let guard = 0;
	while (left > 0 && guard < 80) {
		guard += 1;
		const key = ranked[guard % ranked.length];
		const cap = Math.min(99, state.player.potential + 3);
		if (state.player.attributes[key] >= cap) {
			left -= 1;
			continue;
		}
		state.player.attributes[key] += 1;
		left -= 1;
	}
	recalcOvr(state);
}
function acceptRaise(state) {
	if (!state.pendingRaise) return;
	state.weeklyWage = state.pendingRaise;
	state.pendingRaise = null;
	pushNews(state, "Aumento aceito.", "good");
}
function rejectRaise(state) {
	state.pendingRaise = null;
}
function acceptBrand(state) {
	if (!state.pendingBrand) return;
	state.sponsorships.push(state.pendingBrand);
	state.followers += state.pendingBrand.followersBoost;
	pushNews(state, `Publi: ${state.pendingBrand.brand}.`, "good");
	state.pendingBrand = null;
}
function rejectBrand(state) {
	state.pendingBrand = null;
}
function simulateSeason(state) {
	if (state.retired) return null;
	const start = state.season;
	let last = null;
	for (let i = 0; i < 42; i++) {
		const { recap } = playWeek(state, null);
		if (recap) {
			last = recap;
			break;
		}
		if (state.season !== start) break;
	}
	return last;
}
function careerRank(state) {
	const titles = state.titles.length;
	const champs = state.titles.filter((t) => t.type === "continental").length;
	const peak = state.peakOverall;
	const fame = state.fame;
	if (peak >= 90 || titles >= 8 || champs >= 2) return {
		id: "lenda",
		label: "Lenda",
		copy: "Nome gravado. Os moleques vao copiar a comemoracao."
	};
	if (peak >= 86 || titles >= 5) return {
		id: "fenomeno",
		label: "Fenomeno",
		copy: "Pico absurdo. Uma geracao inteira discute voce."
	};
	if (peak >= 80 || titles >= 3 || fame >= 72) return {
		id: "craque",
		label: "Craque",
		copy: "Decide jogo grande. Camisa pesada, carreira limpa."
	};
	if (peak >= 74 || titles >= 1 || fame >= 50) return {
		id: "astro",
		label: "Astro",
		copy: "Virou cara de cartaz. Nao e eterno, mas brilhou."
	};
	if (state.stats.appearances >= 180) return {
		id: "profissional",
		label: "Profissional",
		copy: "Comeu po, cumpriu contrato, construiu fortuna."
	};
	return {
		id: "promessa",
		label: "Promessa",
		copy: "O talento existia. A carreira nao fechou a conta."
	};
}
function coachRankOf(titles, years) {
	if (titles >= 8 || titles >= 5 && years <= 10) return {
		id: "lenda-banco",
		label: "Lenda do banco",
		copy: "Virou escola. Outros tecnicos copiam o seu quadro."
	};
	if (titles >= 4) return {
		id: "vencedor",
		label: "Tecnico vencedor",
		copy: "Ganhou o que tinha que ganhar. Ninguem discute o curriculo."
	};
	if (titles >= 1) return {
		id: "competente",
		label: "Tecnico competente",
		copy: "Entregou titulo e sobreviveu a janela. Carreira honesta."
	};
	return {
		id: "passagem",
		label: "Passagem",
		copy: "Rodou clubes, quase levantou taca. O banco nao perdoou."
	};
}
function lifeVerdictOf(state) {
	const p = state.historyRank?.id ?? careerRank(state).id;
	const c = state.coach?.rank.id;
	if (!c) {
		if (p === "lenda" || p === "fenomeno") return "Jogador para a historia. Nao quis o banco.";
		if (p === "craque" || p === "astro") return "Brilhou em campo. A segunda carreira ficou em branco.";
		return "A chuteira falou mais alto que o apito. Historia incompleta no banco.";
	}
	if ((p === "lenda" || p === "fenomeno") && (c === "lenda-banco" || c === "vencedor")) return "Lenda em campo e lenda no banco. Carreira completa.";
	if ((p === "lenda" || p === "fenomeno") && c === "passagem") return "Genio com a bola, comum com o apito. O campo foi maior.";
	if ((p === "promessa" || p === "profissional") && (c === "lenda-banco" || c === "vencedor")) return "O jogador foi honesto. O tecnico foi grande.";
	if (p === "craque" && (c === "vencedor" || c === "lenda-banco")) return "Craque que ainda mandou no vestiario. Dois curriculos pesados.";
	if (c === "passagem") return "Jogou, treinou, passou. Falta uma taca que feche o livro.";
	return "Boa vida nos dois lados da linha. Nem lenda eterna, nem esquecido.";
}
function simulateCoachCareer(state) {
	const rng = rngFrom(state);
	const years = randInt(rng, 8, 14);
	const lines = [];
	let titles = 0;
	let club = clubById(state.clubId);
	const famePull = 60 + state.fame * .35 + Math.max(0, state.peakOverall - 72);
	const pool = [...CLUBS].sort((a, b) => Math.abs(a.reputation - famePull) - Math.abs(b.reputation - famePull));
	for (let i = 0; i < years; i++) {
		if (i === 0 || rng() > .62) club = pick(rng, pool.slice(0, 14));
		const boost = clamp(state.peakOverall - 70, 0, 18) + (state.historyRank?.id === "lenda" ? 4 : 0);
		const place = clamp(Math.round(10 - boost / 4 + (rng() - .5) * 8), 1, 18);
		const won = [];
		if (place === 1) {
			won.push(club.league);
			titles += 1;
		}
		if (place <= 3 && rng() > .7) {
			won.push(club.countryCode === "BRA" ? "Copa do Brasil" : "Copa nacional");
			titles += 1;
		}
		if (place === 1 && club.reputation >= 88 && rng() > .75) {
			won.push(club.countryCode === "BRA" ? "Libertadores" : "Champions League");
			titles += 1;
		}
		lines.push({
			year: state.year + i,
			clubName: club.name,
			place,
			titles: won
		});
	}
	const rank = coachRankOf(titles, years);
	const coach = {
		active: true,
		years,
		lines,
		titles,
		rank
	};
	state.coach = coach;
	if (!state.historyRank) state.historyRank = careerRank(state);
	state.lifeVerdict = lifeVerdictOf(state);
	return coach;
}
function retireNow(state) {
	state.retired = true;
	state.retireReason = `Pendurou as chuteiras aos ${state.player.age}.`;
	state.historyRank = careerRank(state);
}
var YOU_TEXT = {
	raise: "Quero aumento.",
	transfer: "Me coloca no mercado. Eu so aceito ou recuso clube.",
	sponsor: "Busca uma marca. Publi e seguidor.",
	loan: "Se eu nao jogo, me empresta.",
	number: "Quero trocar o numero da camisa.",
	resign: "Quero a rescisao. Pago a multa se precisar."
};
var useCareer = create()(persist((set, get) => ({
	game: null,
	screen: "landing",
	recap: null,
	fastRecap: null,
	agentLog: [],
	toast: null,
	createCareer: (payload) => {
		set({
			game: createCareer(payload),
			screen: "hub",
			recap: null,
			fastRecap: null,
			agentLog: [{
				id: "hello",
				from: "agent",
				text: `Fala, ${payload.name.split(" ")[0]}. Eu fecho contrato. Voce so diz sim ou nao.`
			}],
			toast: "Base sorteada. Cartinha bronze. Agora e trabalho."
		});
	},
	setScreen: (screen) => set({ screen }),
	simulateSeason: () => {
		const game = get().game;
		if (!game || game.retired) return;
		const next = cloneState(game);
		const recap = simulateSeason(next);
		if (next.retired) {
			set({
				game: next,
				screen: "retired",
				recap,
				toast: next.retireReason
			});
			return;
		}
		if (recap) {
			set({
				game: next,
				recap,
				screen: "season-recap"
			});
			return;
		}
		set({
			game: next,
			screen: "hub"
		});
	},
	simulateCareer: () => {
		const game = get().game;
		if (!game || game.retired) return;
		const next = cloneState(game);
		set({
			game: next,
			fastRecap: simulateSeasonsTracked(next, Math.max(1, 38 - next.player.age)),
			screen: next.retired ? "retired" : "fast-recap"
		});
	},
	spend: (attr) => {
		const game = get().game;
		if (!game) return;
		const next = cloneState(game);
		if (!spendPoint(next, attr)) return;
		set({ game: next });
	},
	accept: (offer) => {
		const game = get().game;
		if (!game) return;
		const next = cloneState(game);
		acceptOffer(next, offer);
		set({
			game: next,
			screen: "hub",
			toast: next.news[0]?.text ?? "Transferencia fechada."
		});
	},
	rejectAll: () => {
		const game = get().game;
		if (!game) return;
		const next = cloneState(game);
		next.offers = [];
		set({
			game: next,
			screen: "hub",
			toast: "Propostas recusadas."
		});
	},
	yesRaise: () => {
		const game = get().game;
		if (!game) return;
		const next = cloneState(game);
		acceptRaise(next);
		set({
			game: next,
			toast: "Aumento aceito."
		});
	},
	noRaise: () => {
		const game = get().game;
		if (!game) return;
		const next = cloneState(game);
		rejectRaise(next);
		set({ game: next });
	},
	yesBrand: () => {
		const game = get().game;
		if (!game) return;
		const next = cloneState(game);
		acceptBrand(next);
		set({
			game: next,
			toast: "Publi fechada."
		});
	},
	noBrand: () => {
		const game = get().game;
		if (!game) return;
		const next = cloneState(game);
		rejectBrand(next);
		set({ game: next });
	},
	talkAgent: (intent) => {
		const game = get().game;
		if (!game) return;
		if (intent === "offers") {
			set({ screen: "offers" });
			return;
		}
		if (intent === "position") return;
		const next = cloneState(game);
		const reply = agentReply(next, intent);
		set({
			game: next,
			agentLog: [
				...get().agentLog,
				{
					id: `y-${next.rngCount}`,
					from: "you",
					text: YOU_TEXT[intent]
				},
				{
					id: `a-${next.rngCount}`,
					from: "agent",
					text: reply
				}
			].slice(-16),
			screen: intent === "transfer" || intent === "loan" || intent === "resign" ? next.offers.length ? "offers" : "agent" : "agent",
			toast: next.news[0]?.text
		});
	},
	setNumber: (n) => {
		const game = get().game;
		if (!game) return;
		const next = cloneState(game);
		next.player.shirtNumber = Math.max(1, Math.min(99, Math.round(n)));
		set({
			game: next,
			toast: `Camisa ${next.player.shirtNumber}.`
		});
	},
	requestPosition: (p) => {
		const game = get().game;
		if (!game) return;
		const next = cloneState(game);
		const reply = tryChangePosition(next, p);
		set({
			game: next,
			agentLog: [
				...get().agentLog,
				{
					id: `y-${next.rngCount}`,
					from: "you",
					text: `Quero jogar de ${p}.`
				},
				{
					id: `a-${next.rngCount}`,
					from: "agent",
					text: reply
				}
			].slice(-16),
			toast: reply
		});
	},
	becomeCoach: () => {
		const game = get().game;
		if (!game) return;
		const next = cloneState(game);
		if (!next.retired) retireNow(next);
		simulateCoachCareer(next);
		set({
			game: next,
			screen: "coach"
		});
	},
	hangBoots: () => {
		const game = get().game;
		if (!game) return;
		const next = cloneState(game);
		retireNow(next);
		set({
			game: next,
			screen: "retired"
		});
	},
	newGame: () => set({
		game: null,
		screen: "create",
		recap: null,
		fastRecap: null,
		agentLog: [],
		toast: null
	}),
	clearToast: () => set({ toast: null })
}), {
	name: "lenda-career-v3",
	version: 3,
	storage: createJSONStorage(() => localStorage),
	partialize: (s) => ({
		game: s.game,
		screen: s.screen,
		agentLog: s.agentLog
	}),
	skipHydration: true
}));
function AgentPanel({ game }) {
	const talk = useCareer((s) => s.talkAgent);
	const log = useCareer((s) => s.agentLog);
	const setNumber = useCareer((s) => s.setNumber);
	const requestPosition = useCareer((s) => s.requestPosition);
	const [number, setNum] = (0, import_react.useState)(game.player.shirtNumber);
	const [pos, setPos] = (0, import_react.useState)(game.player.position);
	const club = clubById(game.clubId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4 pb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.2em] text-gold",
					children: "Empresario"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl text-fg",
					children: "Rafa Moreira"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Humor ",
						game.agentMood,
						" · ",
						club.name,
						" · ",
						formatMoney(game.weeklyWage, club.countryCode),
						"/sem"
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex max-h-72 flex-col gap-2 overflow-y-auto rounded-xl bg-surface p-3 panel",
				children: log.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Manda um recado. Eu resolvo o resto. Voce so diz sim ou nao."
				}) : log.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("max-w-[90%] rounded-lg px-3 py-2 text-sm leading-relaxed", m.from === "you" ? "ml-auto bg-gold/15 text-fg" : "bg-surface-2 text-fg"),
					children: m.text
				}, m.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Talk, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banknote, { className: "size-4" }),
						label: "Pedir aumento",
						onClick: () => talk("raise")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Talk, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeftRight, { className: "size-4" }),
						label: "Quero sair",
						onClick: () => talk("transfer")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Talk, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "size-4" }),
						label: "Patrocinio",
						onClick: () => talk("sponsor")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Talk, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plane, { className: "size-4" }),
						label: "Emprestimo",
						onClick: () => talk("loan")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Talk, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4" }),
						label: "Ver propostas",
						onClick: () => talk("offers")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Talk, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DoorOpen, { className: "size-4" }),
						label: "Rescisao",
						onClick: () => talk("resign")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface p-4 panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted",
						children: "Numero da camisa"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 1,
							max: 99,
							value: number,
							onChange: (e) => setNum(Number(e.target.value))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: () => setNumber(number),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hash, { className: "size-4" }), "Aplicar"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs uppercase tracking-wider text-muted",
						children: "Pedir nova posicao"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[11px] text-muted",
						children: "O tecnico pode recusar. E sorte."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex flex-wrap gap-1.5",
						children: POSITIONS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setPos(p.id),
							className: cn("h-9 rounded-md px-2.5 text-xs", pos === p.id ? "bg-gold text-gold-fg" : "bg-surface-2 text-fg"),
							children: p.id
						}, p.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "mt-3 w-full",
						variant: "outline",
						onClick: () => requestPosition(pos),
						disabled: pos === game.player.position,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }),
							"Pedir ",
							pos
						]
					})
				]
			})
		]
	});
}
function Talk({ icon, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex h-14 items-center gap-2 rounded-xl bg-surface px-3 text-left text-sm text-fg panel",
		children: [icon, label]
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium tracking-wide uppercase", {
	variants: { variant: {
		default: "bg-surface-2 text-muted",
		gold: "bg-gold/15 text-gold",
		pitch: "bg-pitch/15 text-pitch",
		danger: "bg-danger/15 text-danger",
		warn: "bg-warn/15 text-warn"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({
			variant,
			className
		})),
		...props
	});
}
function ClubBadge({ clubId, size = "md", className }) {
	const club = clubById(clubId);
	const src = clubLogo(clubId);
	const [failed, setFailed] = (0, import_react.useState)(false);
	const dim = size === "sm" ? "size-8" : size === "lg" ? "size-14" : "size-10";
	if (src && !failed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: club.name,
		className: cn("object-contain", dim, className),
		onError: () => setFailed(true)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center justify-center rounded-md text-[10px] font-bold", dim, className),
		style: {
			background: club.colors[0],
			color: club.colors[1]
		},
		children: club.shortName.slice(0, 3)
	});
}
function CareerView({ game }) {
	const club = clubById(game.clubId);
	const s = game.stats;
	const t = game.seasonStats;
	const hangBoots = useCareer((x) => x.hangBoots);
	const newGame = useCareer((x) => x.newGame);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 pb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.2em] text-gold",
					children: "Livro de ouro"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl text-fg",
					children: "Carreira"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Pico ",
						game.peakOverall,
						" · ",
						game.player.idolName,
						" · ",
						game.player.cardStyle
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile$1, {
						k: "Jogos",
						v: s.appearances + t.appearances
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile$1, {
						k: "Gols",
						v: s.goals + t.goals
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile$1, {
						k: "Assistencias",
						v: s.assists + t.assists
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile$1, {
						k: "Nota media",
						v: (s.avgRating || t.avgRating || 0).toFixed(2)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile$1, {
						k: "Titulos",
						v: game.titles.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile$1, {
						k: "Fortuna",
						v: formatFortune(game.money)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile$1, {
						k: "Seguidores",
						v: formatFollowers(game.followers)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile$1, {
						k: "Fama",
						v: Math.round(game.fame)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-4 panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted",
						children: "Temporada atual"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-fg",
						children: [
							t.appearances,
							" jogos · ",
							t.goals,
							" gols · ",
							t.assists,
							" assist. · media ",
							t.avgRating.toFixed(1)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							t.wins,
							"V ",
							t.draws,
							"E ",
							t.losses,
							"D · salario ",
							formatMoney(game.weeklyWage, club.countryCode)
						]
					})
				]
			}),
			game.lastMatch ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-4 panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted",
						children: "Ultima partida"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-fg",
						children: [
							game.lastMatch.playerTeam,
							" ",
							game.lastMatch.goalsFor,
							"–",
							game.lastMatch.goalsAgainst,
							" ",
							game.lastMatch.opponent
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							"nota ",
							game.lastMatch.rating.toFixed(1),
							" · ",
							game.lastMatch.minutes,
							"' · ",
							game.lastMatch.competition
						]
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 text-xs uppercase tracking-wider text-muted",
				children: "Patrocinios"
			}), game.sponsorships.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Nenhum contrato de imagem. Fala com o empresario."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: game.sponsorships.map((sp) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between rounded-lg bg-surface px-3 py-2 text-sm panel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: sp.brand }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums text-muted",
						children: [
							formatMoney(sp.weekly, club.countryCode),
							"/sem · ",
							sp.seasonsLeft,
							" temp."
						]
					})]
				}, sp.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 text-xs uppercase tracking-wider text-muted",
				children: "Clubes"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: game.stats.clubs.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1.5 rounded-full bg-surface px-2 py-1 panel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubBadge, {
						clubId: id,
						size: "sm"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: clubById(id).shortName })]
				}, id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 text-xs uppercase tracking-wider text-muted",
				children: "Titulos"
			}), game.titles.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Ainda nada na vitrine. Temporada longa."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: game.titles.map((title) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between rounded-lg bg-surface px-3 py-2 panel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-fg",
						children: title.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted",
						children: ["T", title.season]
					})]
				}, title.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "w-full",
				onClick: hangBoots,
				children: "Pendurar as chuteiras"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				className: "w-full",
				onClick: newGame,
				children: "Nova carreira"
			})
		]
	});
}
function Tile$1({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface px-3 py-3 panel",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] uppercase tracking-wider text-muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl tabular-nums text-fg",
			children: v
		})]
	});
}
var SKIN = [
	"#f3d2b5",
	"#e0b184",
	"#c68642",
	"#8d5524",
	"#4a2c14"
];
var HAIR = [
	"#1a120c",
	"#2b1b10",
	"#4a2e14",
	"#111111",
	"#3d2a1a"
];
function PlayerFace({ appearance, className }) {
	if (appearance.photo) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: appearance.photo,
		alt: "",
		className: cn("h-full w-full object-cover", className)
	});
	const skin = SKIN[appearance.skin] ?? SKIN[2];
	const hair = HAIR[appearance.skin] ?? HAIR[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 80 96",
		className: cn("h-full w-auto", className),
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "40",
				cy: "90",
				rx: "22",
				ry: "10",
				fill: skin,
				opacity: "0.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "40",
				cy: "44",
				rx: "22",
				ry: "28",
				fill: skin
			}),
			appearance.hair !== "buzz" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: appearance.hair === "long" ? "M18 40c2-22 14-32 22-32s20 10 22 32c-6-10-14-14-22-14s-16 4-22 14z" : appearance.hair === "curly" ? "M16 38c0-18 10-28 24-28s24 10 24 28c-5-8-12-12-24-12s-19 4-24 12z" : appearance.hair === "fade" ? "M20 36c2-16 10-24 20-24s18 8 20 24H20z" : "M18 34c2-14 12-22 22-22s20 8 22 22H18z",
				fill: hair
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "40",
				cy: "20",
				rx: "18",
				ry: "8",
				fill: hair
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "42",
				r: "2.2",
				fill: "#1a1a1a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "48",
				cy: "42",
				r: "2.2",
				fill: "#1a1a1a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M36 52c2 2 6 2 8 0",
				fill: "none",
				stroke: "#5c3a28",
				strokeWidth: "1.4",
				strokeLinecap: "round"
			}),
			appearance.facial !== "none" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: appearance.facial === "beard" ? "M28 54c2 12 8 16 12 16s10-4 12-16c-4 6-8 8-12 8s-8-2-12-8z" : "M34 56c2 4 4 5 6 5s4-1 6-5",
				fill: hair,
				opacity: "0.85"
			}) : null
		]
	});
}
function resizePhoto(file) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		const url = URL.createObjectURL(file);
		img.onload = () => {
			const canvas = document.createElement("canvas");
			const size = 256;
			canvas.width = size;
			canvas.height = size;
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				reject(/* @__PURE__ */ new Error("canvas"));
				return;
			}
			const min = Math.min(img.width, img.height);
			const sx = (img.width - min) / 2;
			const sy = (img.height - min) / 2;
			ctx.drawImage(img, sx, sy, min, min, 0, 0, size, size);
			URL.revokeObjectURL(url);
			resolve(canvas.toDataURL("image/jpeg", .72));
		};
		img.onerror = () => reject(/* @__PURE__ */ new Error("image"));
		img.src = url;
	});
}
var STYLE = {
	bronze: "from-[#5c3d24] to-[#c4a074] text-[#2a1a0c]",
	silver: "from-[#4d555e] to-[#d5dde6] text-[#1c2228]",
	gold: "from-[#6e5614] to-[#f0d36a] text-[#1a1406]",
	rare: "from-[#1a2a22] to-[#c9a227] text-[#0d120f]",
	fenomeno: "from-[#0b0f0c] via-[#1d3a28] to-[#e4c15a] text-[#f4f7f4]"
};
function PlayerCard({ player, clubId, compact = false, className }) {
	const nation = nationById(player.nationId);
	const club = clubId ? clubById(clubId) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("relative overflow-hidden rounded-xl bg-linear-to-b p-3 shadow-[0_0_0_1px_rgba(255,255,255,0.08)]", STYLE[player.cardStyle], compact ? "w-[168px]" : "w-[228px]", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 opacity-30 mix-blend-overlay card-sheen" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-4xl font-extrabold leading-none tabular-nums",
					children: player.overall
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 text-xs font-semibold tracking-[0.18em]",
					children: player.position
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-end gap-1",
					children: [clubId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubBadge, {
						clubId,
						size: "sm"
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] font-semibold uppercase tracking-widest opacity-80",
						children: player.cardStyle
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("mx-auto my-2 overflow-hidden rounded-md", compact ? "h-16 w-16" : "h-28 w-28"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerFace, { appearance: player.appearance })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("text-center font-display uppercase tracking-wide", compact ? "text-base" : "text-xl"),
				children: player.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-0.5 text-center text-[10px] font-medium uppercase tracking-[0.16em] opacity-80",
				children: [
					player.playStyle,
					" · #",
					player.shirtNumber
				]
			}),
			!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-x-3 gap-y-1 text-[11px] font-semibold tabular-nums",
				children: [[
					["pace", "shooting"],
					["passing", "dribbling"],
					["defending", "physical"]
				].flat().map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between border-b border-current/15 pb-0.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "opacity-70",
						children: ATTR_LABELS[k].short
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: player.attributes[k] })]
				}, k)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "col-span-2 flex items-baseline justify-between border-b border-current/15 pb-0.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "opacity-70",
						children: ATTR_LABELS.vision.short
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: player.attributes.vision })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center justify-between text-[10px] font-semibold uppercase tracking-wider opacity-80",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: nation.code }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: club?.shortName ?? "LIVRE" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [player.age, "a"] })
				]
			})
		]
	});
}
var TICKER = [...LEGENDS.map((l) => l.name), ...LEGENDS.map((l) => l.name)];
function Landing() {
	const game = useCareer((s) => s.game);
	const setScreen = useCareer((s) => s.setScreen);
	const newGame = useCareer((s) => s.newGame);
	const featured = FEATURED_LANDING.map((id) => LEGENDS.find((l) => l.id === id)).filter(Boolean);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative flex min-h-dvh flex-col overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/landing-stadium.jpg",
				alt: "",
				className: "absolute inset-0 h-full w-full object-cover object-[center_30%]"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[linear-gradient(180deg,rgba(8,11,9,0.35)_0%,rgba(8,11,9,0.55)_38%,rgba(8,11,9,0.92)_72%,#080b09_100%)]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "grain pointer-events-none absolute inset-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 flex min-h-dvh flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden border-b border-white/10 bg-black/25 py-2 backdrop-blur-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "marquee flex w-max gap-8 whitespace-nowrap text-[11px] font-medium uppercase tracking-[0.22em] text-gold",
						children: TICKER.map((name, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: name }, `${name}-${i}`))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-lg flex-1 flex-col justify-end px-5 pb-10 pt-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.28em] text-gold",
							children: "Simulador de carreira"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display mt-2 text-7xl font-extrabold leading-none tracking-tight text-fg",
							children: "LENDA"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-sm text-sm leading-relaxed text-muted",
							children: "16 anos, bronze, base sorteada. Idolo, roubo de habilidades e um pouco de sorte. O resto e sim ou nao."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 flex gap-3 overflow-x-auto pb-1",
							children: featured.slice(0, 6).map((l) => l ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "relative h-36 w-24 shrink-0 overflow-hidden rounded-lg shadow-[0_0_0_1px_rgba(228,193,90,0.35)]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: legendArt(l),
										alt: "",
										className: "h-full w-full object-cover"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute inset-x-0 bottom-0 p-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-display text-lg leading-none text-gold",
											children: l.number
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-0.5 truncate text-[10px] font-medium uppercase tracking-wide text-fg",
											children: l.name.split(" ").slice(-1)
										})]
									})
								]
							}, l.id) : null)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-7 flex flex-col gap-3",
							children: [game && !game.retired ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "lg",
								className: "w-full",
								onClick: () => setScreen("hub"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), "Continuar carreira"]
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "lg",
								variant: game ? "outline" : "default",
								className: "w-full",
								onClick: newGame,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Nova carreira"]
							})]
						})
					]
				})]
			})
		]
	});
}
function PitchBackdrop() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"aria-hidden": true,
		className: "pointer-events-none absolute inset-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/landing-stadium.jpg",
				alt: "",
				className: "absolute inset-0 h-full w-full object-cover opacity-25"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(61,204,115,0.12),transparent_55%),linear-gradient(180deg,rgba(8,11,9,0.7),#080b09)]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				className: "absolute inset-0 h-full w-full opacity-[0.1]",
				viewBox: "0 0 100 180",
				preserveAspectRatio: "none",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "6",
						y: "8",
						width: "88",
						height: "164",
						fill: "none",
						stroke: "currentColor",
						className: "text-pitch",
						strokeWidth: "0.6"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "6",
						y1: "90",
						x2: "94",
						y2: "90",
						stroke: "currentColor",
						className: "text-pitch",
						strokeWidth: "0.5"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "50",
						cy: "90",
						r: "14",
						fill: "none",
						stroke: "currentColor",
						className: "text-pitch",
						strokeWidth: "0.5"
					})
				]
			})
		]
	});
}
var HAIRS = [
	"buzz",
	"short",
	"fade",
	"long",
	"curly"
];
var FACIAL = [
	"none",
	"stubble",
	"beard"
];
function CreatePlayer() {
	const create = useCareer((s) => s.createCareer);
	const setScreen = useCareer((s) => s.setScreen);
	const [step, setStep] = (0, import_react.useState)(0);
	const [name, setName] = (0, import_react.useState)("Gabriel Silva");
	const [nationId, setNationId] = (0, import_react.useState)("bra");
	const [position, setPosition] = (0, import_react.useState)("ST");
	const [shirt, setShirt] = (0, import_react.useState)(9);
	const [mode, setMode] = (0, import_react.useState)("complete");
	const [idolId, setIdolId] = (0, import_react.useState)("");
	const [appearance, setAppearance] = (0, import_react.useState)({
		skin: 2,
		hair: "short",
		facial: "none",
		photo: null
	});
	const [seed] = (0, import_react.useState)(() => Math.floor(Math.random() * 1e9));
	const idols = idolsFor(position);
	const chosenIdol = idols.find((l) => l.id === idolId) ?? idols[0];
	const academy = (0, import_react.useMemo)(() => rollAcademy(nationId, seed), [nationId, seed]);
	const player = (0, import_react.useMemo)(() => rollPlayer({
		name,
		nationId,
		position,
		shirtNumber: shirt,
		idolId: chosenIdol?.id,
		appearance,
		seed
	}), [
		name,
		nationId,
		position,
		shirt,
		chosenIdol?.id,
		appearance,
		seed
	]);
	const steps = [
		"Identidade",
		"Nacao",
		"Posicao",
		"Idolo",
		"Sorte",
		"Modo"
	];
	function next() {
		if (step === 2 && !idolId) setIdolId(idols[0]?.id ?? "");
		if (step < steps.length - 1) setStep(step + 1);
		else create({
			name: name.trim() || "Jogador",
			nationId,
			position,
			shirtNumber: shirt,
			clubId: academy.id,
			mode,
			player: {
				...player,
				name: name.trim() || "Jogador",
				appearance,
				idolId: chosenIdol?.id ?? player.idolId,
				idolName: chosenIdol?.name ?? player.idolName
			}
		});
	}
	async function onPhoto(file) {
		if (!file) return;
		const photo = await resizePhoto(file);
		setAppearance((a) => ({
			...a,
			photo
		}));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative mx-auto flex min-h-dvh max-w-lg flex-col px-4 pb-28 pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PitchBackdrop, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "mb-4 flex h-11 items-center gap-1 text-sm text-muted",
						onClick: () => step === 0 ? setScreen("landing") : setStep(step - 1),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), "Voltar"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.22em] text-gold",
						children: "Nova carreira"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-1 text-3xl text-fg",
						children: steps[step]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex gap-1.5",
						children: steps.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-1 flex-1 rounded-full", i <= step ? "bg-gold" : "bg-surface-2") }, i))
					}),
					step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-6 space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1.5 block text-xs uppercase tracking-wider text-muted",
									children: "Nome"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: name,
									onChange: (e) => setName(e.target.value),
									maxLength: 28
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-24 overflow-hidden rounded-xl border border-border bg-surface",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerFace, { appearance })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-1 flex-col gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex h-11 cursor-pointer items-center justify-center gap-2 rounded-md border border-border bg-surface text-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" }),
											"Colocar foto",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "file",
												accept: "image/*",
												className: "hidden",
												onChange: (e) => void onPhoto(e.target.files?.[0])
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										variant: "outline",
										className: "h-11 w-full",
										onClick: () => setAppearance((a) => ({
											...a,
											photo: null
										})),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-4" }), appearance.photo ? "Retirar foto · 2D" : "Personagem 2D"]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-xs uppercase tracking-wider text-muted",
								children: "Pele"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2",
								children: [
									0,
									1,
									2,
									3,
									4
								].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setAppearance((a) => ({
										...a,
										skin: i,
										photo: a.photo
									})),
									className: cn("size-9 rounded-full border", appearance.skin === i ? "border-gold" : "border-border"),
									style: { background: [
										"#f3d2b5",
										"#e0b184",
										"#c68642",
										"#8d5524",
										"#4a2c14"
									][i] }
								}, i))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-xs uppercase tracking-wider text-muted",
								children: "Cabelo"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: HAIRS.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setAppearance((a) => ({
										...a,
										hair: h
									})),
									className: cn("h-9 rounded-md px-3 text-xs", appearance.hair === h ? "bg-gold text-gold-fg" : "bg-surface text-fg border border-border"),
									children: h
								}, h))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-xs uppercase tracking-wider text-muted",
								children: "Rosto"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: FACIAL.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setAppearance((a) => ({
										...a,
										facial: f
									})),
									className: cn("h-9 rounded-md px-3 text-xs", appearance.facial === f ? "bg-gold text-gold-fg" : "bg-surface text-fg border border-border"),
									children: f === "none" ? "limpo" : f
								}, f))
							})] })
						]
					}),
					step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-3 text-sm text-muted",
								children: "A base sai no sorteio da nacionalidade. Voce nao escolhe o clube."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-3 gap-2 sm:grid-cols-4",
								children: NATIONS.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setNationId(n.id),
									className: cn("flex h-14 items-center justify-center gap-1.5 rounded-md border px-2 text-xs font-medium", nationId === n.id ? "border-gold bg-gold/10 text-gold" : "border-border bg-surface text-fg"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: flagUrl(n.id),
										alt: "",
										className: "h-3.5 w-5 rounded-sm object-cover"
									}), n.code]
								}, n.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs text-muted",
								children: nationById(nationId).name
							})
						]
					}),
					step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PitchPicker, {
							value: position,
							onChange: (p) => {
								setPosition(p);
								setShirt(defaultShirt(p));
								setIdolId("");
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-5 block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mb-1.5 flex items-center gap-2 text-xs uppercase tracking-wider text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shirt, { className: "size-3.5" }), "Numero da camisa"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 1,
								max: 99,
								value: shirt,
								onChange: (e) => setShirt(Math.max(1, Math.min(99, Number(e.target.value) || 1)))
							})]
						})]
					}),
					step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-sm text-muted",
							children: "Escolhe o idolo. Os da sua posicao puxam mais o estilo. Lendas mundiais tambem entram."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 gap-2",
							children: idols.map((l) => {
								const active = (idolId || idols[0]?.id) === l.id;
								const recommended = l.positions.includes(position);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setIdolId(l.id),
									className: cn("overflow-hidden rounded-xl text-left shadow-[0_0_0_1px_rgba(255,255,255,0.06)]", active ? "shadow-[0_0_0_1px_#e4c15a]" : ""),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative h-28",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: legendArt(l),
												alt: "",
												className: "h-full w-full object-cover"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "absolute left-2 top-2 font-display text-2xl text-gold",
												children: l.number
											}),
											recommended ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "absolute right-2 top-2 rounded-full bg-gold/90 px-2 py-0.5 text-[10px] font-medium uppercase text-gold-fg",
												children: "posicao"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "absolute right-2 top-2 rounded-full bg-black/60 px-2 py-0.5 text-[10px] font-medium uppercase text-gold",
												children: "lenda"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "absolute inset-x-0 bottom-0 p-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm font-medium leading-tight text-fg",
													children: l.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[10px] text-muted",
													children: [
														l.nation,
														" · ",
														l.positions.join("/"),
														" · ",
														l.era
													]
												})]
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "bg-surface px-2 py-2 text-[11px] text-muted",
										children: l.blurb
									})]
								}, l.id);
							})
						})]
					}),
					step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-6 flex flex-col items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerCard, {
								player,
								clubId: academy.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex items-center gap-2 rounded-xl border border-border bg-surface px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubBadge, {
									clubId: academy.id,
									size: "sm"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-fg",
									children: ["Base: ", academy.name]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-muted",
									children: "Sorteada pela nacionalidade"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-center text-xs text-muted",
								children: [
									"Cartinha bronze · OVR ",
									player.overall,
									" · teto ",
									player.potential
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-3 w-full space-y-1.5",
								children: [player.steals.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: cn("rounded-lg px-3 py-2 text-sm text-fg", s.rare ? "border border-gold bg-gold/15" : "border border-gold/30 bg-gold/10"),
									children: [
										s.rare ? "Roubo lendario" : "Roubo",
										": ",
										ATTR_LABELS[s.attr].long,
										" de ",
										s.legend
									]
								}, `${s.legend}-${s.attr}`)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-lg border border-border bg-surface px-3 py-2 text-sm text-muted",
									children: ["Idolo: ", player.idolName]
								})]
							})
						]
					}),
					step === 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-6 grid gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeCard, {
							active: mode === "complete",
							title: "Modo completo",
							copy: "Simula temporada por temporada. Voce so decide sim ou nao: clube, contrato, publi. Ganha pontos para gastar no overall.",
							onClick: () => setMode("complete")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeCard, {
							active: mode === "fast",
							title: "Modo Fast",
							copy: "Simula a carreira inteira de uma vez e entrega o livro: jogos, titulos, fortuna e o lugar na historia.",
							onClick: () => setMode("fast")
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-0 z-10 border-t border-border bg-bg/95 px-4 py-3 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-lg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "lg",
						className: "w-full",
						onClick: next,
						children: [step === steps.length - 1 ? "Entrar no hub" : "Continuar", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })]
					})
				})
			})
		]
	});
}
function ModeCard({ active, title, copy, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("rounded-xl border p-4 text-left", active ? "border-gold bg-gold/10" : "border-border bg-surface"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium text-fg",
				children: title
			}), active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: "gold",
				children: "Ativo"
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm leading-relaxed text-muted",
			children: copy
		})]
	});
}
function PitchPicker({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative overflow-hidden rounded-xl border border-pitch/30 bg-pitch-dim/40 p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-center text-[11px] uppercase tracking-wider text-pitch",
				children: "Toque no campo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-2",
				children: [
					0,
					1,
					2,
					3,
					4,
					5,
					6
				].map((line) => {
					const row = POSITIONS.filter((p) => p.line === line);
					const slots = [
						0,
						1,
						2
					].map((slot) => row.find((p) => p.slot === slot) ?? null);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2",
						children: slots.map((p, i) => p ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onChange(p.id),
							className: cn("h-11 rounded-md text-xs font-semibold", value === p.id ? "bg-gold text-gold-fg" : "bg-bg/50 text-fg hover:bg-bg/70"),
							children: p.id
						}, p.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}, `empty-${line}-${i}`))
					}, line);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-center text-xs text-muted",
				children: POSITIONS.find((p) => p.id === value)?.name
			})
		]
	});
}
function StatBar({ label, value, max = 100, className }) {
	const pct = Math.max(0, Math.min(100, value / max * 100));
	const tone = pct >= 80 ? "bg-pitch" : pct >= 60 ? "bg-gold" : pct >= 40 ? "bg-warn" : "bg-danger";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("grid grid-cols-[1fr_auto] items-center gap-x-3 gap-y-1", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-medium tabular-nums text-fg",
				children: Math.round(value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "col-span-2 h-1.5 overflow-hidden rounded-full bg-surface-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("h-full rounded-full", tone),
					style: { width: `${pct}%` }
				})
			})
		]
	});
}
function Meter({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-1 flex items-baseline justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[11px] uppercase tracking-wider text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-medium tabular-nums text-fg",
				children: Math.round(value)
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-1 overflow-hidden rounded-full bg-surface-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full rounded-full bg-gold",
				style: { width: `${Math.max(0, Math.min(100, value))}%` }
			})
		})]
	});
}
function Hub({ game }) {
	const setScreen = useCareer((s) => s.setScreen);
	const simulateSeason = useCareer((s) => s.simulateSeason);
	const simulateCareer = useCareer((s) => s.simulateCareer);
	const hangBoots = useCareer((s) => s.hangBoots);
	const club = clubById(game.clubId);
	const nation = nationById(game.player.nationId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 pb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubBadge, {
						clubId: game.clubId,
						size: "lg"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] uppercase tracking-[0.2em] text-gold",
							children: [
								club.league,
								" · ",
								game.year
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl leading-none text-fg",
							children: game.player.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								game.player.position,
								" · ",
								nation.code,
								" · ",
								game.player.age,
								"a · T",
								game.season
							]
						})
					] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-4xl tabular-nums text-gold",
						children: game.player.overall
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-wider text-muted",
						children: game.player.cardStyle
					})]
				})]
			}),
			game.injury ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-danger/40 bg-danger/10 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-danger",
					children: game.injury.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [
						game.injury.weeksLeft,
						" semana(s) restantes · ",
						game.injury.severity
					]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerCard, {
					player: game.player,
					clubId: game.clubId
				})
			}),
			game.player.steals.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1.5",
				children: game.player.steals.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg border border-gold/25 bg-gold/10 px-3 py-2 text-xs text-fg",
					children: [
						s.rare ? "Roubo lendario" : "Roubo",
						": ",
						s.legend
					]
				}, `${s.legend}-${s.attr}`))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 rounded-xl bg-surface p-4 panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: "Forma",
						value: game.form
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: "Moral",
						value: game.morale
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: "Fama",
						value: game.fame
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: "Fisico",
						value: game.fitness
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoTile, {
						label: "Fortuna",
						value: formatFortune(game.money)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoTile, {
						label: "Seguidores",
						value: formatFollowers(game.followers)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoTile, {
						label: "Salario/sem",
						value: formatMoney(game.weeklyWage, club.countryCode)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoTile, {
						label: "Contrato",
						value: `${game.contractYearsLeft}a · cl. ${formatFortune(game.releaseClause)}`
					})
				]
			}),
			game.offers.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setScreen("offers"),
				className: "flex w-full items-center justify-between rounded-xl border border-gold/40 bg-gold/10 px-4 py-3 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm font-medium text-gold",
					children: [game.offers.length, " proposta(s) na mesa"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "gold",
					children: "Sim ou nao"
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2",
				children: game.retired ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "w-full",
					onClick: hangBoots,
					children: "Ver o livro de ouro"
				}) : game.mode === "fast" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "lg",
					className: "w-full",
					onClick: simulateCareer,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FastForward, { className: "size-4" }), "Simular carreira inteira"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "lg",
					className: "w-full",
					onClick: simulateSeason,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FastForward, { className: "size-4" }), "Simular temporada"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dumbbell, { className: "size-4" }),
						label: game.seasonPoints ? `Pontos ${game.seasonPoints}` : "Atributos",
						onClick: () => setScreen("training")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4" }),
						label: "Empresario",
						onClick: () => setScreen("agent")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-4" }),
						label: "Carreira",
						onClick: () => setScreen("career")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "mb-2 flex items-center gap-2 text-xs uppercase tracking-wider text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Newspaper, { className: "size-3.5" }), "Gazeta"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: game.news.slice(0, 8).map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg bg-surface px-3 py-2.5 text-sm text-fg panel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[10px] uppercase tracking-wider text-muted",
						children: [
							"T",
							n.season,
							" · sem ",
							n.week
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5",
						children: n.text
					})]
				}, n.id))
			})] })
		]
	});
}
function InfoTile({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface px-3 py-3 panel",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] uppercase tracking-wider text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm font-medium tabular-nums text-fg",
			children: value
		})]
	});
}
function Quick({ icon, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex h-16 flex-col items-center justify-center gap-1 rounded-xl bg-surface text-xs text-fg panel",
		children: [icon, label]
	});
}
function OffersView({ game }) {
	const accept = useCareer((s) => s.accept);
	const rejectAll = useCareer((s) => s.rejectAll);
	const current = clubById(game.clubId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 pb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.2em] text-gold",
					children: "Mercado"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl text-fg",
					children: "Propostas"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Hoje voce veste ",
						current.name,
						". So sim ou nao."
					]
				})
			] }),
			game.offers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-surface px-4 py-6 text-sm text-muted panel",
				children: "Nenhuma proposta. Pede para o empresario ligar ou espera a janela."
			}) : game.offers.map((o) => {
				const c = clubById(o.clubId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-surface p-4 panel",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubBadge, { clubId: c.id }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-lg font-medium text-fg",
									children: c.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										c.league,
										" · ",
										c.country
									]
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "gold",
								children: o.role
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-3 grid grid-cols-2 gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-[11px] uppercase text-muted",
									children: "Salario"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
									className: "tabular-nums text-fg",
									children: [formatMoney(o.wage, c.countryCode), "/sem"]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-[11px] uppercase text-muted",
									children: "Contrato"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
									className: "text-fg",
									children: [o.years, " anos"]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-[11px] uppercase text-muted",
									children: "Luva"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "tabular-nums text-fg",
									children: formatMoney(o.signingBonus, c.countryCode)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-[11px] uppercase text-muted",
									children: "Clausula"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "tabular-nums text-fg",
									children: formatFortune(o.releaseClause)
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "mt-4 w-full",
							onClick: () => accept(o),
							children: ["Sim, assinar com ", c.shortName]
						})
					]
				}, o.id);
			}),
			game.offers.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				className: "w-full",
				onClick: rejectAll,
				children: "Nao. Recusar todas"
			}) : null
		]
	});
}
function SeasonRecapView({ recap, game }) {
	const setScreen = useCareer((s) => s.setScreen);
	const yesRaise = useCareer((s) => s.yesRaise);
	const noRaise = useCareer((s) => s.noRaise);
	const yesBrand = useCareer((s) => s.yesBrand);
	const noBrand = useCareer((s) => s.noBrand);
	const hangBoots = useCareer((s) => s.hangBoots);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 pb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.2em] text-gold",
					children: "Fim de temporada"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl text-fg",
					children: recap.year
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						recap.clubName,
						" · ",
						recap.leaguePlace,
						"º na liga"
					]
				})
			] }),
			recap.sacked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-danger/40 bg-danger/10 px-4 py-3 text-sm text-danger",
				children: "O clube rescindiu por baixo rendimento. Voce escolhe o proximo destino."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						k: "Jogos",
						v: recap.stats.appearances
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						k: "Gols",
						v: recap.stats.goals
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						k: "Assistencias",
						v: recap.stats.assists
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						k: "Media",
						v: recap.stats.avgRating.toFixed(1)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl bg-surface px-4 py-3 text-sm text-fg panel",
				children: [
					"Overall ",
					recap.overallFrom,
					" → ",
					recap.overallTo,
					" · cartinha ",
					recap.cardFrom,
					" → ",
					recap.cardTo,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					"Seguidores ",
					formatFollowers(recap.followersFrom),
					" → ",
					formatFollowers(recap.followersTo),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					"Pontos ganhos: ",
					recap.points
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-1.5",
				children: [recap.titles.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted",
					children: "Sem titulos."
				}) : null, recap.titles.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "gold",
					children: t.name
				}, t.id))]
			}),
			recap.highlights.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 text-xs uppercase tracking-wider text-muted",
				children: "Partidas que ficaram"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: recap.highlights.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg bg-surface px-3 py-2 text-sm panel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-fg",
						children: [
							h.home ? h.playerTeam : h.opponent,
							" ",
							h.home ? h.goalsFor : h.goalsAgainst,
							"–",
							h.home ? h.goalsAgainst : h.goalsFor,
							" ",
							h.home ? h.opponent : h.playerTeam
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							h.competition,
							" · nota ",
							h.rating.toFixed(1),
							h.goals ? ` · ${h.goals} gol(s)` : "",
							h.motm ? " · craque" : "",
							h.injured ? ` · ${h.injured.name}` : ""
						]
					})]
				}, `${h.preview.week}-${i}`))
			})] }) : null,
			game.pendingRaise ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-gold/35 bg-gold/10 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-fg",
						children: "O clube oferece aumento."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [formatMoney(game.pendingRaise, clubById(game.clubId).countryCode), "/sem. Sim ou nao."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: yesRaise,
							children: "Aceitar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: noRaise,
							children: "Recusar"
						})]
					})
				]
			}) : null,
			game.pendingBrand ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-gold/35 bg-gold/10 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-medium text-fg",
						children: [game.pendingBrand.brand, " quer publi."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							formatMoney(game.pendingBrand.weekly, clubById(game.clubId).countryCode),
							"/sem · +",
							formatFollowers(game.pendingBrand.followersBoost),
							" seguidores"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: yesBrand,
							children: "Fechar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: noBrand,
							children: "Recusar"
						})]
					})
				]
			}) : null,
			game.seasonPoints > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "lg",
				variant: "pitch",
				className: "w-full",
				onClick: () => setScreen("training"),
				children: [
					"Gastar ",
					game.seasonPoints,
					" ponto(s)"
				]
			}) : null,
			recap.nextOffers.length > 0 || game.offers.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "lg",
				className: "w-full",
				onClick: () => setScreen("offers"),
				children: "Ver proposta(s)"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "lg",
				className: "w-full",
				onClick: () => setScreen("hub"),
				children: "Proxima temporada"
			}),
			game.retired ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "w-full",
				onClick: hangBoots,
				children: "Encerrar carreira"
			}) : null
		]
	});
}
function FastRecapView({ recap }) {
	const setScreen = useCareer((s) => s.setScreen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 pb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.2em] text-gold",
					children: "Simulacao Fast"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "font-display text-3xl text-fg",
					children: [recap.years, " temporada(s)"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"OVR ",
						recap.overallFrom,
						" → ",
						recap.overallTo,
						" · Fama ",
						Math.round(recap.fameFrom),
						" → ",
						Math.round(recap.fameTo)
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl bg-surface px-4 py-3 text-sm text-fg panel",
				children: ["Dinheiro ganho: ", formatFortune(recap.moneyGained)]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "space-y-2",
				children: recap.lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl bg-surface p-3 panel",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubBadge, {
									clubId: line.clubId,
									size: "sm"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-medium text-fg",
									children: [
										line.year,
										" · ",
										line.clubName
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs tabular-nums text-muted",
								children: ["OVR ", line.overall]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted",
							children: [
								line.appearances,
								" j · ",
								line.goals,
								" g · ",
								line.assists,
								" a · media ",
								line.avgRating.toFixed(1),
								line.injuryWeeks ? ` · ${line.injuryWeeks} sem. lesionado` : ""
							]
						}),
						line.titles.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex flex-wrap gap-1",
							children: line.titles.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "gold",
								children: t
							}, t))
						}) : null
					]
				}, `${line.season}-${line.clubId}`))
			}),
			recap.nextOffers.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "lg",
				className: "w-full",
				onClick: () => setScreen("offers"),
				children: "Proxima proposta"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "lg",
				className: "w-full",
				onClick: () => setScreen("hub"),
				children: "Voltar ao hub"
			})
		]
	});
}
function RetiredView({ game }) {
	const becomeCoach = useCareer((s) => s.becomeCoach);
	const newGame = useCareer((s) => s.newGame);
	const rank = game.historyRank;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.2em] text-gold",
						children: "Pendurou as chuteiras"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-1 text-4xl text-fg",
						children: game.player.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: game.retireReason ?? "Carreira encerrada."
					}),
					rank ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-display text-3xl text-gold",
						children: rank.label
					}) : null,
					rank ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: rank.copy
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerCard, {
					player: {
						...game.player,
						overall: game.peakOverall,
						cardStyle: game.player.cardStyle
					},
					clubId: game.clubId
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						k: "Jogos",
						v: game.stats.appearances
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						k: "Gols",
						v: game.stats.goals
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						k: "Assistencias",
						v: game.stats.assists
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						k: "Titulos",
						v: game.titles.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						k: "Pico OVR",
						v: game.peakOverall
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						k: "Fortuna",
						v: formatFortune(game.money)
					})
				]
			}),
			!game.coach ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-gold/35 bg-gold/10 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-fg",
						children: "Virar tecnico?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "So existe o Fast de tecnico. Uma simulacao unica, sem voltar atras, e o livro fecha."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "mt-3 w-full",
						onClick: becomeCoach,
						children: "Simular carreira de tecnico"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "mt-2 w-full",
						onClick: newGame,
						children: "Encerrar sem o banco"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "lg",
				className: "w-full",
				onClick: newGame,
				children: "Nova lenda"
			})
		]
	});
}
function CoachView({ game }) {
	const newGame = useCareer((s) => s.newGame);
	const coach = game.coach;
	const rank = game.historyRank;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.2em] text-gold",
						children: "Livro fechado"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-1 text-4xl text-fg",
						children: game.player.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-display text-3xl text-gold",
						children: [
							rank?.label ?? "Jogador",
							" ",
							coach ? `· ${coach.rank.label}` : ""
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: game.lifeVerdict ?? rank?.copy
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerCard, {
					player: {
						...game.player,
						overall: game.peakOverall
					},
					clubId: game.stats.clubs[0]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-4 panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted",
						children: "Jogador"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-fg",
						children: [
							"Pico ",
							game.peakOverall,
							" OVR · ",
							game.stats.appearances,
							" jogos · ",
							game.stats.goals,
							" gols · ",
							game.stats.assists,
							" assist. · media",
							" ",
							game.stats.avgRating.toFixed(2)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							game.titles.length,
							" titulos em campo · fortuna ",
							formatFortune(game.money),
							" · ",
							formatFollowers(game.followers),
							" seguidores"
						]
					})
				]
			}),
			coach ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-4 panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted",
						children: "Tecnico · Fast"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-fg",
						children: [
							coach.years,
							" anos no banco · ",
							coach.titles,
							" titulos · ",
							coach.rank.label
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: coach.rank.copy
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-3 space-y-2",
						children: coach.lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start justify-between gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-fg",
								children: [
									line.year,
									" · ",
									line.clubName
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-right text-xs text-muted",
								children: [
									line.place,
									"º",
									line.titles.length ? ` · ${line.titles.join(", ")}` : ""
								]
							})]
						}, line.year))
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 text-xs uppercase tracking-wider text-muted",
				children: "Vitrine"
			}), game.titles.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Nenhum titulo como jogador."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1.5",
				children: game.titles.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between rounded-lg bg-surface px-3 py-2 text-sm panel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted",
						children: ["T", t.season]
					})]
				}, t.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "lg",
				className: "w-full",
				onClick: newGame,
				children: "Nova lenda"
			})
		]
	});
}
function Tile({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface px-3 py-3 panel",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] uppercase tracking-wider text-muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl tabular-nums text-fg",
			children: v
		})]
	});
}
function TrainingView({ game }) {
	const spend = useCareer((s) => s.spend);
	const setScreen = useCareer((s) => s.setScreen);
	const points = game.seasonPoints;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 pb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.2em] text-gold",
					children: "Pontos da temporada"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl text-fg",
					children: "Evolucao"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						points,
						" ponto(s) · potencial ",
						game.player.potential,
						" · ",
						game.player.age,
						" anos"
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3 rounded-xl bg-surface p-4 panel",
				children: ATTR_KEYS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBar, {
					label: ATTR_LABELS[k].long,
					value: game.player.attributes[k]
				}, k))
			}),
			points <= 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-surface px-4 py-3 text-sm text-muted panel",
				children: "Os pontos saem no fim de cada temporada, de acordo com jogos, gols, nota e titulos. No Fast o jogo gasta sozinho."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2",
				children: ATTR_KEYS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => spend(k),
					children: ["+1 ", ATTR_LABELS[k].short]
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				className: "w-full",
				onClick: () => setScreen("hub"),
				children: "Voltar"
			})
		]
	});
}
var NAV = [
	{
		id: "hub",
		label: "Inicio",
		icon: House
	},
	{
		id: "agent",
		label: "Empresario",
		icon: Briefcase
	},
	{
		id: "training",
		label: "Pontos",
		icon: Sparkles
	},
	{
		id: "career",
		label: "Carreira",
		icon: Trophy
	}
];
function GameApp() {
	const [ready, setReady] = (0, import_react.useState)(false);
	const screen = useCareer((s) => s.screen);
	const game = useCareer((s) => s.game);
	const recap = useCareer((s) => s.recap);
	const fastRecap = useCareer((s) => s.fastRecap);
	const toast = useCareer((s) => s.toast);
	const clearToast = useCareer((s) => s.clearToast);
	const setScreen = useCareer((s) => s.setScreen);
	(0, import_react.useEffect)(() => {
		const result = useCareer.persist.rehydrate();
		Promise.resolve(result).then(() => setReady(true));
	}, []);
	(0, import_react.useEffect)(() => {
		if (!toast) return;
		const t = window.setTimeout(clearToast, 2800);
		return () => window.clearTimeout(t);
	}, [toast, clearToast]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landing, {});
	if (screen === "landing" || !game && screen !== "create") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landing, {});
	if (screen === "create" || !game) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreatePlayer, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex min-h-dvh max-w-lg flex-col px-4 pb-24 pt-5",
				children: [
					screen === "hub" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hub, { game }),
					screen === "match" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hub, { game }),
					screen === "agent" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentPanel, { game }),
					screen === "training" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrainingView, { game }),
					screen === "career" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CareerView, { game }),
					screen === "offers" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OffersView, { game }),
					screen === "season-recap" && recap && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeasonRecapView, {
						recap,
						game
					}),
					screen === "fast-recap" && fastRecap && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FastRecapView, { recap: fastRecap }),
					screen === "retired" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RetiredView, { game }),
					screen === "coach" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoachView, { game }),
					screen === "season-recap" && !recap && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hub, { game }),
					screen === "fast-recap" && !fastRecap && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hub, { game })
				]
			}),
			!(screen === "season-recap" || screen === "fast-recap" || screen === "retired" || screen === "coach") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-lg grid-cols-4",
					children: NAV.map((item) => {
						const active = screen === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setScreen(item.id),
							className: cn("flex h-14 flex-col items-center justify-center gap-0.5 text-[11px]", active ? "text-gold" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-4" }), item.label]
						}, item.id);
					})
				})
			}) : null,
			toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none fixed inset-x-0 bottom-20 z-30 flex justify-center px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm rounded-lg bg-surface px-3 py-2 text-center text-sm text-fg panel",
					children: toast
				})
			}) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { Home as component };
