import type { ReactNode } from "react";
import { Briefcase, Dumbbell, FastForward, Newspaper, Trophy, Users, Activity } from "lucide-react";
import { PlayerCard } from "@/components/career/player-card";
import { ClubBadge } from "@/components/career/club-badge";
import { Meter } from "@/components/career/stat-bar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { clubById, nationById } from "@/lib/career/data";
import { formatFollowers, formatFortune, formatMoney } from "@/lib/career/engine";
import type { GameState } from "@/lib/career/types";
import { useCareer } from "@/store/career-store";

export function Hub({ game }: { game: GameState }) {
  const setScreen = useCareer((s) => s.setScreen);
  const simulateSeason = useCareer((s) => s.simulateSeason);
  const playNextMatch = useCareer((s) => s.playNextMatch);
  const simulateCareer = useCareer((s) => s.simulateCareer);
  const hangBoots = useCareer((s) => s.hangBoots);
  const club = clubById(game.clubId);
  const nation = nationById(game.player.nationId);

  return (
    <div className="space-y-4 pb-4">
      <header className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <ClubBadge clubId={game.clubId} size="lg" />
          <div>
            <p className="text-[11px] uppercase tracking-[0.2em] text-gold">
              {club.league} · {game.year}
            </p>
            <h1 className="font-display text-3xl leading-none text-fg">{game.player.name}</h1>
            <p className="mt-1 text-sm text-muted">
              {game.player.position} · {nation.code} · {game.player.age}a · T{game.season}
            </p>
          </div>
        </div>
        <div className="text-right">
          <p className="font-display text-4xl tabular-nums text-gold">{game.player.overall}</p>
          <p className="text-[11px] uppercase tracking-wider text-muted">{game.player.cardStyle}</p>
        </div>
      </header>

      {game.injury ? (
        <div className="rounded-xl border border-danger/40 bg-danger/10 px-4 py-3">
          <p className="text-sm font-medium text-danger">{game.injury.name}</p>
          <p className="text-xs text-muted">
            {game.injury.weeksLeft} semana(s) restantes · {game.injury.severity}
          </p>
        </div>
      ) : null}

      <div className="flex justify-center">
        <PlayerCard player={game.player} clubId={game.clubId} />
      </div>

      {game.player.steals.length ? (
        <ul className="space-y-1.5">
          {game.player.steals.map((s) => (
            <li
              key={`${s.legend}-${s.attr}`}
              className="rounded-lg border border-gold/25 bg-gold/10 px-3 py-2 text-xs text-fg"
            >
              {s.rare ? "Roubo lendario" : "Roubo"}: {s.legend}
            </li>
          ))}
        </ul>
      ) : null}

      <FormationCard game={game} />

      <div className="grid grid-cols-2 gap-2 rounded-xl bg-surface p-4 panel">
        <Meter label="Forma" value={game.form} />
        <Meter label="Moral" value={game.morale} />
        <Meter label="Fama" value={game.fame} />
        <Meter label="Fisico" value={game.fitness} />
      </div>

      <div className="grid grid-cols-2 gap-2">
        <InfoTile label="Fortuna" value={formatFortune(game.money)} />
        <InfoTile label="Seguidores" value={formatFollowers(game.followers)} />
        <InfoTile label="Salario/sem" value={formatMoney(game.weeklyWage, club.countryCode)} />
        <InfoTile label="Contrato" value={`${game.contractYearsLeft}a · cl. ${formatFortune(game.releaseClause)}`} />
      </div>

      {game.offers.length > 0 ? (
        <button
          type="button"
          onClick={() => setScreen("offers")}
          className="flex w-full items-center justify-between rounded-xl border border-gold/40 bg-gold/10 px-4 py-3 text-left"
        >
          <span className="text-sm font-medium text-gold">{game.offers.length} proposta(s) na mesa</span>
          <Badge variant="gold">Sim ou nao</Badge>
        </button>
      ) : null}

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {!game.retired ? (
          <Button size="lg" variant="outline" className="w-full border-pitch/40 text-pitch" onClick={playNextMatch}>
            <FastForward className="size-4" />
            Próximo jogo
          </Button>
        ) : null}
        {game.retired ? (
          <Button size="lg" className="w-full" onClick={hangBoots}>
            Ver o livro de ouro
          </Button>
        ) : game.mode === "fast" ? (
          <Button size="lg" className="w-full" onClick={simulateCareer}>
            <FastForward className="size-4" />
            Simular carreira inteira
          </Button>
        ) : (
          <Button size="lg" className="w-full" onClick={simulateSeason}>
            <FastForward className="size-4" />
            Simular temporada
          </Button>
        )}
      </div>

      <div className="grid grid-cols-3 gap-2">
        <Quick
          icon={<Dumbbell className="size-4" />}
          label={game.seasonPoints ? `Pontos ${game.seasonPoints}` : "Atributos"}
          onClick={() => setScreen("training")}
        />
        <Quick icon={<Briefcase className="size-4" />} label="Empresario" onClick={() => setScreen("agent")} />
        <Quick icon={<Trophy className="size-4" />} label="Carreira" onClick={() => setScreen("career")} />
      </div>

      <section>
        <h2 className="mb-2 flex items-center gap-2 text-xs uppercase tracking-wider text-muted">
          <Newspaper className="size-3.5" />
          Gazeta
        </h2>
        <ul className="space-y-2">
          {game.news.slice(0, 8).map((n) => (
            <li key={n.id} className="rounded-lg bg-surface px-3 py-2.5 text-sm text-fg panel">
              <p className="text-[10px] uppercase tracking-wider text-muted">
                T{n.season} · sem {n.week}
              </p>
              <p className="mt-0.5">{n.text}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function FormationCard({ game }: { game: GameState }) {
  const player = game.player.name.split(" ")[0];
  const is = (p: string) => game.player.position === p;
  const names = [
    "Alisson", "Cafu", "Van Dijk", "Maldini", "Rodri", "De Bruyne", "Bellingham", "Messi", "Vini Jr.", "Haaland", "Salah",
  ];
  const seed = game.season + game.player.overall + game.player.age;
  const pickName = (i: number) => names[(seed + i * 3) % names.length];
  const slots = [
    ["GK", "Goleiro", is("GK") ? player : pickName(0)],
    ["LB", "Lateral", is("LB") ? player : pickName(1)],
    ["CB", "Zagueiro", is("CB") ? player : pickName(2)],
    ["CB", "Zagueiro", is("CB") ? player : pickName(3)],
    ["RB", "Lateral", is("RB") ? player : pickName(4)],
    ["CDM", "Volante", is("CDM") ? player : pickName(5)],
    ["CM", "Meia", is("CM") ? player : pickName(6)],
    ["CAM", "Meia", is("CAM") ? player : pickName(7)],
    ["LW", "Ponta", is("LW") ? player : pickName(8)],
    ["ST", "Ataque", is("ST") ? player : pickName(9)],
    ["RW", "Ponta", is("RW") ? player : pickName(10)],
  ];
  return (
    <section className="overflow-hidden rounded-2xl border border-pitch/25 bg-surface panel animate-[floatIn_500ms_ease-out]">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <div><p className="text-[11px] uppercase tracking-[0.18em] text-pitch">Elenco</p><h2 className="font-display text-2xl text-fg">4-3-3 · Formação</h2></div>
        <div className="flex items-center gap-1.5 text-[10px] text-muted"><Activity className="size-3.5 text-pitch" /> AO VIVO</div>
      </div>
      <div className="relative mx-3 my-3 min-h-[360px] overflow-hidden rounded-xl border border-pitch/20 bg-[radial-gradient(circle_at_center,_rgba(61,204,115,.18),_transparent_58%),linear-gradient(180deg,#17452b,#0d2a1b)]">
        <div className="absolute inset-3 rounded-lg border border-white/15" />
        <div className="absolute left-1/2 top-1/2 h-px w-[calc(100%-24px)] -translate-x-1/2 bg-white/15" />
        <div className="absolute left-1/2 top-1/2 size-20 -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/15" />
        {slots.map(([pos, role, name], i) => {
          const coords = [[50,88],[20,70],[40,73],[60,73],[80,70],[30,52],[50,55],[70,52],[20,28],[50,20],[80,28]][i];
          const mine = name === player;
          return <div key={`${pos}-${i}`} className="absolute -translate-x-1/2 -translate-y-1/2 text-center" style={{ left: `${coords[0]}%`, top: `${coords[1]}%` }}>
            <div className={mine ? "mx-auto flex size-10 items-center justify-center rounded-full border-2 border-gold bg-gold text-xs font-bold text-gold-fg shadow-[0_0_22px_rgba(228,193,90,.55)] animate-pulse" : "mx-auto flex size-9 items-center justify-center rounded-full border border-white/30 bg-black/55 text-[10px] font-bold text-white"}>{mine ? game.player.overall : pos}</div>
            <p className={mine ? "mt-1 max-w-20 truncate text-[10px] font-bold text-gold" : "mt-1 max-w-20 truncate text-[10px] text-white"}>{name}</p>
            <p className="text-[8px] uppercase text-white/50">{role}</p>
          </div>;
        })}
      </div>
      <div className="flex items-center gap-2 px-4 pb-4 text-xs text-muted"><Users className="size-3.5 text-pitch" /> Você está destacado em dourado. Os nomes ao redor representam as estrelas do elenco.</div>
    </section>
  );
}

function InfoTile({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-surface px-3 py-3 panel">
      <p className="text-[11px] uppercase tracking-wider text-muted">{label}</p>
      <p className="mt-1 text-sm font-medium tabular-nums text-fg">{value}</p>
    </div>
  );
}

function Quick({ icon, label, onClick }: { icon: ReactNode; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex h-16 flex-col items-center justify-center gap-1 rounded-xl bg-surface text-xs text-fg panel"
    >
      {icon}
      {label}
    </button>
  );
}
