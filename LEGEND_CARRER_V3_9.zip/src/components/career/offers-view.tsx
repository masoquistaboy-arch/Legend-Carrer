import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ClubBadge } from "@/components/career/club-badge";
import { clubById } from "@/lib/career/data";
import { formatFortune, formatMoney } from "@/lib/career/engine";
import type { GameState } from "@/lib/career/types";
import { useCareer } from "@/store/career-store";

export function OffersView({ game }: { game: GameState }) {
  const accept = useCareer((s) => s.accept);
  const rejectAll = useCareer((s) => s.rejectAll);
  const current = clubById(game.clubId);

  return (
    <div className="space-y-4 pb-4">
      <header>
        <p className="text-[11px] uppercase tracking-[0.2em] text-gold">Mercado</p>
        <h1 className="font-display text-3xl text-fg">Propostas</h1>
        <p className="text-sm text-muted">Hoje voce veste {current.name}. So sim ou nao.</p>
      </header>

      {game.offers.length === 0 ? (
        <p className="rounded-xl bg-surface px-4 py-6 text-sm text-muted panel">
          Nenhuma proposta. Pede para o empresario ligar ou espera a janela.
        </p>
      ) : (
        game.offers.map((o) => {
          const c = clubById(o.clubId);
          return (
            <article key={o.id} className="rounded-xl bg-surface p-4 panel">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3">
                  <ClubBadge clubId={c.id} />
                  <div>
                    <h2 className="text-lg font-medium text-fg">{c.name}</h2>
                    <p className="text-xs text-muted">
                      {c.league} · {c.country}
                    </p>
                  </div>
                </div>
                <Badge variant="gold">{o.role}</Badge>
              </div>
              <dl className="mt-3 grid grid-cols-2 gap-2 text-sm">
                <div>
                  <dt className="text-[11px] uppercase text-muted">Salario</dt>
                  <dd className="tabular-nums text-fg">{formatMoney(o.wage, c.countryCode)}/sem</dd>
                </div>
                <div>
                  <dt className="text-[11px] uppercase text-muted">Contrato</dt>
                  <dd className="text-fg">{o.years} anos</dd>
                </div>
                <div>
                  <dt className="text-[11px] uppercase text-muted">Luva</dt>
                  <dd className="tabular-nums text-fg">{formatMoney(o.signingBonus, c.countryCode)}</dd>
                </div>
                <div>
                  <dt className="text-[11px] uppercase text-muted">Clausula</dt>
                  <dd className="tabular-nums text-fg">{formatFortune(o.releaseClause)}</dd>
                </div>
              </dl>
              <Button className="mt-4 w-full" onClick={() => accept(o)}>
                Sim, assinar com {c.shortName}
              </Button>
            </article>
          );
        })
      )}

      {game.offers.length > 0 ? (
        <Button variant="ghost" className="w-full" onClick={rejectAll}>
          Nao. Recusar todas
        </Button>
      ) : null}
    </div>
  );
}
