import { cn } from "@/lib/utils";

export function StatBar({
  label,
  value,
  max = 100,
  className,
}: {
  label: string;
  value: number;
  max?: number;
  className?: string;
}) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const tone = pct >= 80 ? "bg-pitch" : pct >= 60 ? "bg-gold" : pct >= 40 ? "bg-warn" : "bg-danger";
  return (
    <div className={cn("grid grid-cols-[1fr_auto] items-center gap-x-3 gap-y-1", className)}>
      <span className="text-xs text-muted">{label}</span>
      <span className="text-xs font-medium tabular-nums text-fg">{Math.round(value)}</span>
      <div className="col-span-2 h-1.5 overflow-hidden rounded-full bg-surface-2">
        <div className={cn("h-full rounded-full", tone)} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export function Meter({
  label,
  value,
}: {
  label: string;
  value: number;
}) {
  return (
    <div className="min-w-0">
      <div className="mb-1 flex items-baseline justify-between gap-2">
        <span className="text-[11px] uppercase tracking-wider text-muted">{label}</span>
        <span className="text-xs font-medium tabular-nums text-fg">{Math.round(value)}</span>
      </div>
      <div className="h-1 overflow-hidden rounded-full bg-surface-2">
        <div className="h-full rounded-full bg-gold" style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
      </div>
    </div>
  );
}
