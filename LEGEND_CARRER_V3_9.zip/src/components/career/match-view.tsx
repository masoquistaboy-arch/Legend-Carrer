import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { GameState } from "@/lib/career/types";
import { useCareer } from "@/store/career-store";
import { cn } from "@/lib/utils";

export function MatchView({ game }: { game: GameState }) {
  const setScreen = useCareer((s) => s.setScreen);
  const match = game.lastMatch;

  if (!match) {
    return (
      <div className="space-y-4">
        <header>
          <p className="text-[11px] uppercase tracking-[0.2em] text-gold">Gazeta</p>
          <h1 className="font-display text-3xl text-fg">Sem partida ainda</h1>
          <p className="text-sm text-muted">Simula a temporada. Os jogos e as noticias aparecem no hub.</p>
        </header>
        <Button size="lg" className="w-full" onClick={() => setScreen("hub")}>
          Voltar ao hub
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4 pb-4">
      <header className="text-center">
        <p className="text-[11px] uppercase tracking-[0.2em] text-gold">{match.competition}</p>
        <p className="mt-2 text-sm text-muted">
          {match.home ? match.playerTeam : match.opponent} vs {match.home ? match.opponent : match.playerTeam}
        </p>
        <p className="font-display mt-1 text-6xl tabular-nums text-fg">
          {match.home ? match.goalsFor : match.goalsAgainst}–{match.home ? match.goalsAgainst : match.goalsFor}
        </p>
        <div className="mt-2 flex justify-center gap-2">
          <Badge variant={match.result === "W" ? "pitch" : match.result === "D" ? "gold" : "danger"}>
            {match.result === "W" ? "Vitoria" : match.result === "D" ? "Empate" : "Derrota"}
          </Badge>
          {match.motm ? <Badge variant="gold">Craque da partida</Badge> : null}
        </div>
      </header>

      <ol className="space-y-1.5 rounded-xl bg-surface p-3 panel">
        {match.events.map((e, i) => (
          <li
            key={`${e.minute}-${i}`}
            className={cn(
              "flex gap-3 text-sm",
              e.kind === "goal" ? "text-gold" : e.kind === "injury" ? "text-danger" : "text-fg",
            )}
          >
            <span className="w-8 shrink-0 tabular-nums text-muted">{e.minute}'</span>
            <span>{e.text}</span>
          </li>
        ))}
      </ol>

      <div className="grid grid-cols-2 gap-2">
        <Stat k="Nota" v={match.rating.toFixed(1)} />
        <Stat k="Minutos" v={`${match.minutes}'`} />
        <Stat k="Gols" v={String(match.goals)} />
        <Stat k="Assistencias" v={String(match.assists)} />
      </div>

      {match.injured ? (
        <p className="rounded-xl border border-danger/40 bg-danger/10 px-4 py-3 text-sm text-danger">
          Lesao: {match.injured.name} · {match.injured.weeksTotal} semana(s)
        </p>
      ) : null}

      <Button size="lg" className="w-full" onClick={() => setScreen("hub")}>
        Voltar ao hub
      </Button>
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-xl bg-surface px-3 py-3 panel">
      <p className="text-[11px] uppercase tracking-wider text-muted">{k}</p>
      <p className="font-display text-2xl tabular-nums text-fg">{v}</p>
    </div>
  );
}
