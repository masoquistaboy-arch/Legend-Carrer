import { useState, type ReactNode } from "react";
import { ArrowLeftRight, Banknote, Briefcase, DoorOpen, Hash, MapPin, Megaphone, Plane } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { POSITIONS, clubById } from "@/lib/career/data";
import { formatMoney } from "@/lib/career/engine";
import type { GameState, Position } from "@/lib/career/types";
import { useCareer } from "@/store/career-store";
import { cn } from "@/lib/utils";

export function AgentPanel({ game }: { game: GameState }) {
  const talk = useCareer((s) => s.talkAgent);
  const log = useCareer((s) => s.agentLog);
  const setNumber = useCareer((s) => s.setNumber);
  const requestPosition = useCareer((s) => s.requestPosition);
  const [number, setNum] = useState(game.player.shirtNumber);
  const [pos, setPos] = useState<Position>(game.player.position);
  const club = clubById(game.clubId);

  return (
    <div className="flex flex-col gap-4 pb-4">
      <header>
        <p className="text-[11px] uppercase tracking-[0.2em] text-gold">Empresario</p>
        <h1 className="font-display text-3xl text-fg">Rafa Moreira</h1>
        <p className="text-sm text-muted">
          Humor {game.agentMood} · {club.name} · {formatMoney(game.weeklyWage, club.countryCode)}/sem
        </p>
      </header>

      <div className="flex max-h-72 flex-col gap-2 overflow-y-auto rounded-xl bg-surface p-3 panel">
        {log.length === 0 ? (
          <p className="text-sm text-muted">Manda um recado. Eu resolvo o resto. Voce so diz sim ou nao.</p>
        ) : (
          log.map((m) => (
            <div
              key={m.id}
              className={cn(
                "max-w-[90%] rounded-lg px-3 py-2 text-sm leading-relaxed",
                m.from === "you" ? "ml-auto bg-gold/15 text-fg" : "bg-surface-2 text-fg",
              )}
            >
              {m.text}
            </div>
          ))
        )}
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Talk icon={<Banknote className="size-4" />} label="Pedir aumento" onClick={() => talk("raise")} />
        <Talk icon={<ArrowLeftRight className="size-4" />} label="Quero sair" onClick={() => talk("transfer")} />
        <Talk icon={<Megaphone className="size-4" />} label="Patrocinio" onClick={() => talk("sponsor")} />
        <Talk icon={<Plane className="size-4" />} label="Emprestimo" onClick={() => talk("loan")} />
        <Talk icon={<Briefcase className="size-4" />} label="Ver propostas" onClick={() => talk("offers")} />
        <Talk icon={<DoorOpen className="size-4" />} label="Rescisao" onClick={() => talk("resign")} />
      </div>

      <div className="rounded-xl bg-surface p-4 panel">
        <p className="text-xs uppercase tracking-wider text-muted">Numero da camisa</p>
        <div className="mt-2 flex gap-2">
          <Input
            type="number"
            min={1}
            max={99}
            value={number}
            onChange={(e) => setNum(Number(e.target.value))}
          />
          <Button variant="outline" onClick={() => setNumber(number)}>
            <Hash className="size-4" />
            Aplicar
          </Button>
        </div>
        <p className="mt-4 text-xs uppercase tracking-wider text-muted">Pedir nova posicao</p>
        <p className="mt-1 text-[11px] text-muted">O tecnico pode recusar. E sorte.</p>
        <div className="mt-2 flex flex-wrap gap-1.5">
          {POSITIONS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setPos(p.id)}
              className={cn(
                "h-9 rounded-md px-2.5 text-xs",
                pos === p.id ? "bg-gold text-gold-fg" : "bg-surface-2 text-fg",
              )}
            >
              {p.id}
            </button>
          ))}
        </div>
        <Button
          className="mt-3 w-full"
          variant="outline"
          onClick={() => requestPosition(pos)}
          disabled={pos === game.player.position}
        >
          <MapPin className="size-4" />
          Pedir {pos}
        </Button>
      </div>
    </div>
  );
}

function Talk({ icon, label, onClick }: { icon: ReactNode; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex h-14 items-center gap-2 rounded-xl bg-surface px-3 text-left text-sm text-fg panel"
    >
      {icon}
      {label}
    </button>
  );
}
