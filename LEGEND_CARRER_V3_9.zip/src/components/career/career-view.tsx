import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ClubBadge } from "@/components/career/club-badge";
import { clubById } from "@/lib/career/data";
import { formatFollowers, formatFortune, formatMoney } from "@/lib/career/engine";
import type { GameState } from "@/lib/career/types";
import { useCareer } from "@/store/career-store";

export function CareerView({ game }: { game: GameState }) {
  const club = clubById(game.clubId);
  const s = game.stats;
  const t = game.seasonStats;
  const hangBoots = useCareer((x) => x.hangBoots);
  const newGame = useCareer((x) => x.newGame);

  return (
    <div className="space-y-4 pb-4">
      <header>
        <p className="text-[11px] uppercase tracking-[0.2em] text-gold">Livro de ouro</p>
        <h1 className="font-display text-3xl text-fg">Carreira</h1>
        <p className="text-sm text-muted">
          Pico {game.peakOverall} · {game.player.idolName} · {game.player.cardStyle}
        </p>
      </header>

      <div className="grid grid-cols-2 gap-2">
        <Tile k="Jogos" v={s.appearances + t.appearances} />
        <Tile k="Gols" v={s.goals + t.goals} />
        <Tile k="Assistencias" v={s.assists + t.assists} />
        <Tile k="Nota media" v={(s.avgRating || t.avgRating || 0).toFixed(2)} />
        <Tile k="Titulos" v={game.titles.length} />
        <Tile k="Fortuna" v={formatFortune(game.money)} />
        <Tile k="Seguidores" v={formatFollowers(game.followers)} />
        <Tile k="Fama" v={Math.round(game.fame)} />
      </div>

      <section className="rounded-xl bg-surface p-4 panel">
        <p className="text-xs uppercase tracking-wider text-muted">Temporada atual</p>
        <p className="mt-1 text-sm text-fg">
          {t.appearances} jogos · {t.goals} gols · {t.assists} assist. · media {t.avgRating.toFixed(1)}
        </p>
        <p className="text-sm text-muted">
          {t.wins}V {t.draws}E {t.losses}D · salario {formatMoney(game.weeklyWage, club.countryCode)}
        </p>
      </section>

      {game.lastMatch ? (
        <section className="rounded-xl bg-surface p-4 panel">
          <p className="text-xs uppercase tracking-wider text-muted">Ultima partida</p>
          <p className="mt-1 text-sm text-fg">
            {game.lastMatch.playerTeam} {game.lastMatch.goalsFor}–{game.lastMatch.goalsAgainst} {game.lastMatch.opponent}
          </p>
          <p className="text-xs text-muted">
            nota {game.lastMatch.rating.toFixed(1)} · {game.lastMatch.minutes}' · {game.lastMatch.competition}
          </p>
        </section>
      ) : null}

      <section>
        <h2 className="mb-2 text-xs uppercase tracking-wider text-muted">Patrocinios</h2>
        {game.sponsorships.length === 0 ? (
          <p className="text-sm text-muted">Nenhum contrato de imagem. Fala com o empresario.</p>
        ) : (
          <ul className="space-y-2">
            {game.sponsorships.map((sp) => (
              <li key={sp.id} className="flex justify-between rounded-lg bg-surface px-3 py-2 text-sm panel">
                <span>{sp.brand}</span>
                <span className="tabular-nums text-muted">
                  {formatMoney(sp.weekly, club.countryCode)}/sem · {sp.seasonsLeft} temp.
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section>
        <h2 className="mb-2 text-xs uppercase tracking-wider text-muted">Clubes</h2>
        <div className="flex flex-wrap gap-2">
          {game.stats.clubs.map((id) => (
            <span key={id} className="inline-flex items-center gap-1.5 rounded-full bg-surface px-2 py-1 panel">
              <ClubBadge clubId={id} size="sm" />
              <Badge>{clubById(id).shortName}</Badge>
            </span>
          ))}
        </div>
      </section>

      <section>
        <h2 className="mb-2 text-xs uppercase tracking-wider text-muted">Titulos</h2>
        {game.titles.length === 0 ? (
          <p className="text-sm text-muted">Ainda nada na vitrine. Temporada longa.</p>
        ) : (
          <ul className="space-y-2">
            {game.titles.map((title) => (
              <li key={title.id} className="flex items-center justify-between rounded-lg bg-surface px-3 py-2 panel">
                <span className="text-sm text-fg">{title.name}</span>
                <span className="text-xs text-muted">T{title.season}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <Button variant="outline" className="w-full" onClick={hangBoots}>
        Pendurar as chuteiras
      </Button>
      <Button variant="ghost" className="w-full" onClick={newGame}>
        Nova carreira
      </Button>
    </div>
  );
}

function Tile({ k, v }: { k: string; v: number | string }) {
  return (
    <div className="rounded-xl bg-surface px-3 py-3 panel">
      <p className="text-[11px] uppercase tracking-wider text-muted">{k}</p>
      <p className="font-display text-2xl tabular-nums text-fg">{v}</p>
    </div>
  );
}
