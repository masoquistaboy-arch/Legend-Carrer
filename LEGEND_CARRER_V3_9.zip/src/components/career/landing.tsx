import { Play, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FEATURED_LANDING, LEGENDS, legendArt } from "@/lib/career/data";
import { useCareer } from "@/store/career-store";

const TICKER = [...LEGENDS.map((l) => l.name), ...LEGENDS.map((l) => l.name)];

export function Landing() {
  const game = useCareer((s) => s.game);
  const setScreen = useCareer((s) => s.setScreen);
  const newGame = useCareer((s) => s.newGame);
  const featured = FEATURED_LANDING.map((id) => LEGENDS.find((l) => l.id === id)).filter(Boolean);

  return (
    <main className="relative flex min-h-dvh flex-col overflow-hidden">
      <img
        src="/landing-stadium.jpg"
        alt=""
        className="absolute inset-0 h-full w-full object-cover object-[center_30%]"
      />
      <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(8,11,9,0.35)_0%,rgba(8,11,9,0.55)_38%,rgba(8,11,9,0.92)_72%,#080b09_100%)]" />
      <div className="grain pointer-events-none absolute inset-0" />

      <div className="relative z-10 flex min-h-dvh flex-col">
        <div className="overflow-hidden border-b border-white/10 bg-black/25 py-2 backdrop-blur-sm">
          <div className="marquee flex w-max gap-8 whitespace-nowrap text-[11px] font-medium uppercase tracking-[0.22em] text-gold">
            {TICKER.map((name, i) => (
              <span key={`${name}-${i}`}>{name}</span>
            ))}
          </div>
        </div>

        <div className="mx-auto flex w-full max-w-lg flex-1 flex-col justify-end px-5 pb-10 pt-8">
          <p className="text-xs font-medium uppercase tracking-[0.28em] text-gold">Simulador de carreira</p>
          <h1 className="font-display mt-2 text-7xl font-extrabold leading-none tracking-tight text-fg">LENDA</h1>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted">
            16 anos, bronze, base sorteada. Idolo, roubo de habilidades e um pouco de sorte. O resto e sim ou nao.
          </p>

          <div className="mt-6 flex gap-3 overflow-x-auto pb-1">
            {featured.slice(0, 6).map((l) =>
              l ? (
                <article key={l.id} className="relative h-36 w-24 shrink-0 overflow-hidden rounded-lg shadow-[0_0_0_1px_rgba(228,193,90,0.35)]">
                  <img src={legendArt(l)} alt="" className="h-full w-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-2">
                    <p className="font-display text-lg leading-none text-gold">{l.number}</p>
                    <p className="mt-0.5 truncate text-[10px] font-medium uppercase tracking-wide text-fg">{l.name.split(" ").slice(-1)}</p>
                  </div>
                </article>
              ) : null,
            )}
          </div>

          <div className="mt-7 flex flex-col gap-3">
            {game && !game.retired ? (
              <Button size="lg" className="w-full" onClick={() => setScreen("hub")}>
                <Play className="size-4" />
                Continuar carreira
              </Button>
            ) : null}
            <Button size="lg" variant={game ? "outline" : "default"} className="w-full" onClick={newGame}>
              <RotateCcw className="size-4" />
              Nova carreira
            </Button>
          </div>
        </div>
      </div>
    </main>
  );
}

export function PitchBackdrop() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0">
      <img src="/landing-stadium.jpg" alt="" className="absolute inset-0 h-full w-full object-cover opacity-25" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(61,204,115,0.12),transparent_55%),linear-gradient(180deg,rgba(8,11,9,0.7),#080b09)]" />
      <svg className="absolute inset-0 h-full w-full opacity-[0.1]" viewBox="0 0 100 180" preserveAspectRatio="none">
        <rect x="6" y="8" width="88" height="164" fill="none" stroke="currentColor" className="text-pitch" strokeWidth="0.6" />
        <line x1="6" y1="90" x2="94" y2="90" stroke="currentColor" className="text-pitch" strokeWidth="0.5" />
        <circle cx="50" cy="90" r="14" fill="none" stroke="currentColor" className="text-pitch" strokeWidth="0.5" />
      </svg>
    </div>
  );
}
