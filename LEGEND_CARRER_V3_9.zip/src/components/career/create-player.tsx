import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Camera, Shirt, UserRound } from "lucide-react";
import { PlayerCard } from "@/components/career/player-card";
import { PlayerFace, resizePhoto } from "@/components/career/player-face";
import { ClubBadge } from "@/components/career/club-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { NATIONS, POSITIONS, defaultShirt, flagUrl, idolsFor, legendArt, nationById } from "@/lib/career/data";
import { ATTR_LABELS } from "@/lib/career/data";
import { rollAcademy, rollPlayer } from "@/lib/career/engine";
import type { Appearance, GameMode, Position } from "@/lib/career/types";
import { useCareer } from "@/store/career-store";
import { cn } from "@/lib/utils";
import { PitchBackdrop } from "./landing";

const HAIRS: Appearance["hair"][] = ["buzz", "short", "fade", "long", "curly"];
const FACIAL: Appearance["facial"][] = ["none", "stubble", "beard"];

export function CreatePlayer() {
  const create = useCareer((s) => s.createCareer);
  const setScreen = useCareer((s) => s.setScreen);
  const [step, setStep] = useState(0);
  const [name, setName] = useState("Gabriel Silva");
  const [nationId, setNationId] = useState("bra");
  const [position, setPosition] = useState<Position>("ST");
  const [shirt, setShirt] = useState(9);
  const [mode, setMode] = useState<GameMode>("complete");
  const [idolId, setIdolId] = useState<string>("");
  const [appearance, setAppearance] = useState<Appearance>({
    skin: 2,
    hair: "short",
    facial: "none",
    photo: null,
  });
  const [seed] = useState(() => Math.floor(Math.random() * 1e9));

  const idols = idolsFor(position);
  const chosenIdol = idols.find((l) => l.id === idolId) ?? idols[0];

  const academy = useMemo(() => rollAcademy(nationId, seed), [nationId, seed]);
  const player = useMemo(
    () =>
      rollPlayer({
        name,
        nationId,
        position,
        shirtNumber: shirt,
        idolId: chosenIdol?.id,
        appearance,
        seed,
      }),
    [name, nationId, position, shirt, chosenIdol?.id, appearance, seed],
  );

  const steps = ["Identidade", "Nacao", "Posicao", "Idolo", "Sorte", "Modo"];

  function next() {
    if (step === 2 && !idolId) setIdolId(idols[0]?.id ?? "");
    if (step < steps.length - 1) setStep(step + 1);
    else {
      create({
        name: name.trim() || "Jogador",
        nationId,
        position,
        shirtNumber: shirt,
        clubId: academy.id,
        mode,
        player: {
          ...player,
          name: name.trim() || "Jogador",
          appearance,
          idolId: chosenIdol?.id ?? player.idolId,
          idolName: chosenIdol?.name ?? player.idolName,
        },
      });
    }
  }

  async function onPhoto(file: File | undefined) {
    if (!file) return;
    const photo = await resizePhoto(file);
    setAppearance((a) => ({ ...a, photo }));
  }

  return (
    <main className="relative mx-auto flex min-h-dvh max-w-lg flex-col px-4 pb-28 pt-6">
      <PitchBackdrop />
      <div className="relative">
        <button
          type="button"
          className="mb-4 flex h-11 items-center gap-1 text-sm text-muted"
          onClick={() => (step === 0 ? setScreen("landing") : setStep(step - 1))}
        >
          <ChevronLeft className="size-4" />
          Voltar
        </button>
        <p className="text-[11px] font-medium uppercase tracking-[0.22em] text-gold">Nova carreira</p>
        <h1 className="font-display mt-1 text-3xl text-fg">{steps[step]}</h1>
        <div className="mt-4 flex gap-1.5">
          {steps.map((_, i) => (
            <span key={i} className={cn("h-1 flex-1 rounded-full", i <= step ? "bg-gold" : "bg-surface-2")} />
          ))}
        </div>

        {step === 0 && (
          <section className="mt-6 space-y-5">
            <label className="block">
              <span className="mb-1.5 block text-xs uppercase tracking-wider text-muted">Nome</span>
              <Input value={name} onChange={(e) => setName(e.target.value)} maxLength={28} />
            </label>
            <div className="flex items-center gap-4">
              <div className="size-24 overflow-hidden rounded-xl border border-border bg-surface">
                <PlayerFace appearance={appearance} />
              </div>
              <div className="flex flex-1 flex-col gap-2">
                <label className="flex h-11 cursor-pointer items-center justify-center gap-2 rounded-md border border-border bg-surface text-sm">
                  <Camera className="size-4" />
                  Colocar foto
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => void onPhoto(e.target.files?.[0])}
                  />
                </label>
                <Button
                  type="button"
                  variant="outline"
                  className="h-11 w-full"
                  onClick={() => setAppearance((a) => ({ ...a, photo: null }))}
                >
                  <UserRound className="size-4" />
                  {appearance.photo ? "Retirar foto · 2D" : "Personagem 2D"}
                </Button>
              </div>
            </div>
            <div>
              <p className="mb-2 text-xs uppercase tracking-wider text-muted">Pele</p>
              <div className="flex gap-2">
                {[0, 1, 2, 3, 4].map((i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setAppearance((a) => ({ ...a, skin: i, photo: a.photo }))}
                    className={cn("size-9 rounded-full border", appearance.skin === i ? "border-gold" : "border-border")}
                    style={{ background: ["#f3d2b5", "#e0b184", "#c68642", "#8d5524", "#4a2c14"][i] }}
                  />
                ))}
              </div>
            </div>
            <div>
              <p className="mb-2 text-xs uppercase tracking-wider text-muted">Cabelo</p>
              <div className="flex flex-wrap gap-2">
                {HAIRS.map((h) => (
                  <button
                    key={h}
                    type="button"
                    onClick={() => setAppearance((a) => ({ ...a, hair: h }))}
                    className={cn(
                      "h-9 rounded-md px-3 text-xs",
                      appearance.hair === h ? "bg-gold text-gold-fg" : "bg-surface text-fg border border-border",
                    )}
                  >
                    {h}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="mb-2 text-xs uppercase tracking-wider text-muted">Rosto</p>
              <div className="flex flex-wrap gap-2">
                {FACIAL.map((f) => (
                  <button
                    key={f}
                    type="button"
                    onClick={() => setAppearance((a) => ({ ...a, facial: f }))}
                    className={cn(
                      "h-9 rounded-md px-3 text-xs",
                      appearance.facial === f ? "bg-gold text-gold-fg" : "bg-surface text-fg border border-border",
                    )}
                  >
                    {f === "none" ? "limpo" : f}
                  </button>
                ))}
              </div>
            </div>
          </section>
        )}

        {step === 1 && (
          <section className="mt-6">
            <p className="mb-3 text-sm text-muted">A base sai no sorteio da nacionalidade. Voce nao escolhe o clube.</p>
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
              {NATIONS.map((n) => (
                <button
                  key={n.id}
                  type="button"
                  onClick={() => setNationId(n.id)}
                  className={cn(
                    "flex h-14 items-center justify-center gap-1.5 rounded-md border px-2 text-xs font-medium",
                    nationId === n.id ? "border-gold bg-gold/10 text-gold" : "border-border bg-surface text-fg",
                  )}
                >
                  <img src={flagUrl(n.id)} alt="" className="h-3.5 w-5 rounded-sm object-cover" />
                  {n.code}
                </button>
              ))}
            </div>
            <p className="mt-3 text-xs text-muted">{nationById(nationId).name}</p>
          </section>
        )}

        {step === 2 && (
          <section className="mt-6">
            <PitchPicker
              value={position}
              onChange={(p) => {
                setPosition(p);
                setShirt(defaultShirt(p));
                setIdolId("");
              }}
            />
            <label className="mt-5 block">
              <span className="mb-1.5 flex items-center gap-2 text-xs uppercase tracking-wider text-muted">
                <Shirt className="size-3.5" />
                Numero da camisa
              </span>
              <Input
                type="number"
                min={1}
                max={99}
                value={shirt}
                onChange={(e) => setShirt(Math.max(1, Math.min(99, Number(e.target.value) || 1)))}
              />
            </label>
          </section>
        )}

        {step === 3 && (
          <section className="mt-6">
            <p className="mb-3 text-sm text-muted">
              Escolhe o idolo. Os da sua posicao puxam mais o estilo. Lendas mundiais tambem entram.
            </p>
            <div className="grid grid-cols-2 gap-2">
              {idols.map((l) => {
                const active = (idolId || idols[0]?.id) === l.id;
                const recommended = l.positions.includes(position);
                return (
                  <button
                    key={l.id}
                    type="button"
                    onClick={() => setIdolId(l.id)}
                    className={cn(
                      "overflow-hidden rounded-xl text-left shadow-[0_0_0_1px_rgba(255,255,255,0.06)]",
                      active ? "shadow-[0_0_0_1px_#e4c15a]" : "",
                    )}
                  >
                    <div className="relative h-28">
                      <img src={legendArt(l)} alt="" className="h-full w-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
                      <span className="absolute left-2 top-2 font-display text-2xl text-gold">{l.number}</span>
                      {recommended ? (
                        <span className="absolute right-2 top-2 rounded-full bg-gold/90 px-2 py-0.5 text-[10px] font-medium uppercase text-gold-fg">
                          posicao
                        </span>
                      ) : (
                        <span className="absolute right-2 top-2 rounded-full bg-black/60 px-2 py-0.5 text-[10px] font-medium uppercase text-gold">
                          lenda
                        </span>
                      )}
                      <div className="absolute inset-x-0 bottom-0 p-2">
                        <p className="text-sm font-medium leading-tight text-fg">{l.name}</p>
                        <p className="text-[10px] text-muted">
                          {l.nation} · {l.positions.join("/")} · {l.era}
                        </p>
                      </div>
                    </div>
                    <p className="bg-surface px-2 py-2 text-[11px] text-muted">{l.blurb}</p>
                  </button>
                );
              })}
            </div>
          </section>
        )}

        {step === 4 && (
          <section className="mt-6 flex flex-col items-center">
            <PlayerCard player={player} clubId={academy.id} />
            <div className="mt-4 flex items-center gap-2 rounded-xl border border-border bg-surface px-3 py-2">
              <ClubBadge clubId={academy.id} size="sm" />
              <div>
                <p className="text-sm text-fg">Base: {academy.name}</p>
                <p className="text-[11px] text-muted">Sorteada pela nacionalidade</p>
              </div>
            </div>
            <p className="mt-3 text-center text-xs text-muted">
              Cartinha bronze · OVR {player.overall} · teto {player.potential}
            </p>
            <ul className="mt-3 w-full space-y-1.5">
              {player.steals.map((s) => (
                <li
                  key={`${s.legend}-${s.attr}`}
                  className={cn(
                    "rounded-lg px-3 py-2 text-sm text-fg",
                    s.rare ? "border border-gold bg-gold/15" : "border border-gold/30 bg-gold/10",
                  )}
                >
                  {s.rare ? "Roubo lendario" : "Roubo"}: {ATTR_LABELS[s.attr].long} de {s.legend}
                </li>
              ))}
              <li className="rounded-lg border border-border bg-surface px-3 py-2 text-sm text-muted">
                Idolo: {player.idolName}
              </li>
            </ul>
          </section>
        )}

        {step === 5 && (
          <section className="mt-6 grid gap-3">
            <ModeCard
              active={mode === "complete"}
              title="Modo completo"
              copy="Simula temporada por temporada. Voce so decide sim ou nao: clube, contrato, publi. Ganha pontos para gastar no overall."
              onClick={() => setMode("complete")}
            />
            <ModeCard
              active={mode === "fast"}
              title="Modo Fast"
              copy="Simula a carreira inteira de uma vez e entrega o livro: jogos, titulos, fortuna e o lugar na historia."
              onClick={() => setMode("fast")}
            />
          </section>
        )}
      </div>

      <div className="fixed inset-x-0 bottom-0 z-10 border-t border-border bg-bg/95 px-4 py-3 backdrop-blur-sm">
        <div className="mx-auto max-w-lg">
          <Button size="lg" className="w-full" onClick={next}>
            {step === steps.length - 1 ? "Entrar no hub" : "Continuar"}
            <ChevronRight className="size-4" />
          </Button>
        </div>
      </div>
    </main>
  );
}

function ModeCard({
  active,
  title,
  copy,
  onClick,
}: {
  active: boolean;
  title: string;
  copy: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn("rounded-xl border p-4 text-left", active ? "border-gold bg-gold/10" : "border-border bg-surface")}
    >
      <div className="flex items-center justify-between gap-2">
        <p className="font-medium text-fg">{title}</p>
        {active ? <Badge variant="gold">Ativo</Badge> : null}
      </div>
      <p className="mt-1 text-sm leading-relaxed text-muted">{copy}</p>
    </button>
  );
}

function PitchPicker({ value, onChange }: { value: Position; onChange: (p: Position) => void }) {
  const lines = [0, 1, 2, 3, 4, 5, 6];
  return (
    <div className="relative overflow-hidden rounded-xl border border-pitch/30 bg-pitch-dim/40 p-3">
      <p className="mb-2 text-center text-[11px] uppercase tracking-wider text-pitch">Toque no campo</p>
      <div className="flex flex-col gap-2">
        {lines.map((line) => {
          const row = POSITIONS.filter((p) => p.line === line);
          const slots = [0, 1, 2].map((slot) => row.find((p) => p.slot === slot) ?? null);
          return (
            <div key={line} className="grid grid-cols-3 gap-2">
              {slots.map((p, i) =>
                p ? (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => onChange(p.id)}
                    className={cn(
                      "h-11 rounded-md text-xs font-semibold",
                      value === p.id ? "bg-gold text-gold-fg" : "bg-bg/50 text-fg hover:bg-bg/70",
                    )}
                  >
                    {p.id}
                  </button>
                ) : (
                  <span key={`empty-${line}-${i}`} />
                ),
              )}
            </div>
          );
        })}
      </div>
      <p className="mt-2 text-center text-xs text-muted">{POSITIONS.find((p) => p.id === value)?.name}</p>
    </div>
  );
}
