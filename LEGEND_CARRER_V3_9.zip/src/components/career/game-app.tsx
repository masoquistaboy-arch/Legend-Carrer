import { useEffect, useState } from "react";
import { Briefcase, House, Sparkles, Trophy } from "lucide-react";
import { AgentPanel } from "@/components/career/agent-panel";
import { CareerView } from "@/components/career/career-view";
import { CreatePlayer } from "@/components/career/create-player";
import { Hub } from "@/components/career/hub";
import { Landing } from "@/components/career/landing";
import { MatchView } from "@/components/career/match-view";
import { OffersView } from "@/components/career/offers-view";
import { CoachView, FastRecapView, RetiredView, SeasonRecapView } from "@/components/career/recap-views";
import { TrainingView } from "@/components/career/training-view";
import type { Screen } from "@/lib/career/types";
import { useCareer } from "@/store/career-store";
import { cn } from "@/lib/utils";

const NAV: { id: Screen; label: string; icon: typeof House }[] = [
  { id: "hub", label: "Inicio", icon: House },
  { id: "agent", label: "Empresario", icon: Briefcase },
  { id: "training", label: "Pontos", icon: Sparkles },
  { id: "career", label: "Carreira", icon: Trophy },
];

export function GameApp() {
  const [ready, setReady] = useState(false);
  const screen = useCareer((s) => s.screen);
  const game = useCareer((s) => s.game);
  const recap = useCareer((s) => s.recap);
  const fastRecap = useCareer((s) => s.fastRecap);
  const toast = useCareer((s) => s.toast);
  const clearToast = useCareer((s) => s.clearToast);
  const setScreen = useCareer((s) => s.setScreen);

  useEffect(() => {
    const result = useCareer.persist.rehydrate();
    void Promise.resolve(result).then(() => setReady(true));
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(clearToast, 2800);
    return () => window.clearTimeout(t);
  }, [toast, clearToast]);

  if (!ready) {
    return <Landing />;
  }

  if (screen === "landing" || (!game && screen !== "create")) return <Landing />;
  if (screen === "create" || !game) return <CreatePlayer />;

  const hideNav =
    screen === "season-recap" || screen === "fast-recap" || screen === "retired" || screen === "coach";

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <div className="mx-auto flex min-h-dvh max-w-lg flex-col px-4 pb-24 pt-5">
        {screen === "hub" && <Hub game={game} />}
        {screen === "match" && <MatchView game={game} />}
        {screen === "agent" && <AgentPanel game={game} />}
        {screen === "training" && <TrainingView game={game} />}
        {screen === "career" && <CareerView game={game} />}
        {screen === "offers" && <OffersView game={game} />}
        {screen === "season-recap" && recap && <SeasonRecapView recap={recap} game={game} />}
        {screen === "fast-recap" && fastRecap && <FastRecapView recap={fastRecap} />}
        {screen === "retired" && <RetiredView game={game} />}
        {screen === "coach" && <CoachView game={game} />}
        {screen === "season-recap" && !recap && <Hub game={game} />}
        {screen === "fast-recap" && !fastRecap && <Hub game={game} />}
      </div>

      {!hideNav ? (
        <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm">
          <div className="mx-auto grid max-w-lg grid-cols-4">
            {NAV.map((item) => {
              const active = screen === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setScreen(item.id)}
                  className={cn(
                    "flex h-14 flex-col items-center justify-center gap-0.5 text-[11px]",
                    active ? "text-gold" : "text-muted",
                  )}
                >
                  <item.icon className="size-4" />
                  {item.label}
                </button>
              );
            })}
          </div>
        </nav>
      ) : null}

      {toast ? (
        <div className="pointer-events-none fixed inset-x-0 bottom-20 z-30 flex justify-center px-4">
          <p className="max-w-sm rounded-lg bg-surface px-3 py-2 text-center text-sm text-fg panel">
            {toast}
          </p>
        </div>
      ) : null}
    </div>
  );
}
