import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PlayerCard } from "@/components/career/player-card";
import { ClubBadge } from "@/components/career/club-badge";
import { formatFollowers, formatFortune, formatMoney } from "@/lib/career/engine";
import { clubById } from "@/lib/career/data";
import type { FastRecap, GameState, SeasonRecap } from "@/lib/career/types";
import { useCareer } from "@/store/career-store";

export function SeasonRecapView({ recap, game }: { recap: SeasonRecap; game: GameState }) {
  const setScreen = useCareer((s) => s.setScreen);
  const yesRaise = useCareer((s) => s.yesRaise);
  const noRaise = useCareer((s) => s.noRaise);
  const yesBrand = useCareer((s) => s.yesBrand);
  const noBrand = useCareer((s) => s.noBrand);
  const hangBoots = useCareer((s) => s.hangBoots);

  return (
    <div className="space-y-4 pb-4">
      <header>
        <p className="text-[11px] uppercase tracking-[0.2em] text-gold">Fim de temporada</p>
        <h1 className="font-display text-3xl text-fg">{recap.year}</h1>
        <p className="text-sm text-muted">
          {recap.clubName} · {recap.leaguePlace}º na liga
        </p>
      </header>

      {recap.sacked ? (
        <p className="rounded-xl border border-danger/40 bg-danger/10 px-4 py-3 text-sm text-danger">
          O clube rescindiu por baixo rendimento. Voce escolhe o proximo destino.
        </p>
      ) : null}

      <div className="grid grid-cols-2 gap-2">
        <Tile k="Jogos" v={recap.stats.appearances} />
        <Tile k="Gols" v={recap.stats.goals} />
        <Tile k="Assistencias" v={recap.stats.assists} />
        <Tile k="Media" v={recap.stats.avgRating.toFixed(1)} />
      </div>

      <p className="rounded-xl bg-surface px-4 py-3 text-sm text-fg panel">
        Overall {recap.overallFrom} → {recap.overallTo} · cartinha {recap.cardFrom} → {recap.cardTo}
        <br />
        Seguidores {formatFollowers(recap.followersFrom)} → {formatFollowers(recap.followersTo)}
        <br />
        Pontos ganhos: {recap.points}
      </p>

      <div className="flex flex-wrap gap-1.5">
        {recap.titles.length === 0 ? <span className="text-sm text-muted">Sem titulos.</span> : null}
        {recap.titles.map((t) => (
          <Badge key={t.id} variant="gold">
            {t.name}
          </Badge>
        ))}
      </div>

      {recap.highlights.length ? (
        <section>
          <h2 className="mb-2 text-xs uppercase tracking-wider text-muted">Partidas que ficaram</h2>
          <ul className="space-y-2">
            {recap.highlights.map((h, i) => (
              <li key={`${h.preview.week}-${i}`} className="rounded-lg bg-surface px-3 py-2 text-sm panel">
                <p className="text-fg">
                  {h.home ? h.playerTeam : h.opponent} {h.home ? h.goalsFor : h.goalsAgainst}–{h.home ? h.goalsAgainst : h.goalsFor}{" "}
                  {h.home ? h.opponent : h.playerTeam}
                </p>
                <p className="text-xs text-muted">
                  {h.competition} · nota {h.rating.toFixed(1)}
                  {h.goals ? ` · ${h.goals} gol(s)` : ""}
                  {h.motm ? " · craque" : ""}
                  {h.injured ? ` · ${h.injured.name}` : ""}
                </p>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {game.pendingRaise ? (
        <div className="rounded-xl border border-gold/35 bg-gold/10 p-4">
          <p className="text-sm font-medium text-fg">O clube oferece aumento.</p>
          <p className="text-xs text-muted">{formatMoney(game.pendingRaise, clubById(game.clubId).countryCode)}/sem. Sim ou nao.</p>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <Button onClick={yesRaise}>Aceitar</Button>
            <Button variant="outline" onClick={noRaise}>
              Recusar
            </Button>
          </div>
        </div>
      ) : null}

      {game.pendingBrand ? (
        <div className="rounded-xl border border-gold/35 bg-gold/10 p-4">
          <p className="text-sm font-medium text-fg">{game.pendingBrand.brand} quer publi.</p>
          <p className="text-xs text-muted">
            {formatMoney(game.pendingBrand.weekly, clubById(game.clubId).countryCode)}/sem · +{formatFollowers(game.pendingBrand.followersBoost)} seguidores
          </p>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <Button onClick={yesBrand}>Fechar</Button>
            <Button variant="outline" onClick={noBrand}>
              Recusar
            </Button>
          </div>
        </div>
      ) : null}

      {game.seasonPoints > 0 ? (
        <Button size="lg" variant="pitch" className="w-full" onClick={() => setScreen("training")}>
          Gastar {game.seasonPoints} ponto(s)
        </Button>
      ) : null}

      {recap.nextOffers.length > 0 || game.offers.length > 0 ? (
        <Button size="lg" className="w-full" onClick={() => setScreen("offers")}>
          Ver proposta(s)
        </Button>
      ) : (
        <Button size="lg" className="w-full" onClick={() => setScreen("hub")}>
          Proxima temporada
        </Button>
      )}

      {game.retired ? (
        <Button variant="outline" className="w-full" onClick={hangBoots}>
          Encerrar carreira
        </Button>
      ) : null}
    </div>
  );
}

export function FastRecapView({ recap }: { recap: FastRecap }) {
  const setScreen = useCareer((s) => s.setScreen);
  return (
    <div className="space-y-4 pb-4">
      <header>
        <p className="text-[11px] uppercase tracking-[0.2em] text-gold">Simulacao Fast</p>
        <h1 className="font-display text-3xl text-fg">{recap.years} temporada(s)</h1>
        <p className="text-sm text-muted">
          OVR {recap.overallFrom} → {recap.overallTo} · Fama {Math.round(recap.fameFrom)} → {Math.round(recap.fameTo)}
        </p>
      </header>
      <p className="rounded-xl bg-surface px-4 py-3 text-sm text-fg panel">
        Dinheiro ganho: {formatFortune(recap.moneyGained)}
      </p>
      <ol className="space-y-2">
        {recap.lines.map((line) => (
          <li key={`${line.season}-${line.clubId}`} className="rounded-xl bg-surface p-3 panel">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <ClubBadge clubId={line.clubId} size="sm" />
                <p className="text-sm font-medium text-fg">
                  {line.year} · {line.clubName}
                </p>
              </div>
              <p className="text-xs tabular-nums text-muted">OVR {line.overall}</p>
            </div>
            <p className="mt-1 text-xs text-muted">
              {line.appearances} j · {line.goals} g · {line.assists} a · media {line.avgRating.toFixed(1)}
              {line.injuryWeeks ? ` · ${line.injuryWeeks} sem. lesionado` : ""}
            </p>
            {line.titles.length ? (
              <div className="mt-2 flex flex-wrap gap-1">
                {line.titles.map((t) => (
                  <Badge key={t} variant="gold">
                    {t}
                  </Badge>
                ))}
              </div>
            ) : null}
          </li>
        ))}
      </ol>
      {recap.nextOffers.length > 0 ? (
        <Button size="lg" className="w-full" onClick={() => setScreen("offers")}>
          Proxima proposta
        </Button>
      ) : (
        <Button size="lg" className="w-full" onClick={() => setScreen("hub")}>
          Voltar ao hub
        </Button>
      )}
    </div>
  );
}

export function RetiredView({ game }: { game: GameState }) {
  const becomeCoach = useCareer((s) => s.becomeCoach);
  const newGame = useCareer((s) => s.newGame);
  const rank = game.historyRank;

  return (
    <div className="space-y-5 py-4">
      <header className="text-center">
        <p className="text-[11px] uppercase tracking-[0.2em] text-gold">Pendurou as chuteiras</p>
        <h1 className="font-display mt-1 text-4xl text-fg">{game.player.name}</h1>
        <p className="mt-2 text-sm text-muted">{game.retireReason ?? "Carreira encerrada."}</p>
        {rank ? (
          <p className="mt-3 font-display text-3xl text-gold">{rank.label}</p>
        ) : null}
        {rank ? <p className="mt-1 text-sm text-muted">{rank.copy}</p> : null}
      </header>

      <div className="flex justify-center">
        <PlayerCard player={{ ...game.player, overall: game.peakOverall, cardStyle: game.player.cardStyle }} clubId={game.clubId} />
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Tile k="Jogos" v={game.stats.appearances} />
        <Tile k="Gols" v={game.stats.goals} />
        <Tile k="Assistencias" v={game.stats.assists} />
        <Tile k="Titulos" v={game.titles.length} />
        <Tile k="Pico OVR" v={game.peakOverall} />
        <Tile k="Fortuna" v={formatFortune(game.money)} />
      </div>

      {!game.coach ? (
        <div className="rounded-xl border border-gold/35 bg-gold/10 p-4">
          <p className="text-sm font-medium text-fg">Virar tecnico?</p>
          <p className="mt-1 text-xs text-muted">
            So existe o Fast de tecnico. Uma simulacao unica, sem voltar atras, e o livro fecha.
          </p>
          <Button size="lg" className="mt-3 w-full" onClick={becomeCoach}>
            Simular carreira de tecnico
          </Button>
          <Button variant="ghost" className="mt-2 w-full" onClick={newGame}>
            Encerrar sem o banco
          </Button>
        </div>
      ) : (
        <Button size="lg" className="w-full" onClick={newGame}>
          Nova lenda
        </Button>
      )}
    </div>
  );
}

export function CoachView({ game }: { game: GameState }) {
  const newGame = useCareer((s) => s.newGame);
  const coach = game.coach;
  const rank = game.historyRank;

  return (
    <div className="space-y-5 pb-8">
      <header className="text-center">
        <p className="text-[11px] uppercase tracking-[0.2em] text-gold">Livro fechado</p>
        <h1 className="font-display mt-1 text-4xl text-fg">{game.player.name}</h1>
        <p className="mt-3 font-display text-3xl text-gold">
          {rank?.label ?? "Jogador"} {coach ? `· ${coach.rank.label}` : ""}
        </p>
        <p className="mt-2 text-sm text-muted">{game.lifeVerdict ?? rank?.copy}</p>
      </header>

      <div className="flex justify-center">
        <PlayerCard player={{ ...game.player, overall: game.peakOverall }} clubId={game.stats.clubs[0]} />
      </div>

      <section className="rounded-xl bg-surface p-4 panel">
        <p className="text-xs uppercase tracking-wider text-muted">Jogador</p>
        <p className="mt-2 text-sm text-fg">
          Pico {game.peakOverall} OVR · {game.stats.appearances} jogos · {game.stats.goals} gols · {game.stats.assists} assist. · media{" "}
          {game.stats.avgRating.toFixed(2)}
        </p>
        <p className="text-sm text-muted">
          {game.titles.length} titulos em campo · fortuna {formatFortune(game.money)} · {formatFollowers(game.followers)} seguidores
        </p>
      </section>

      {coach ? (
        <section className="rounded-xl bg-surface p-4 panel">
          <p className="text-xs uppercase tracking-wider text-muted">Tecnico · Fast</p>
          <p className="mt-2 text-sm text-fg">
            {coach.years} anos no banco · {coach.titles} titulos · {coach.rank.label}
          </p>
          <p className="text-xs text-muted">{coach.rank.copy}</p>
          <ol className="mt-3 space-y-2">
            {coach.lines.map((line) => (
              <li key={line.year} className="flex items-start justify-between gap-2 text-sm">
                <span className="text-fg">
                  {line.year} · {line.clubName}
                </span>
                <span className="text-right text-xs text-muted">
                  {line.place}º{line.titles.length ? ` · ${line.titles.join(", ")}` : ""}
                </span>
              </li>
            ))}
          </ol>
        </section>
      ) : null}

      <section>
        <h2 className="mb-2 text-xs uppercase tracking-wider text-muted">Vitrine</h2>
        {game.titles.length === 0 ? (
          <p className="text-sm text-muted">Nenhum titulo como jogador.</p>
        ) : (
          <ul className="space-y-1.5">
            {game.titles.map((t) => (
              <li key={t.id} className="flex justify-between rounded-lg bg-surface px-3 py-2 text-sm panel">
                <span>{t.name}</span>
                <span className="text-muted">T{t.season}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <Button size="lg" className="w-full" onClick={newGame}>
        Nova lenda
      </Button>
    </div>
  );
}

function Tile({ k, v }: { k: string; v: number | string }) {
  return (
    <div className="rounded-xl bg-surface px-3 py-3 panel">
      <p className="text-[11px] uppercase tracking-wider text-muted">{k}</p>
      <p className="font-display text-2xl tabular-nums text-fg">{v}</p>
    </div>
  );
}
