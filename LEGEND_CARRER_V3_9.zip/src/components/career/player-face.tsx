import type { Appearance } from "@/lib/career/types";
import { cn } from "@/lib/utils";

const SKIN = ["#f3d2b5", "#e0b184", "#c68642", "#8d5524", "#4a2c14"];
const HAIR = ["#1a120c", "#2b1b10", "#4a2e14", "#111111", "#3d2a1a"];

export function PlayerFace({
  appearance,
  className,
}: {
  appearance: Appearance;
  className?: string;
}) {
  if (appearance.photo) {
    return (
      <img
        src={appearance.photo}
        alt=""
        className={cn("h-full w-full object-cover", className)}
      />
    );
  }
  const skin = SKIN[appearance.skin] ?? SKIN[2];
  const hair = HAIR[appearance.skin] ?? HAIR[0];
  return (
    <svg viewBox="0 0 80 96" className={cn("h-full w-auto", className)} aria-hidden>
      <ellipse cx="40" cy="90" rx="22" ry="10" fill={skin} opacity="0.4" />
      <ellipse cx="40" cy="44" rx="22" ry="28" fill={skin} />
      {appearance.hair !== "buzz" ? (
        <path
          d={
            appearance.hair === "long"
              ? "M18 40c2-22 14-32 22-32s20 10 22 32c-6-10-14-14-22-14s-16 4-22 14z"
              : appearance.hair === "curly"
                ? "M16 38c0-18 10-28 24-28s24 10 24 28c-5-8-12-12-24-12s-19 4-24 12z"
                : appearance.hair === "fade"
                  ? "M20 36c2-16 10-24 20-24s18 8 20 24H20z"
                  : "M18 34c2-14 12-22 22-22s20 8 22 22H18z"
          }
          fill={hair}
        />
      ) : (
        <ellipse cx="40" cy="20" rx="18" ry="8" fill={hair} />
      )}
      <circle cx="32" cy="42" r="2.2" fill="#1a1a1a" />
      <circle cx="48" cy="42" r="2.2" fill="#1a1a1a" />
      <path d="M36 52c2 2 6 2 8 0" fill="none" stroke="#5c3a28" strokeWidth="1.4" strokeLinecap="round" />
      {appearance.facial !== "none" ? (
        <path
          d={appearance.facial === "beard" ? "M28 54c2 12 8 16 12 16s10-4 12-16c-4 6-8 8-12 8s-8-2-12-8z" : "M34 56c2 4 4 5 6 5s4-1 6-5"}
          fill={hair}
          opacity="0.85"
        />
      ) : null}
    </svg>
  );
}

export function resizePhoto(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const canvas = document.createElement("canvas");
      const size = 256;
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        reject(new Error("canvas"));
        return;
      }
      const min = Math.min(img.width, img.height);
      const sx = (img.width - min) / 2;
      const sy = (img.height - min) / 2;
      ctx.drawImage(img, sx, sy, min, min, 0, 0, size, size);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/jpeg", 0.72));
    };
    img.onerror = () => reject(new Error("image"));
    img.src = url;
  });
}
