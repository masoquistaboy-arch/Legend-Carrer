import { ATTR_LABELS, nationById } from "@/lib/career/data";
import { clubById } from "@/lib/career/data";
import type { CardStyle, Player } from "@/lib/career/types";
import { cn } from "@/lib/utils";
import { PlayerFace } from "@/components/career/player-face";
import { ClubBadge } from "@/components/career/club-badge";

const STYLE: Record<CardStyle, string> = {
  bronze: "from-[#5c3d24] to-[#c4a074] text-[#2a1a0c]",
  silver: "from-[#4d555e] to-[#d5dde6] text-[#1c2228]",
  gold: "from-[#6e5614] to-[#f0d36a] text-[#1a1406]",
  rare: "from-[#1a2a22] to-[#c9a227] text-[#0d120f]",
  fenomeno: "from-[#0b0f0c] via-[#1d3a28] to-[#e4c15a] text-[#f4f7f4]",
};

export function PlayerCard({
  player,
  clubId,
  compact = false,
  className,
}: {
  player: Player;
  clubId?: string;
  compact?: boolean;
  className?: string;
}) {
  const nation = nationById(player.nationId);
  const club = clubId ? clubById(clubId) : null;
  const pairs = [
    ["pace", "shooting"],
    ["passing", "dribbling"],
    ["defending", "physical"],
  ] as const;

  return (
    <article
      className={cn(
        "relative overflow-hidden rounded-xl bg-linear-to-b p-3 shadow-[0_0_0_1px_rgba(255,255,255,0.08)]",
        STYLE[player.cardStyle],
        compact ? "w-[168px]" : "w-[228px]",
        className,
      )}
    >
      <div className="pointer-events-none absolute inset-0 opacity-30 mix-blend-overlay card-sheen" />
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-display text-4xl font-extrabold leading-none tabular-nums">{player.overall}</p>
          <p className="mt-0.5 text-xs font-semibold tracking-[0.18em]">{player.position}</p>
        </div>
        <div className="flex flex-col items-end gap-1">
          {clubId ? <ClubBadge clubId={clubId} size="sm" /> : null}
          <p className="text-[10px] font-semibold uppercase tracking-widest opacity-80">{player.cardStyle}</p>
        </div>
      </div>
      <div className={cn("mx-auto my-2 overflow-hidden rounded-md", compact ? "h-16 w-16" : "h-28 w-28")}>
        <PlayerFace appearance={player.appearance} />
      </div>
      <p className={cn("text-center font-display uppercase tracking-wide", compact ? "text-base" : "text-xl")}>
        {player.name}
      </p>
      <p className="mt-0.5 text-center text-[10px] font-medium uppercase tracking-[0.16em] opacity-80">
        {player.playStyle} · #{player.shirtNumber}
      </p>
      {!compact && (
        <div className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1 text-[11px] font-semibold tabular-nums">
          {pairs.flat().map((k) => (
            <div key={k} className="flex items-baseline justify-between border-b border-current/15 pb-0.5">
              <span className="opacity-70">{ATTR_LABELS[k].short}</span>
              <span>{player.attributes[k]}</span>
            </div>
          ))}
          <div className="col-span-2 flex items-baseline justify-between border-b border-current/15 pb-0.5">
            <span className="opacity-70">{ATTR_LABELS.vision.short}</span>
            <span>{player.attributes.vision}</span>
          </div>
        </div>
      )}
      <div className="mt-3 flex items-center justify-between text-[10px] font-semibold uppercase tracking-wider opacity-80">
        <span>{nation.code}</span>
        <span>{club?.shortName ?? "LIVRE"}</span>
        <span>{player.age}a</span>
      </div>
    </article>
  );
}
