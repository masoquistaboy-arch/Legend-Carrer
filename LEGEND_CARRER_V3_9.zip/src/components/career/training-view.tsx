import { ATTR_KEYS, ATTR_LABELS } from "@/lib/career/data";
import { Button } from "@/components/ui/button";
import { StatBar } from "@/components/career/stat-bar";
import type { GameState } from "@/lib/career/types";
import { useCareer } from "@/store/career-store";

export function TrainingView({ game }: { game: GameState }) {
  const spend = useCareer((s) => s.spend);
  const setScreen = useCareer((s) => s.setScreen);
  const points = game.seasonPoints;

  return (
    <div className="space-y-4 pb-4">
      <header>
        <p className="text-[11px] uppercase tracking-[0.2em] text-gold">Pontos da temporada</p>
        <h1 className="font-display text-3xl text-fg">Evolucao</h1>
        <p className="text-sm text-muted">
          {points} ponto(s) · potencial {game.player.potential} · {game.player.age} anos
        </p>
      </header>

      <div className="space-y-3 rounded-xl bg-surface p-4 panel">
        {ATTR_KEYS.map((k) => (
          <StatBar key={k} label={ATTR_LABELS[k].long} value={game.player.attributes[k]} />
        ))}
      </div>

      {points <= 0 ? (
        <p className="rounded-xl bg-surface px-4 py-3 text-sm text-muted panel">
          Os pontos saem no fim de cada temporada, de acordo com jogos, gols, nota e titulos. No Fast o jogo gasta sozinho.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-2">
          {ATTR_KEYS.map((k) => (
            <Button key={k} variant="outline" onClick={() => spend(k)}>
              +1 {ATTR_LABELS[k].short}
            </Button>
          ))}
        </div>
      )}

      <Button variant="ghost" className="w-full" onClick={() => setScreen("hub")}>
        Voltar
      </Button>
    </div>
  );
}
