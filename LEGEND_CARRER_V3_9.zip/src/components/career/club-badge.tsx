import { useState } from "react";
import { clubById, clubLogo } from "@/lib/career/data";
import { cn } from "@/lib/utils";

export function ClubBadge({ clubId, size = "md", className }: { clubId: string; size?: "sm" | "md" | "lg"; className?: string }) {
  const club = clubById(clubId);
  const src = clubLogo(clubId);
  const [failed, setFailed] = useState(false);
  const dim = size === "sm" ? "size-8" : size === "lg" ? "size-14" : "size-10";

  if (src && !failed) {
    return (
      <img
        src={src}
        alt={club.name}
        className={cn("object-contain", dim, className)}
        onError={() => setFailed(true)}
      />
    );
  }

  return (
    <span
      className={cn("inline-flex items-center justify-center rounded-md text-[10px] font-bold", dim, className)}
      style={{ background: club.colors[0], color: club.colors[1] }}
    >
      {club.shortName.slice(0, 3)}
    </span>
  );
}
