import type { AttrKey, Club, Legend, Nation, Position } from "./types";

export const NATIONS: Nation[] = [
  { id: "bra", name: "Brasil", code: "BRA" },
  { id: "arg", name: "Argentina", code: "ARG" },
  { id: "por", name: "Portugal", code: "POR" },
  { id: "uru", name: "Uruguai", code: "URU" },
  { id: "fra", name: "Franca", code: "FRA" },
  { id: "esp", name: "Espanha", code: "ESP" },
  { id: "eng", name: "Inglaterra", code: "ENG" },
  { id: "ger", name: "Alemanha", code: "GER" },
  { id: "ita", name: "Italia", code: "ITA" },
  { id: "ned", name: "Holanda", code: "NED" },
  { id: "bel", name: "Belgica", code: "BEL" },
  { id: "cro", name: "Croacia", code: "CRO" },
  { id: "nga", name: "Nigeria", code: "NGA" },
  { id: "sen", name: "Senegal", code: "SEN" },
  { id: "civ", name: "Costa do Marfim", code: "CIV" },
  { id: "mar", name: "Marrocos", code: "MAR" },
  { id: "jpn", name: "Japao", code: "JPN" },
  { id: "kor", name: "Coreia do Sul", code: "KOR" },
  { id: "col", name: "Colombia", code: "COL" },
  { id: "chi", name: "Chile", code: "CHI" },
  { id: "par", name: "Paraguai", code: "PAR" },
  { id: "ecu", name: "Equador", code: "ECU" },
  { id: "gha", name: "Gana", code: "GHA" },
  { id: "cmr", name: "Camaroes", code: "CMR" },
  { id: "usa", name: "Estados Unidos", code: "USA" },
  { id: "mex", name: "Mexico", code: "MEX" },
];

export const POSITIONS: { id: Position; name: string; line: number; slot: number }[] = [
  { id: "ST", name: "Centroavante", line: 0, slot: 1 },
  { id: "LW", name: "Ponta esquerda", line: 1, slot: 0 },
  { id: "RW", name: "Ponta direita", line: 1, slot: 2 },
  { id: "CAM", name: "Meia ofensivo", line: 2, slot: 1 },
  { id: "LM", name: "Meia esquerda", line: 3, slot: 0 },
  { id: "CM", name: "Meio-campo", line: 3, slot: 1 },
  { id: "RM", name: "Meia direita", line: 3, slot: 2 },
  { id: "CDM", name: "Volante", line: 4, slot: 1 },
  { id: "LB", name: "Lateral esquerdo", line: 5, slot: 0 },
  { id: "CB", name: "Zagueiro", line: 5, slot: 1 },
  { id: "RB", name: "Lateral direito", line: 5, slot: 2 },
  { id: "GK", name: "Goleiro", line: 6, slot: 1 },
];

export const ATTR_LABELS: Record<AttrKey, { short: string; long: string }> = {
  pace: { short: "RIT", long: "Ritmo" },
  shooting: { short: "FIN", long: "Finalizacao" },
  passing: { short: "PAS", long: "Passe" },
  dribbling: { short: "DRI", long: "Drible" },
  defending: { short: "DEF", long: "Defesa" },
  physical: { short: "FIS", long: "Fisico" },
  vision: { short: "QI", long: "QI de jogo" },
};

export const ATTR_KEYS: AttrKey[] = [
  "pace",
  "shooting",
  "passing",
  "dribbling",
  "defending",
  "physical",
  "vision",
];

export const POSITION_WEIGHTS: Record<Position, Record<AttrKey, number>> = {
  ST: { pace: 0.16, shooting: 0.3, passing: 0.1, dribbling: 0.16, defending: 0.04, physical: 0.14, vision: 0.1 },
  LW: { pace: 0.24, shooting: 0.14, passing: 0.14, dribbling: 0.24, defending: 0.04, physical: 0.08, vision: 0.12 },
  RW: { pace: 0.24, shooting: 0.14, passing: 0.14, dribbling: 0.24, defending: 0.04, physical: 0.08, vision: 0.12 },
  CAM: { pace: 0.1, shooting: 0.14, passing: 0.22, dribbling: 0.18, defending: 0.06, physical: 0.08, vision: 0.22 },
  CM: { pace: 0.08, shooting: 0.1, passing: 0.24, dribbling: 0.12, defending: 0.14, physical: 0.14, vision: 0.18 },
  CDM: { pace: 0.1, shooting: 0.06, passing: 0.18, dribbling: 0.08, defending: 0.26, physical: 0.2, vision: 0.12 },
  LM: { pace: 0.2, shooting: 0.1, passing: 0.18, dribbling: 0.18, defending: 0.1, physical: 0.1, vision: 0.14 },
  RM: { pace: 0.2, shooting: 0.1, passing: 0.18, dribbling: 0.18, defending: 0.1, physical: 0.1, vision: 0.14 },
  CB: { pace: 0.12, shooting: 0.04, passing: 0.12, dribbling: 0.06, defending: 0.32, physical: 0.24, vision: 0.1 },
  LB: { pace: 0.22, shooting: 0.06, passing: 0.16, dribbling: 0.12, defending: 0.2, physical: 0.14, vision: 0.1 },
  RB: { pace: 0.22, shooting: 0.06, passing: 0.16, dribbling: 0.12, defending: 0.2, physical: 0.14, vision: 0.1 },
  GK: { pace: 0.08, shooting: 0.04, passing: 0.14, dribbling: 0.08, defending: 0.3, physical: 0.16, vision: 0.2 },
};

export const PLAY_STYLES: Record<Position, string[]> = {
  ST: ["Cacador", "Raposa da area", "Homem-alvo", "Finalizador"],
  LW: ["Pontinha", "Infiltrador", "Extremo classico"],
  RW: ["Pontinha", "Infiltrador", "Extremo classico"],
  CAM: ["Maestro", "Camisa 10", "Sombra"],
  CM: ["Box-to-box", "Organizador", "Motorzinho"],
  CDM: ["Destruidor", "Primeiro passe", "Ancora"],
  LM: ["Corredor", "Apoio", "Aberto"],
  RM: ["Corredor", "Apoio", "Aberto"],
  CB: ["Libero", "Brucutu", "Bola longa"],
  LB: ["Sobreposto", "Marcador", "Wing-back"],
  RB: ["Sobreposto", "Marcador", "Wing-back"],
  GK: ["Sweeper", "Classico", "Passador"],
};

export const CLUBS: Club[] = [
  { id: "fla", name: "Flamengo", shortName: "FLA", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 84, wageBudget: 90000, colors: ["#C41E3A", "#1a1a1a"] },
  { id: "pal", name: "Palmeiras", shortName: "PAL", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 85, wageBudget: 85000, colors: ["#006437", "#ffffff"] },
  { id: "sao", name: "Sao Paulo", shortName: "SAO", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 78, wageBudget: 55000, colors: ["#fe0000", "#ffffff"] },
  { id: "cor", name: "Corinthians", shortName: "COR", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 77, wageBudget: 50000, colors: ["#000000", "#ffffff"] },
  { id: "san", name: "Santos", shortName: "SAN", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 72, wageBudget: 28000, colors: ["#ffffff", "#000000"] },
  { id: "gre", name: "Gremio", shortName: "GRE", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 76, wageBudget: 42000, colors: ["#0d80bf", "#000000"] },
  { id: "int", name: "Internacional", shortName: "INT", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 76, wageBudget: 42000, colors: ["#c8102e", "#ffffff"] },
  { id: "cam", name: "Atletico-MG", shortName: "CAM", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 79, wageBudget: 52000, colors: ["#000000", "#ffffff"] },
  { id: "flu", name: "Fluminense", shortName: "FLU", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 75, wageBudget: 38000, colors: ["#7A0019", "#006633"] },
  { id: "bot", name: "Botafogo", shortName: "BOT", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 80, wageBudget: 60000, colors: ["#000000", "#ffffff"] },
  { id: "vas", name: "Vasco", shortName: "VAS", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 70, wageBudget: 22000, colors: ["#000000", "#ffffff"] },
  { id: "bah", name: "Bahia", shortName: "BAH", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 73, wageBudget: 30000, colors: ["#006cb6", "#ce0e2d"] },
  { id: "cru", name: "Cruzeiro", shortName: "CRU", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 74, wageBudget: 32000, colors: ["#2b57a3", "#ffffff"] },
  { id: "cap", name: "Athletico-PR", shortName: "CAP", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 71, wageBudget: 24000, colors: ["#e10600", "#000000"] },
  { id: "for", name: "Fortaleza", shortName: "FOR", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 72, wageBudget: 26000, colors: ["#1c3c8c", "#e10600"] },
  { id: "rbb", name: "Bragantino", shortName: "RBB", country: "Brasil", countryCode: "BRA", league: "Brasileirao", reputation: 74, wageBudget: 34000, colors: ["#ffffff", "#e10600"] },
  { id: "riv", name: "River Plate", shortName: "RIV", country: "Argentina", countryCode: "ARG", league: "Liga Profesional", reputation: 82, wageBudget: 45000, colors: ["#ffffff", "#e10600"] },
  { id: "boc", name: "Boca Juniors", shortName: "BOC", country: "Argentina", countryCode: "ARG", league: "Liga Profesional", reputation: 81, wageBudget: 42000, colors: ["#0033a0", "#f9be00"] },
  { id: "rma", name: "Real Madrid", shortName: "RMA", country: "Espanha", countryCode: "ESP", league: "La Liga", reputation: 97, wageBudget: 450000, colors: ["#ffffff", "#fbbc04"] },
  { id: "bar", name: "Barcelona", shortName: "BAR", country: "Espanha", countryCode: "ESP", league: "La Liga", reputation: 95, wageBudget: 380000, colors: ["#a50044", "#004d98"] },
  { id: "atm", name: "Atletico Madrid", shortName: "ATM", country: "Espanha", countryCode: "ESP", league: "La Liga", reputation: 90, wageBudget: 220000, colors: ["#ce1727", "#ffffff"] },
  { id: "mci", name: "Manchester City", shortName: "MCI", country: "Inglaterra", countryCode: "ENG", league: "Premier League", reputation: 97, wageBudget: 480000, colors: ["#6cabdd", "#1c2c5b"] },
  { id: "liv", name: "Liverpool", shortName: "LIV", country: "Inglaterra", countryCode: "ENG", league: "Premier League", reputation: 94, wageBudget: 360000, colors: ["#c8102e", "#00b2a9"] },
  { id: "ars", name: "Arsenal", shortName: "ARS", country: "Inglaterra", countryCode: "ENG", league: "Premier League", reputation: 92, wageBudget: 320000, colors: ["#ef0107", "#ffffff"] },
  { id: "che", name: "Chelsea", shortName: "CHE", country: "Inglaterra", countryCode: "ENG", league: "Premier League", reputation: 88, wageBudget: 300000, colors: ["#034694", "#ffffff"] },
  { id: "mun", name: "Manchester United", shortName: "MUN", country: "Inglaterra", countryCode: "ENG", league: "Premier League", reputation: 87, wageBudget: 310000, colors: ["#da291c", "#fbe122"] },
  { id: "tot", name: "Tottenham", shortName: "TOT", country: "Inglaterra", countryCode: "ENG", league: "Premier League", reputation: 86, wageBudget: 240000, colors: ["#132257", "#ffffff"] },
  { id: "bay", name: "Bayern Munique", shortName: "BAY", country: "Alemanha", countryCode: "GER", league: "Bundesliga", reputation: 94, wageBudget: 340000, colors: ["#dc052d", "#0066b2"] },
  { id: "bvb", name: "Borussia Dortmund", shortName: "BVB", country: "Alemanha", countryCode: "GER", league: "Bundesliga", reputation: 88, wageBudget: 180000, colors: ["#fde100", "#000000"] },
  { id: "lev", name: "Bayer Leverkusen", shortName: "LEV", country: "Alemanha", countryCode: "GER", league: "Bundesliga", reputation: 86, wageBudget: 140000, colors: ["#e32219", "#000000"] },
  { id: "psg", name: "Paris Saint-Germain", shortName: "PSG", country: "Franca", countryCode: "FRA", league: "Ligue 1", reputation: 93, wageBudget: 420000, colors: ["#004170", "#da291c"] },
  { id: "intm", name: "Inter de Milao", shortName: "INT", country: "Italia", countryCode: "ITA", league: "Serie A", reputation: 91, wageBudget: 220000, colors: ["#010E80", "#000000"] },
  { id: "mil", name: "Milan", shortName: "MIL", country: "Italia", countryCode: "ITA", league: "Serie A", reputation: 89, wageBudget: 200000, colors: ["#fb090b", "#000000"] },
  { id: "juv", name: "Juventus", shortName: "JUV", country: "Italia", countryCode: "ITA", league: "Serie A", reputation: 88, wageBudget: 210000, colors: ["#000000", "#ffffff"] },
  { id: "nap", name: "Napoli", shortName: "NAP", country: "Italia", countryCode: "ITA", league: "Serie A", reputation: 87, wageBudget: 160000, colors: ["#12A0D7", "#ffffff"] },
  { id: "ben", name: "Benfica", shortName: "BEN", country: "Portugal", countryCode: "POR", league: "Liga Portugal", reputation: 84, wageBudget: 90000, colors: ["#e41e26", "#ffffff"] },
  { id: "por", name: "Porto", shortName: "POR", country: "Portugal", countryCode: "POR", league: "Liga Portugal", reputation: 83, wageBudget: 80000, colors: ["#003087", "#ffffff"] },
  { id: "scp", name: "Sporting", shortName: "SCP", country: "Portugal", countryCode: "POR", league: "Liga Portugal", reputation: 82, wageBudget: 75000, colors: ["#008057", "#ffffff"] },
  { id: "aja", name: "Ajax", shortName: "AJA", country: "Holanda", countryCode: "NED", league: "Eredivisie", reputation: 82, wageBudget: 70000, colors: ["#d2122e", "#ffffff"] },
];

export const FILLER_OPPONENTS: Record<string, { name: string; rep: number }[]> = {
  Brasileirao: [
    { name: "Cuiaba", rep: 64 },
    { name: "Goias", rep: 66 },
    { name: "Coritiba", rep: 65 },
    { name: "Ceara", rep: 67 },
    { name: "Sport", rep: 68 },
    { name: "Vitoria", rep: 66 },
    { name: "Juventude", rep: 64 },
    { name: "Atletico-GO", rep: 65 },
  ],
  "Liga Profesional": [
    { name: "Racing", rep: 74 },
    { name: "Independiente", rep: 73 },
    { name: "San Lorenzo", rep: 72 },
    { name: "Estudiantes", rep: 74 },
    { name: "Velez", rep: 73 },
  ],
  "La Liga": [
    { name: "Sevilla", rep: 80 },
    { name: "Real Sociedad", rep: 82 },
    { name: "Villarreal", rep: 81 },
    { name: "Athletic Bilbao", rep: 83 },
    { name: "Getafe", rep: 74 },
    { name: "Valencia", rep: 78 },
    { name: "Betis", rep: 80 },
  ],
  "Premier League": [
    { name: "Newcastle", rep: 84 },
    { name: "Aston Villa", rep: 84 },
    { name: "Brighton", rep: 80 },
    { name: "West Ham", rep: 79 },
    { name: "Fulham", rep: 78 },
    { name: "Crystal Palace", rep: 77 },
    { name: "Wolves", rep: 76 },
    { name: "Everton", rep: 76 },
    { name: "Brentford", rep: 78 },
  ],
  Bundesliga: [
    { name: "RB Leipzig", rep: 85 },
    { name: "Stuttgart", rep: 80 },
    { name: "Frankfurt", rep: 81 },
    { name: "Wolfsburg", rep: 78 },
    { name: "Gladbach", rep: 77 },
    { name: "Freiburg", rep: 79 },
  ],
  "Ligue 1": [
    { name: "Monaco", rep: 84 },
    { name: "Marseille", rep: 82 },
    { name: "Lyon", rep: 80 },
    { name: "Lille", rep: 81 },
    { name: "Nice", rep: 79 },
    { name: "Lens", rep: 78 },
  ],
  "Serie A": [
    { name: "Roma", rep: 84 },
    { name: "Lazio", rep: 82 },
    { name: "Atalanta", rep: 85 },
    { name: "Fiorentina", rep: 80 },
    { name: "Torino", rep: 76 },
    { name: "Bologna", rep: 79 },
  ],
  "Liga Portugal": [
    { name: "Braga", rep: 78 },
    { name: "Vitoria Guimaraes", rep: 74 },
    { name: "Boavista", rep: 70 },
    { name: "Gil Vicente", rep: 68 },
  ],
  Eredivisie: [
    { name: "PSV", rep: 84 },
    { name: "Feyenoord", rep: 83 },
    { name: "AZ Alkmaar", rep: 76 },
    { name: "Twente", rep: 74 },
  ],
};

export const INJURY_TABLE: { name: string; severity: "leve" | "media" | "grave" | "cronica"; weeks: [number, number] }[] = [
  { name: "Contusao", severity: "leve", weeks: [1, 2] },
  { name: "Estiramento", severity: "leve", weeks: [2, 3] },
  { name: "Entorse de tornozelo", severity: "media", weeks: [4, 6] },
  { name: "Lesao muscular", severity: "media", weeks: [5, 8] },
  { name: "Rompimento de ligamento", severity: "grave", weeks: [12, 24] },
  { name: "Fratura", severity: "grave", weeks: [10, 18] },
  { name: "Joelho cronico", severity: "cronica", weeks: [8, 14] },
];

export const SPONSOR_BRANDS = ["Nike", "Adidas", "Puma", "New Balance", "Umbro", "Gatorade", "EA Sports"];

export function clubById(id: string): Club {
  const club = CLUBS.find((c) => c.id === id);
  if (!club) throw new Error(`Clube inexistente: ${id}`);
  return club;
}

export function nationById(id: string): Nation {
  const n = NATIONS.find((x) => x.id === id);
  if (!n) throw new Error(`Nacao inexistente: ${id}`);
  return n;
}

export function positionName(id: Position): string {
  return POSITIONS.find((p) => p.id === id)?.name ?? id;
}

export function defaultShirt(position: Position): number {
  const map: Record<Position, number> = {
    GK: 1,
    CB: 4,
    LB: 6,
    RB: 2,
    CDM: 5,
    CM: 8,
    CAM: 10,
    LM: 11,
    RM: 7,
    LW: 11,
    RW: 7,
    ST: 9,
  };
  return map[position];
}

export function starterClubsFor(nationId: string): Club[] {
  const nation = nationById(nationId);
  const home = CLUBS.filter((c) => c.countryCode === nation.code);
  const pool = home.length >= 3 ? home : CLUBS.filter((c) => c.reputation <= 85);
  return [...pool].sort((a, b) => b.reputation - a.reputation);
}

export const NATION_ISO: Record<string, string> = {
  bra: "br",
  arg: "ar",
  por: "pt",
  uru: "uy",
  fra: "fr",
  esp: "es",
  eng: "gb",
  ger: "de",
  ita: "it",
  ned: "nl",
  bel: "be",
  cro: "hr",
  nga: "ng",
  sen: "sn",
  civ: "ci",
  mar: "ma",
  jpn: "jp",
  kor: "kr",
  col: "co",
  chi: "cl",
  par: "py",
  ecu: "ec",
  gha: "gh",
  cmr: "cm",
  usa: "us",
  mex: "mx",
};

export function flagUrl(nationId: string): string {
  const iso = NATION_ISO[nationId] ?? "un";
  return `https://flagcdn.com/w80/${iso}.png`;
}

/** Transfermarkt crest IDs — real club badges. Fallback is a color shield. */
export const CLUB_LOGOS: Record<string, string> = {
  fla: "https://tmssl.akamaized.net/images/wappen/head/614.png",
  pal: "https://tmssl.akamaized.net/images/wappen/head/1023.png",
  sao: "https://tmssl.akamaized.net/images/wappen/head/585.png",
  cor: "https://tmssl.akamaized.net/images/wappen/head/199.png",
  san: "https://tmssl.akamaized.net/images/wappen/head/221.png",
  gre: "https://tmssl.akamaized.net/images/wappen/head/210.png",
  int: "https://tmssl.akamaized.net/images/wappen/head/6600.png",
  cam: "https://tmssl.akamaized.net/images/wappen/head/330.png",
  flu: "https://tmssl.akamaized.net/images/wappen/head/2462.png",
  bot: "https://tmssl.akamaized.net/images/wappen/head/537.png",
  vas: "https://tmssl.akamaized.net/images/wappen/head/475.png",
  bah: "https://tmssl.akamaized.net/images/wappen/head/10010.png",
  cru: "https://tmssl.akamaized.net/images/wappen/head/609.png",
  cap: "https://tmssl.akamaized.net/images/wappen/head/679.png",
  for: "https://tmssl.akamaized.net/images/wappen/head/10870.png",
  rbb: "https://tmssl.akamaized.net/images/wappen/head/8793.png",
  riv: "https://tmssl.akamaized.net/images/wappen/head/209.png",
  boc: "https://tmssl.akamaized.net/images/wappen/head/189.png",
  rma: "https://tmssl.akamaized.net/images/wappen/head/418.png",
  bar: "https://tmssl.akamaized.net/images/wappen/head/131.png",
  atm: "https://tmssl.akamaized.net/images/wappen/head/13.png",
  mci: "https://tmssl.akamaized.net/images/wappen/head/281.png",
  liv: "https://tmssl.akamaized.net/images/wappen/head/31.png",
  ars: "https://tmssl.akamaized.net/images/wappen/head/11.png",
  che: "https://tmssl.akamaized.net/images/wappen/head/631.png",
  mun: "https://tmssl.akamaized.net/images/wappen/head/985.png",
  tot: "https://tmssl.akamaized.net/images/wappen/head/148.png",
  bay: "https://tmssl.akamaized.net/images/wappen/head/27.png",
  bvb: "https://tmssl.akamaized.net/images/wappen/head/16.png",
  lev: "https://tmssl.akamaized.net/images/wappen/head/15.png",
  psg: "https://tmssl.akamaized.net/images/wappen/head/583.png",
  intm: "https://tmssl.akamaized.net/images/wappen/head/46.png",
  mil: "https://tmssl.akamaized.net/images/wappen/head/5.png",
  juv: "https://tmssl.akamaized.net/images/wappen/head/506.png",
  nap: "https://tmssl.akamaized.net/images/wappen/head/6195.png",
  ben: "https://tmssl.akamaized.net/images/wappen/head/294.png",
  por: "https://tmssl.akamaized.net/images/wappen/head/720.png",
  scp: "https://tmssl.akamaized.net/images/wappen/head/336.png",
  aja: "https://tmssl.akamaized.net/images/wappen/head/610.png",
};

export function clubLogo(id: string): string | undefined {
  return CLUB_LOGOS[id];
}

const GATEWAY_ACADEMY = ["aja", "scp", "por", "ben", "rbb", "vas", "san", "flu"];

export function academyPool(nationId: string): Club[] {
  const nation = nationById(nationId);
  const home = CLUBS.filter((c) => c.countryCode === nation.code);
  if (home.length >= 2) {
    const modest = home.filter((c) => c.reputation <= 80);
    return modest.length >= 2 ? modest : home;
  }
  return GATEWAY_ACADEMY.map((id) => clubById(id));
}

export const LEGENDS: Legend[] = [
  { id: "ronaldo", name: "Ronaldo Fenomeno", positions: ["ST"], signature: { pace: 94, shooting: 96, dribbling: 90 }, blurb: "Explosao e finalizacao", nation: "BRA", era: "90-00", number: 9, colors: ["#ffdf00", "#009c3b"], iconic: true },
  { id: "pele", name: "Pele", positions: ["ST", "CAM"], signature: { shooting: 93, passing: 88, dribbling: 90, vision: 92 }, blurb: "Jogo completo", nation: "BRA", era: "58-77", number: 10, colors: ["#ffdf00", "#002776"], iconic: true },
  { id: "romario", name: "Romario", positions: ["ST"], signature: { shooting: 95, dribbling: 88, pace: 86 }, blurb: "Raposa da area", nation: "BRA", era: "85-00", number: 11, colors: ["#ffdf00", "#009c3b"], iconic: true },
  { id: "messi", name: "Lionel Messi", positions: ["RW", "CAM", "ST"], signature: { dribbling: 97, passing: 93, vision: 96, shooting: 92 }, blurb: "Toque e visao", nation: "ARG", era: "04-22", number: 10, colors: ["#75aadb", "#ffffff"], iconic: true },
  { id: "cr7", name: "Cristiano Ronaldo", positions: ["ST", "LW"], signature: { shooting: 95, pace: 90, physical: 88 }, blurb: "Salto e chute", nation: "POR", era: "03-22", number: 7, colors: ["#006600", "#d0103a"], iconic: true },
  { id: "ronaldinho", name: "Ronaldinho", positions: ["CAM", "LW", "LM"], signature: { dribbling: 96, passing: 90, vision: 91 }, blurb: "Magia no um contra um", nation: "BRA", era: "99-11", number: 10, colors: ["#a50044", "#004d98"], iconic: true },
  { id: "neymar", name: "Neymar", positions: ["LW", "CAM"], signature: { dribbling: 95, pace: 90, passing: 86 }, blurb: "Gingado e ruptura", nation: "BRA", era: "09-22", number: 10, colors: ["#ffdf00", "#009c3b"], iconic: true },
  { id: "mbappe", name: "Kylian Mbappe", positions: ["ST", "LW", "RW"], signature: { pace: 97, shooting: 89, dribbling: 88 }, blurb: "Velocidade pura", nation: "FRA", era: "16-", number: 7, colors: ["#002395", "#ed2939"], iconic: false },
  { id: "zidane", name: "Zinedine Zidane", positions: ["CAM", "CM"], signature: { passing: 94, vision: 95, dribbling: 88 }, blurb: "Primeiro toque", nation: "FRA", era: "92-06", number: 5, colors: ["#002395", "#ed2939"], iconic: true },
  { id: "xavi", name: "Xavi", positions: ["CM", "CAM"], signature: { passing: 96, vision: 97 }, blurb: "Ritmo de posse", nation: "ESP", era: "98-15", number: 6, colors: ["#a50044", "#004d98"], iconic: true },
  { id: "iniesta", name: "Andres Iniesta", positions: ["CM", "CAM", "LM"], signature: { passing: 93, dribbling: 91, vision: 94 }, blurb: "Entre linhas", nation: "ESP", era: "02-18", number: 8, colors: ["#a50044", "#004d98"], iconic: true },
  { id: "kaka", name: "Kaka", positions: ["CAM"], signature: { pace: 88, passing: 90, shooting: 86, dribbling: 88 }, blurb: "Arrancada de 10", nation: "BRA", era: "01-14", number: 8, colors: ["#fb090b", "#000000"], iconic: false },
  { id: "vieira", name: "Patrick Vieira", positions: ["CDM", "CM"], signature: { physical: 93, defending: 90, passing: 82 }, blurb: "Presenca e pulmao", nation: "FRA", era: "95-10", number: 4, colors: ["#ef0107", "#ffffff"], iconic: false },
  { id: "makelele", name: "Claude Makelele", positions: ["CDM"], signature: { defending: 92, physical: 86, passing: 80 }, blurb: "Cobre o buraco", nation: "FRA", era: "92-08", number: 4, colors: ["#034694", "#ffffff"], iconic: false },
  { id: "maldini", name: "Paolo Maldini", positions: ["CB", "LB"], signature: { defending: 96, vision: 88, pace: 78 }, blurb: "Leitura e classe", nation: "ITA", era: "85-09", number: 3, colors: ["#fb090b", "#000000"], iconic: true },
  { id: "cannavaro", name: "Fabio Cannavaro", positions: ["CB"], signature: { defending: 94, physical: 84 }, blurb: "Antecipacao", nation: "ITA", era: "92-10", number: 5, colors: ["#0066cc", "#ffffff"], iconic: false },
  { id: "cafu", name: "Cafu", positions: ["RB"], signature: { pace: 90, passing: 84, physical: 86 }, blurb: "Sobe a faixa", nation: "BRA", era: "90-06", number: 2, colors: ["#ffdf00", "#009c3b"], iconic: true },
  { id: "carlos", name: "Roberto Carlos", positions: ["LB"], signature: { pace: 91, shooting: 86, physical: 84 }, blurb: "Bomba e sobreposicao", nation: "BRA", era: "93-07", number: 6, colors: ["#ffffff", "#fbbc04"], iconic: true },
  { id: "alves", name: "Dani Alves", positions: ["RB"], signature: { pace: 88, passing: 86, dribbling: 84 }, blurb: "Lateral ofensivo", nation: "BRA", era: "03-19", number: 2, colors: ["#a50044", "#004d98"], iconic: false },
  { id: "yashin", name: "Lev Yashin", positions: ["GK"], signature: { defending: 95, vision: 90, physical: 86 }, blurb: "Aranha negra", nation: "URS", era: "50-70", number: 1, colors: ["#111111", "#e4c15a"], iconic: true },
  { id: "buffon", name: "Gianluigi Buffon", positions: ["GK"], signature: { defending: 94, vision: 88, physical: 84 }, blurb: "Posicao e pulso", nation: "ITA", era: "95-18", number: 1, colors: ["#000000", "#ffffff"], iconic: true },
  { id: "henry", name: "Thierry Henry", positions: ["ST", "LW"], signature: { pace: 94, shooting: 91, dribbling: 88 }, blurb: "Diagonais letais", nation: "FRA", era: "97-10", number: 14, colors: ["#ef0107", "#ffffff"], iconic: true },
  { id: "maradona", name: "Diego Maradona", positions: ["CAM", "ST"], signature: { dribbling: 97, passing: 90, vision: 94, shooting: 88 }, blurb: "Genio com a bola", nation: "ARG", era: "76-94", number: 10, colors: ["#75aadb", "#ffffff"], iconic: true },
  { id: "zico", name: "Zico", positions: ["CAM", "ST"], signature: { passing: 93, shooting: 90, vision: 92 }, blurb: "Camisa 10 classico", nation: "BRA", era: "71-89", number: 10, colors: ["#c41e3a", "#1a1a1a"], iconic: true },
  { id: "garrincha", name: "Garrincha", positions: ["RW"], signature: { dribbling: 96, pace: 88 }, blurb: "Drible torto", nation: "BRA", era: "53-66", number: 7, colors: ["#ffdf00", "#009c3b"], iconic: true },
  { id: "beckenbauer", name: "Franz Beckenbauer", positions: ["CB", "CDM"], signature: { defending: 92, passing: 90, vision: 93 }, blurb: "Libero", nation: "GER", era: "64-77", number: 5, colors: ["#ffffff", "#dd0000"], iconic: true },
  { id: "cruyff", name: "Johan Cruyff", positions: ["CAM", "ST", "LW"], signature: { dribbling: 93, passing: 91, vision: 96, pace: 88 }, blurb: "Futebol total", nation: "NED", era: "64-78", number: 14, colors: ["#f36c21", "#ffffff"], iconic: true },
  { id: "vanbasten", name: "Marco van Basten", positions: ["ST"], signature: { shooting: 95, dribbling: 88, physical: 84 }, blurb: "Voleio e classe", nation: "NED", era: "82-93", number: 9, colors: ["#f36c21", "#ffffff"], iconic: true },
  { id: "eusebio", name: "Eusebio", positions: ["ST"], signature: { pace: 92, shooting: 94, dribbling: 86 }, blurb: "Pantera negra", nation: "POR", era: "57-73", number: 13, colors: ["#e41e26", "#ffffff"], iconic: true },
  { id: "distefano", name: "Alfredo Di Stefano", positions: ["ST", "CAM"], signature: { shooting: 92, passing: 90, vision: 93, physical: 86 }, blurb: "O jogador completo", nation: "ARG", era: "45-66", number: 9, colors: ["#ffffff", "#fbbc04"], iconic: true },
  { id: "puskas", name: "Ferenc Puskas", positions: ["ST", "CAM"], signature: { shooting: 96, passing: 88, vision: 90 }, blurb: "Esquerda de ouro", nation: "HUN", era: "43-66", number: 10, colors: ["#ffffff", "#fbbc04"], iconic: true },
  { id: "best", name: "George Best", positions: ["RW", "LW"], signature: { dribbling: 95, pace: 90, shooting: 86 }, blurb: "Quinto Beatle", nation: "NIR", era: "63-74", number: 7, colors: ["#da291c", "#fbe122"], iconic: true },
  { id: "platini", name: "Michel Platini", positions: ["CAM", "CM"], signature: { passing: 94, shooting: 91, vision: 93 }, blurb: "Camisa 10 europeu", nation: "FRA", era: "72-87", number: 10, colors: ["#002395", "#ed2939"], iconic: true },
  { id: "modric", name: "Luka Modric", positions: ["CM", "CAM"], signature: { passing: 93, vision: 94, dribbling: 88 }, blurb: "Motor e visao", nation: "CRO", era: "06-22", number: 10, colors: ["#ffffff", "#c8102e"], iconic: false },
  { id: "kroos", name: "Toni Kroos", positions: ["CM", "CDM"], signature: { passing: 95, vision: 93 }, blurb: "Passe laser", nation: "GER", era: "07-24", number: 8, colors: ["#ffffff", "#fbbc04"], iconic: false },
  { id: "pirlo", name: "Andrea Pirlo", positions: ["CM", "CDM", "CAM"], signature: { passing: 96, vision: 95 }, blurb: "Regista", nation: "ITA", era: "98-15", number: 21, colors: ["#000000", "#ffffff"], iconic: false },
  { id: "gerrard", name: "Steven Gerrard", positions: ["CM", "CAM"], signature: { passing: 90, shooting: 88, physical: 86, vision: 88 }, blurb: "Box-to-box de final", nation: "ENG", era: "98-15", number: 8, colors: ["#c8102e", "#00b2a9"], iconic: false },
  { id: "lampard", name: "Frank Lampard", positions: ["CM", "CAM"], signature: { shooting: 90, passing: 86, vision: 86 }, blurb: "Chegada na area", nation: "ENG", era: "95-15", number: 8, colors: ["#034694", "#ffffff"], iconic: false },
  { id: "scholes", name: "Paul Scholes", positions: ["CM"], signature: { passing: 93, shooting: 88, vision: 92 }, blurb: "Passe e chute de longe", nation: "ENG", era: "94-13", number: 18, colors: ["#da291c", "#fbe122"], iconic: false },
  { id: "socrates", name: "Socrates", positions: ["CAM", "CM"], signature: { passing: 92, vision: 94, shooting: 84 }, blurb: "Doutor e 10", nation: "BRA", era: "74-89", number: 8, colors: ["#c41e3a", "#1a1a1a"], iconic: false },
  { id: "rivaldo", name: "Rivaldo", positions: ["CAM", "LW", "ST"], signature: { shooting: 91, dribbling: 90, passing: 86 }, blurb: "Perna esquerda", nation: "BRA", era: "91-03", number: 10, colors: ["#a50044", "#004d98"], iconic: false },
  { id: "baggio", name: "Roberto Baggio", positions: ["CAM", "ST"], signature: { dribbling: 93, shooting: 90, vision: 90 }, blurb: "Divino", nation: "ITA", era: "86-04", number: 10, colors: ["#000000", "#ffffff"], iconic: false },
  { id: "totti", name: "Francesco Totti", positions: ["CAM", "ST"], signature: { passing: 91, shooting: 88, vision: 92 }, blurb: "Rei de Roma", nation: "ITA", era: "93-17", number: 10, colors: ["#8e1f2f", "#f0bc42"], iconic: false },
  { id: "figo", name: "Luis Figo", positions: ["RW", "RM"], signature: { dribbling: 90, passing: 88, pace: 86 }, blurb: "Extremo classico", nation: "POR", era: "91-09", number: 7, colors: ["#ffffff", "#fbbc04"], iconic: false },
  { id: "jairzinho", name: "Jairzinho", positions: ["RW"], signature: { pace: 92, dribbling: 90, shooting: 86 }, blurb: "Furacao da copa", nation: "BRA", era: "64-74", number: 7, colors: ["#ffdf00", "#009c3b"], iconic: false },
  { id: "rivelino", name: "Rivelino", positions: ["LW", "CAM"], signature: { shooting: 90, passing: 88, dribbling: 88 }, blurb: "Elástico e bomba", nation: "BRA", era: "65-78", number: 11, colors: ["#ffdf00", "#009c3b"], iconic: false },
  { id: "salah", name: "Mohamed Salah", positions: ["RW"], signature: { pace: 93, shooting: 90, dribbling: 88 }, blurb: "Corte pra dentro", nation: "EGY", era: "14-", number: 11, colors: ["#c8102e", "#00b2a9"], iconic: false },
  { id: "hazard", name: "Eden Hazard", positions: ["LW", "CAM"], signature: { dribbling: 94, pace: 88, passing: 86 }, blurb: "Baixo centro", nation: "BEL", era: "07-19", number: 10, colors: ["#034694", "#ffffff"], iconic: false },
  { id: "suarez", name: "Luis Suarez", positions: ["ST"], signature: { shooting: 92, dribbling: 86, physical: 84 }, blurb: "Fome de gol", nation: "URU", era: "05-22", number: 9, colors: ["#a50044", "#004d98"], iconic: false },
  { id: "lewa", name: "Robert Lewandowski", positions: ["ST"], signature: { shooting: 94, physical: 86, vision: 84 }, blurb: "Maquina de gol", nation: "POL", era: "08-", number: 9, colors: ["#dc052d", "#0066b2"], iconic: false },
  { id: "batistuta", name: "Gabriel Batistuta", positions: ["ST"], signature: { shooting: 94, physical: 88, pace: 82 }, blurb: "Batigol", nation: "ARG", era: "88-03", number: 9, colors: ["#4203c9", "#d4001f"], iconic: false },
  { id: "raul", name: "Raul", positions: ["ST", "CAM"], signature: { shooting: 90, vision: 88, passing: 84 }, blurb: "Capitao branco", nation: "ESP", era: "94-10", number: 7, colors: ["#ffffff", "#fbbc04"], iconic: false },
  { id: "sheva", name: "Andriy Shevchenko", positions: ["ST"], signature: { shooting: 92, pace: 86, physical: 82 }, blurb: "Movimentacao", nation: "UKR", era: "94-09", number: 7, colors: ["#fb090b", "#000000"], iconic: false },
  { id: "ramos", name: "Sergio Ramos", positions: ["CB"], signature: { defending: 90, physical: 90, shooting: 78 }, blurb: "Lider e pulmao", nation: "ESP", era: "04-21", number: 4, colors: ["#ffffff", "#fbbc04"], iconic: false },
  { id: "puyol", name: "Carles Puyol", positions: ["CB"], signature: { defending: 92, physical: 90 }, blurb: "Capitao de ferro", nation: "ESP", era: "99-14", number: 5, colors: ["#a50044", "#004d98"], iconic: false },
  { id: "nesta", name: "Alessandro Nesta", positions: ["CB"], signature: { defending: 95, pace: 80, vision: 86 }, blurb: "Antecipa tudo", nation: "ITA", era: "93-13", number: 13, colors: ["#fb090b", "#000000"], iconic: false },
  { id: "baresi", name: "Franco Baresi", positions: ["CB"], signature: { defending: 96, vision: 90, passing: 84 }, blurb: "Cerebro da zaga", nation: "ITA", era: "77-97", number: 6, colors: ["#fb090b", "#000000"], iconic: true },
  { id: "thiago", name: "Thiago Silva", positions: ["CB"], signature: { defending: 90, vision: 86, passing: 82 }, blurb: "Leitura moderna", nation: "BRA", era: "06-22", number: 2, colors: ["#004170", "#da291c"], iconic: false },
  { id: "lucio", name: "Lucio", positions: ["CB"], signature: { defending: 88, physical: 92, pace: 84 }, blurb: "Sobe com a bola", nation: "BRA", era: "98-13", number: 3, colors: ["#dc052d", "#0066b2"], iconic: false },
  { id: "lahm", name: "Philipp Lahm", positions: ["RB", "LB", "CDM"], signature: { defending: 88, passing: 90, vision: 90, pace: 82 }, blurb: "O relogio", nation: "GER", era: "02-17", number: 21, colors: ["#dc052d", "#0066b2"], iconic: false },
  { id: "marcelo", name: "Marcelo", positions: ["LB"], signature: { dribbling: 90, passing: 86, pace: 86 }, blurb: "Lateral-meia", nation: "BRA", era: "05-22", number: 12, colors: ["#ffffff", "#fbbc04"], iconic: false },
  { id: "zanetti", name: "Javier Zanetti", positions: ["RB", "RM"], signature: { physical: 90, defending: 86, pace: 84 }, blurb: "Pulmao eterno", nation: "ARG", era: "92-14", number: 4, colors: ["#010E80", "#000000"], iconic: false },
  { id: "thuram", name: "Lilian Thuram", positions: ["RB", "CB"], signature: { defending: 90, physical: 90, pace: 86 }, blurb: "Forca e leitura", nation: "FRA", era: "91-08", number: 15, colors: ["#010E80", "#000000"], iconic: false },
  { id: "cole", name: "Ashley Cole", positions: ["LB"], signature: { pace: 88, defending: 88, physical: 82 }, blurb: "Lateral de copa", nation: "ENG", era: "99-14", number: 3, colors: ["#034694", "#ffffff"], iconic: false },
  { id: "casemiro", name: "Casemiro", positions: ["CDM"], signature: { defending: 88, physical: 90, passing: 80 }, blurb: "Destruidor", nation: "BRA", era: "13-", number: 14, colors: ["#ffffff", "#fbbc04"], iconic: false },
  { id: "kante", name: "N'Golo Kante", positions: ["CDM", "CM"], signature: { defending: 90, physical: 86, pace: 84 }, blurb: "Cobre o campo", nation: "FRA", era: "12-22", number: 7, colors: ["#034694", "#ffffff"], iconic: false },
  { id: "busquets", name: "Sergio Busquets", positions: ["CDM"], signature: { passing: 90, vision: 93, defending: 84 }, blurb: "Pivô e pausa", nation: "ESP", era: "08-22", number: 5, colors: ["#a50044", "#004d98"], iconic: false },
  { id: "rijkaard", name: "Frank Rijkaard", positions: ["CDM", "CB"], signature: { defending: 90, passing: 86, physical: 88 }, blurb: "Volante total", nation: "NED", era: "80-95", number: 4, colors: ["#fb090b", "#000000"], iconic: false },
  { id: "matthaus", name: "Lothar Matthaus", positions: ["CM", "CDM", "CB"], signature: { passing: 88, physical: 88, shooting: 84, vision: 88 }, blurb: "Box-to-box eterno", nation: "GER", era: "79-00", number: 10, colors: ["#ffffff", "#dd0000"], iconic: false },
  { id: "gullit", name: "Ruud Gullit", positions: ["CAM", "CM", "ST"], signature: { physical: 90, passing: 86, dribbling: 86, vision: 88 }, blurb: "Atleta completo", nation: "NED", era: "79-95", number: 10, colors: ["#fb090b", "#000000"], iconic: false },
  { id: "kahn", name: "Oliver Kahn", positions: ["GK"], signature: { defending: 94, physical: 90, vision: 84 }, blurb: "Titã no gol", nation: "GER", era: "87-08", number: 1, colors: ["#dc052d", "#0066b2"], iconic: false },
  { id: "casillas", name: "Iker Casillas", positions: ["GK"], signature: { defending: 92, vision: 88, pace: 78 }, blurb: "Reflexo de santo", nation: "ESP", era: "99-16", number: 1, colors: ["#ffffff", "#fbbc04"], iconic: false },
  { id: "neuer", name: "Manuel Neuer", positions: ["GK"], signature: { defending: 92, vision: 94, passing: 86 }, blurb: "Sweeper-keeper", nation: "GER", era: "06-", number: 1, colors: ["#dc052d", "#0066b2"], iconic: false },
  { id: "schmeichel", name: "Peter Schmeichel", positions: ["GK"], signature: { defending: 93, physical: 92, vision: 84 }, blurb: "Muralha", nation: "DEN", era: "87-99", number: 1, colors: ["#da291c", "#fbe122"], iconic: false },
  { id: "taffarel", name: "Claudio Taffarel", positions: ["GK"], signature: { defending: 90, vision: 84, physical: 82 }, blurb: "Penalti e copa", nation: "BRA", era: "85-98", number: 1, colors: ["#ffdf00", "#009c3b"], iconic: false },
  { id: "dida", name: "Dida", positions: ["GK"], signature: { defending: 88, physical: 86, vision: 80 }, blurb: "Champions e palme", nation: "BRA", era: "92-10", number: 1, colors: ["#fb090b", "#000000"], iconic: false },
  { id: "cech", name: "Petr Cech", positions: ["GK"], signature: { defending: 91, vision: 86, physical: 86 }, blurb: "Boné e palme", nation: "CZE", era: "01-15", number: 1, colors: ["#034694", "#ffffff"], iconic: false },
  { id: "nilton", name: "Nilton Santos", positions: ["LB"], signature: { defending: 90, passing: 84, pace: 82 }, blurb: "A Enciclopedia", nation: "BRA", era: "48-64", number: 6, colors: ["#000000", "#ffffff"], iconic: false },
  { id: "carlosalberto", name: "Carlos Alberto", positions: ["RB"], signature: { pace: 86, passing: 86, shooting: 80, defending: 84 }, blurb: "Gol da final", nation: "BRA", era: "63-77", number: 4, colors: ["#ffdf00", "#009c3b"], iconic: false },
];

// Craques contemporaneos: entram no sorteio do DNA junto das lendas.
const CURRENT_CRAQUES: Legend[] = [
  { id: "vini", name: "Vinicius Junior", positions: ["LW", "ST"], signature: { dribbling: 94, pace: 96, shooting: 88 }, blurb: "Arrancada e 1x1", nation: "BRA", era: "19-", number: 7, colors: ["#ffffff", "#fbbc04"], iconic: false },
  { id: "haaland", name: "Erling Haaland", positions: ["ST"], signature: { shooting: 97, physical: 94, pace: 90 }, blurb: "Forca e finalizacao", nation: "NOR", era: "20-", number: 9, colors: ["#6cabdd", "#1c2c5b"], iconic: false },
  { id: "bellingham", name: "Jude Bellingham", positions: ["CM", "CAM"], signature: { physical: 88, dribbling: 89, vision: 91 }, blurb: "Chegada e leitura", nation: "ENG", era: "19-", number: 5, colors: ["#ffffff", "#fbbc04"], iconic: false },
  { id: "rodri", name: "Rodri", positions: ["CDM", "CM"], signature: { passing: 94, vision: 95, defending: 88 }, blurb: "Controle e pausa", nation: "ESP", era: "15-", number: 16, colors: ["#6cabdd", "#1c2c5b"], iconic: false },
  { id: "debruyne", name: "Kevin De Bruyne", positions: ["CM", "CAM"], signature: { passing: 96, vision: 97, shooting: 88 }, blurb: "Passe impossível", nation: "BEL", era: "08-", number: 17, colors: ["#ed2939", "#000000"], iconic: false },
  { id: "van-dijk", name: "Virgil van Dijk", positions: ["CB"], signature: { defending: 95, physical: 94, vision: 86 }, blurb: "Forca e leitura", nation: "NED", era: "11-", number: 4, colors: ["#f36c21", "#ffffff"], iconic: false },
  { id: "alisson", name: "Alisson", positions: ["GK"], signature: { defending: 94, vision: 90, physical: 88 }, blurb: "Reflexo e saida", nation: "BRA", era: "13-", number: 1, colors: ["#c8102e", "#00b2a9"], iconic: false },
  { id: "saka", name: "Bukayo Saka", positions: ["RW", "RM"], signature: { dribbling: 91, pace: 90, passing: 86 }, blurb: "Corte e velocidade", nation: "ENG", era: "18-", number: 7, colors: ["#ef0107", "#ffffff"], iconic: false },
  { id: "osimhen", name: "Victor Osimhen", positions: ["ST"], signature: { pace: 94, shooting: 91, physical: 90 }, blurb: "Profundidade e forca", nation: "NGA", era: "17-", number: 9, colors: ["#008751", "#ffffff"], iconic: false },
];

LEGENDS.push(...CURRENT_CRAQUES);

export function legendsFor(position: Position): Legend[] {
  const list = LEGENDS.filter((l) => l.positions.includes(position));
  return list.length ? list : LEGENDS;
}

export function idolsFor(position: Position): Legend[] {
  const primary = LEGENDS.filter((l) => l.positions.includes(position));
  const extra = LEGENDS.filter((l) => !l.positions.includes(position) && l.iconic);
  return [...primary, ...extra];
}

export function legendById(id: string): Legend | undefined {
  return LEGENDS.find((l) => l.id === id);
}

export function legendArt(legend: Legend): string {
  if (legend.positions.includes("GK")) return "/legend-1.jpg";
  if (legend.positions.includes("ST") && !legend.positions.includes("CAM")) return "/legend-9.jpg";
  if (legend.positions.includes("RW") || legend.positions.includes("LW") || legend.number === 7) return "/legend-7.jpg";
  return "/legend-10.jpg";
}

export const FEATURED_LANDING = ["pele", "ronaldo", "maradona", "messi", "cr7", "maldini", "yashin", "garrincha"] as const;


