import {
  ATTR_KEYS,
  CLUBS,
  FILLER_OPPONENTS,
  INJURY_TABLE,
  PLAY_STYLES,
  POSITION_WEIGHTS,
  SPONSOR_BRANDS,
  academyPool,
  clubById,
  legendsFor,
  LEGENDS,
} from "./data";
import type {
  Appearance,
  AttrKey,
  Attributes,
  CardStyle,
  CoachLine,
  CoachRank,
  CoachState,
  CreatePayload,
  FastRecap,
  FastSeasonLine,
  GameState,
  HistoryRank,
  Injury,
  MatchChoiceId,
  MatchEvent,
  MatchPreview,
  MatchResult,
  Player,
  Position,
  SeasonRecap,
  SeasonStats,
  SkillSteal,
  Sponsorship,
  Title,
  TransferOffer,
  TrainFocus,
  Club,
} from "./types";
import { SAVE_VERSION } from "./types";

export function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

export function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function rngFrom(state: GameState): () => number {
  const rng = mulberry32(state.seed + state.rngCount * 9973);
  state.rngCount += 1;
  return rng;
}

export function pick<T>(rng: () => number, list: T[]): T {
  return list[Math.floor(rng() * list.length)] as T;
}

export function randInt(rng: () => number, min: number, max: number): number {
  return min + Math.floor(rng() * (max - min + 1));
}

export function calcOverall(position: Position, attrs: Attributes): number {
  const w = POSITION_WEIGHTS[position];
  let sum = 0;
  for (const key of ATTR_KEYS) sum += attrs[key] * w[key];
  return clamp(Math.round(sum), 40, 99);
}

export function cardFromOverall(overall: number): CardStyle {
  if (overall >= 88) return "fenomeno";
  if (overall >= 82) return "rare";
  if (overall >= 75) return "gold";
  if (overall >= 65) return "silver";
  return "bronze";
}

export function cardStyleFrom(overall: number, _potential?: number, forced?: CardStyle): CardStyle {
  if (forced) return forced;
  return cardFromOverall(overall);
}

export function defaultAppearance(): Appearance {
  return { skin: 2, hair: "short", facial: "none", photo: null };
}

function rollAttr(rng: () => number, weight: number): number {
  if (weight >= 0.24) return randInt(rng, 58, 72);
  if (weight >= 0.16) return randInt(rng, 50, 66);
  if (weight >= 0.1) return randInt(rng, 42, 58);
  if (weight >= 0.06) return randInt(rng, 32, 50);
  return randInt(rng, 22, 42);
}

export function rollPlayer(opts: {
  name: string;
  nationId: string;
  position: Position;
  shirtNumber: number;
  idolId?: string;
  appearance?: Appearance;
  seed?: number;
}): Player {
  const rng = mulberry32(opts.seed ?? Math.floor(Math.random() * 1e9));
  const w = POSITION_WEIGHTS[opts.position];
  const attributes = {} as Attributes;
  for (const key of ATTR_KEYS) attributes[key] = rollAttr(rng, w[key]);

  // DNA: exatamente 1 roubo. A raridade é probabilística.
  const pool = legendsFor(opts.position);
  const stealRoll = rng();
  const historical = pool.filter((l) => l.iconic);
  const famous = pool.filter((l) => !l.iconic);
  // 68% craque/famoso, 24% lenda, 8% lenda historica/iconica.
  let stealPool = famous.length ? famous : pool;
  let rare = false;
  if (stealRoll >= 0.92 && historical.length) {
    stealPool = historical;
    rare = true;
  } else if (stealRoll >= 0.68 && historical.length) {
    stealPool = historical;
    rare = false;
  }
  const legend = pick(rng, stealPool);
  const keys = Object.keys(legend.signature) as AttrKey[];
  const attr = pick(rng, keys.length ? keys : ATTR_KEYS);
  const peak = legend.signature[attr] ?? 85;
  // O roubo melhora a base, mas não entrega uma carta pronta.
  const mul = rare ? 0.76 + rng() * 0.10 : 0.62 + rng() * 0.12;
  const cap = rare ? 88 : 82;
  attributes[attr] = clamp(Math.round(peak * mul + randInt(rng, -2, 2)), 40, cap);
  steals.push({ legend: legend.name, attr, rare });

  const idol = pool.find((l) => l.id === opts.idolId) ?? LEGENDS.find((l) => l.id === opts.idolId) ?? pick(rng, pool);
  if (idol.signature) {
    for (const key of Object.keys(idol.signature) as AttrKey[]) {
      attributes[key] = clamp(attributes[key] + randInt(rng, 0, 2), 25, 80);
    }
  }

  const raw = calcOverall(opts.position, attributes);
  const target = randInt(rng, 56, 64);
  const scale = target / Math.max(raw, 1);
  for (const key of ATTR_KEYS) {
    attributes[key] = clamp(Math.round(attributes[key] * scale + randInt(rng, -1, 1)), 22, 78);
  }

  const overall = calcOverall(opts.position, attributes);
  const talent = rng();
  let potential: number;
  if (talent > 0.97) potential = randInt(rng, 92, 96);
  else if (talent > 0.85) potential = randInt(rng, 87, 92);
  else if (talent > 0.55) potential = randInt(rng, 80, 87);
  else potential = randInt(rng, 74, 82);
  potential = clamp(Math.max(potential, overall + 10), overall + 8, 97);

  return {
    name: opts.name.trim() || "Jogador",
    nationId: opts.nationId,
    position: opts.position,
    shirtNumber: opts.shirtNumber,
    age: 16,
    overall,
    potential,
    attributes,
    cardStyle: "bronze",
    playStyle: pick(rng, PLAY_STYLES[opts.position]),
    idolId: idol.id,
    idolName: idol.name,
    steals,
    appearance: opts.appearance ?? defaultAppearance(),
  };
}

export function rollAcademy(nationId: string, seed: number): Club {
  const rng = mulberry32(seed + 17);
  return pick(rng, academyPool(nationId));
}

export function emptySeasonStats(): SeasonStats {
  return {
    appearances: 0,
    starts: 0,
    minutes: 0,
    goals: 0,
    assists: 0,
    cleanSheets: 0,
    yellows: 0,
    reds: 0,
    avgRating: 0,
    ratingSum: 0,
    motm: 0,
    wins: 0,
    draws: 0,
    losses: 0,
  };
}

export function createCareer(payload: CreatePayload, seed = Math.floor(Math.random() * 1e9)): GameState {
  const club = clubById(payload.clubId);
  const player = {
    ...payload.player,
    shirtNumber: payload.shirtNumber,
    position: payload.position,
    name: payload.name.trim() || payload.player.name,
    nationId: payload.nationId,
    cardStyle: "bronze" as const,
  };
  player.overall = calcOverall(player.position, player.attributes);
  player.cardStyle = "bronze";

  const wage = startingWage(player.overall, club);
  const followers = 400 + Math.round(player.overall * 18);
  return {
    version: SAVE_VERSION,
    mode: payload.mode,
    seed,
    rngCount: 1,
    player,
    clubId: club.id,
    week: 1,
    season: 1,
    year: 2026,
    money: 900,
    weeklyWage: wage,
    fame: clamp(Math.round((player.overall - 52) * 1.1), 2, 14),
    morale: 72,
    form: 58,
    fitness: 86,
    aggression: player.position === "CDM" || player.position === "CB" ? 62 : 48,
    injury: null,
    chronicPenalty: 0,
    contractYearsLeft: 3,
    contractYearsTotal: 3,
    releaseClause: wage * 90,
    stats: { ...emptySeasonStats(), seasons: 0, clubs: [club.id] },
    seasonStats: emptySeasonStats(),
    titles: [],
    news: [
      {
        id: "start",
        week: 1,
        season: 1,
        text: `Saiu da base do ${club.name}. Contrato de 3 anos, ${formatMoney(wage, club.countryCode)}/sem. Cartinha bronze.`,
        tone: "neutral",
      },
    ],
    offers: [],
    sponsorships: [],
    agentMood: 70,
    matchLoad: [],
    pendingMatch: null,
    lastMatch: null,
    retired: false,
    retireReason: null,
    overallAtSeasonStart: player.overall,
    leaguePlace: estimatePlace(club.reputation, 0),
    followers,
    seasonPoints: 0,
    peakOverall: player.overall,
    highlights: [],
    pendingRaise: null,
    pendingBrand: null,
    sacked: false,
    coach: null,
    historyRank: null,
    lifeVerdict: null,
  };
}

export function startingWage(overall: number, club: Club): number {
  const youth = Math.max(250, Math.round(overall * 12 * (club.reputation / 80)));
  return clamp(youth, 250, Math.round(club.wageBudget * 0.08));
}

export function formatMoney(amount: number, countryCode = "EUR"): string {
  if (countryCode === "BRA") {
    return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 }).format(
      Math.round(amount * 6),
    );
  }
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(
    Math.round(amount),
  );
}

export function formatFortune(amount: number): string {
  if (amount >= 1_000_000) return `€ ${(amount / 1_000_000).toFixed(2)} mi`;
  if (amount >= 1_000) return `€ ${Math.round(amount / 1000)} mil`;
  return `€ ${Math.round(amount)}`;
}

export function formatFollowers(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)} mi`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)} mil`;
  return `${Math.round(n)}`;
}

function pushNews(state: GameState, text: string, tone: GameState["news"][0]["tone"]) {
  state.news.unshift({
    id: `${state.season}-${state.week}-${state.rngCount}`,
    week: state.week,
    season: state.season,
    text,
    tone,
  });
  state.news = state.news.slice(0, 24);
}

function minutesFor(state: GameState): number {
  if (state.injury) return 0;
  const club = clubById(state.clubId);
  const gap = club.reputation - state.player.overall;
  const form = state.form;
  const morale = state.morale;
  if (gap > 14) return form > 70 && morale > 60 ? randInt(rngFrom(state), 18, 42) : randInt(rngFrom(state), 8, 30);
  if (gap > 7) return randInt(rngFrom(state), 35, 72);
  if (gap > 2) return randInt(rngFrom(state), 55, 90);
  return randInt(rngFrom(state), 75, 90);
}

function roleFromGap(overall: number, clubRep: number): TransferOffer["role"] {
  const gap = clubRep - overall;
  if (gap > 12) return "promessa";
  if (gap > 5) return "rotacao";
  if (overall >= clubRep + 4) return "estrela";
  return "titular";
}

export function buildFixture(state: GameState): MatchPreview {
  const club = clubById(state.clubId);
  const peers = CLUBS.filter((c) => c.league === club.league && c.id !== club.id);
  const fillers = FILLER_OPPONENTS[club.league] ?? [];
  const rng = rngFrom(state);
  const pool: { name: string; rep: number }[] = [
    ...peers.map((c) => ({ name: c.name, rep: c.reputation })),
    ...fillers,
  ];
  const opp = pick(rng, pool);
  const week = state.week;
  const home = week % 2 === 1;
  let importance: MatchPreview["importance"] = "normal";
  let competition = club.league;
  if (week === 12 || week === 28) {
    competition = club.countryCode === "BRA" ? "Copa do Brasil" : "Copa nacional";
    importance = "big";
  }
  if (week === 36) {
    competition = club.reputation >= 82 ? (club.countryCode === "BRA" ? "Libertadores" : "Champions") : "Copa nacional";
    importance = "final";
  }
  if (Math.abs(opp.rep - club.reputation) <= 3 && rng() > 0.55) importance = "big";
  return {
    opponentName: opp.name,
    opponentRep: opp.rep,
    competition,
    home,
    importance,
    week,
  };
}

function applyChoice(choice: MatchChoiceId | null): { rating: number; injury: number; goal: number; morale: number } {
  switch (choice) {
    case "safe":
      return { rating: 0.1, injury: 0.7, goal: 0.75, morale: 0 };
    case "hero":
      return { rating: 0.55, injury: 1.25, goal: 1.35, morale: 4 };
    case "war":
      return { rating: 0.25, injury: 1.9, goal: 0.9, morale: 2 };
    case "pass":
      return { rating: 0.35, injury: 0.9, goal: 0.7, morale: 1 };
    case "shoot":
      return { rating: 0.4, injury: 1.1, goal: 1.5, morale: 2 };
    default:
      return { rating: 0, injury: 1, goal: 1, morale: 0 };
  }
}

function maybeInjury(state: GameState, riskMul: number): Injury | null {
  const rng = rngFrom(state);
  const age = state.player.age;
  const load = state.matchLoad.slice(-8).reduce((a, b) => a + b, 0);
  let chance = 0.028 * riskMul;
  if (age >= 30) chance *= 1.45;
  if (age >= 34) chance *= 1.5;
  if (state.fitness < 52) chance *= 1.7;
  if (load > 6) chance *= 1.45;
  if (state.aggression > 70) chance *= 1.25;
  if (state.player.attributes.physical > 82) chance *= 0.72;
  if (state.chronicPenalty > 0) chance *= 1.35;
  if (rng() > chance) return null;
  let table = INJURY_TABLE;
  if (age < 24) table = table.filter((t) => t.severity !== "cronica");
  const row = pick(rng, table);
  const weeks = randInt(rng, row.weeks[0], row.weeks[1]);
  return {
    id: `inj-${state.rngCount}`,
    name: row.name,
    severity: row.severity,
    weeksLeft: weeks,
    weeksTotal: weeks,
    chronic: row.severity === "cronica",
  };
}

function goalExpect(position: Position): { g: number; a: number } {
  switch (position) {
    case "ST":
      return { g: 0.48, a: 0.16 };
    case "LW":
    case "RW":
      return { g: 0.26, a: 0.24 };
    case "CAM":
      return { g: 0.2, a: 0.32 };
    case "CM":
      return { g: 0.08, a: 0.18 };
    case "LM":
    case "RM":
      return { g: 0.12, a: 0.2 };
    case "CDM":
      return { g: 0.04, a: 0.1 };
    case "LB":
    case "RB":
      return { g: 0.05, a: 0.14 };
    case "CB":
      return { g: 0.04, a: 0.04 };
    case "GK":
      return { g: 0.002, a: 0.01 };
  }
}

export function simulateMatch(state: GameState, choice: MatchChoiceId | null): MatchResult {
  const preview = state.pendingMatch ?? buildFixture(state);
  const club = clubById(state.clubId);
  const rng = rngFrom(state);
  const ch = applyChoice(choice);
  const minutes = minutesFor(state);
  const ovr = state.player.overall;
  const formMod = (state.form - 50) * 0.07;
  const moraleMod = (state.morale - 50) * 0.05;
  const fitMod = (state.fitness - 70) * 0.05;
  const playerLive = ovr + formMod + moraleMod + fitMod + ch.rating * 4;
  const team = club.reputation * 0.62 + playerLive * 0.38 + (preview.home ? 2.5 : 0);
  const gap = team - preview.opponentRep;
  // Probabilidade continua viva, mas força de elenco pesa mais.
  const winP = clamp(0.48 + gap / 55 + (preview.importance === "final" ? 0.015 : 0), 0.18, 0.82);
  const drawP = clamp(0.24 - gap / 900, 0.18, 0.27);
  const roll = rng();
  const result: MatchResult["result"] = roll < winP ? "W" : roll < winP + drawP ? "D" : "L";
  let gf = result === "W" ? randInt(rng, 1, 3) : result === "D" ? randInt(rng, 0, 2) : randInt(rng, 0, 1);
  let ga = result === "W" ? randInt(rng, 0, 1) : result === "D" ? gf : gf + (rng() < 0.78 ? randInt(rng, 1, 2) : randInt(rng, 2, 3));
  if (result === "D" && gf === 0 && rng() > 0.4) {
    gf = 1;
    ga = 1;
  }

  const expect = goalExpect(state.player.position);
  const share = clamp(minutes / 90, 0, 1) * clamp(playerLive / 78, 0.4, 1.35) * ch.goal;
  let goals = 0;
  let assists = 0;
  if (minutes >= 15) {
    if (rng() < expect.g * share) goals = 1;
    if (rng() < expect.g * share * 0.28) goals += 1;
    if (rng() < expect.a * share) assists = 1;
    if (rng() < expect.a * share * 0.22) assists += 1;
  }
  if (result === "L") goals = Math.min(goals, gf);
  if (goals + (rng() > 0.5 ? assists : 0) > gf) {
    assists = Math.max(0, gf - goals);
  }

  let rating = 6.2 + (playerLive - 70) * 0.045 + (minutes / 90) * 0.3;
  rating += goals * 0.85 + assists * 0.55;
  if (result === "W") rating += 0.25;
  if (result === "L") rating -= 0.2;
  if (minutes < 20) rating = clamp(rating, 5.7, 7.1);
  rating = clamp(round1(rating + (rng() - 0.5) * 0.6), 4.4, 10);

  const yellow = rng() < (choice === "war" ? 0.22 : 0.08);
  const red = rng() < (choice === "war" ? 0.04 : 0.012);
  const motm = rating >= 8.4 && minutes >= 60;
  const injured = minutes > 0 ? maybeInjury(state, ch.injury) : null;

  const events = buildEvents({
    rng,
    preview,
    clubName: club.shortName,
    result,
    gf,
    ga,
    goals,
    assists,
    yellow,
    red,
    injured,
    minutes,
    playerName: state.player.name.split(" ").slice(-1)[0] ?? state.player.name,
    position: state.player.position,
  });

  return {
    preview,
    playerTeam: club.name,
    opponent: preview.opponentName,
    home: preview.home,
    goalsFor: gf,
    goalsAgainst: ga,
    result,
    rating,
    minutes,
    goals,
    assists,
    yellow,
    red,
    motm,
    events,
    choice,
    injured,
    competition: preview.competition,
  };
}

function buildEvents(opts: {
  rng: () => number;
  preview: MatchPreview;
  clubName: string;
  result: "W" | "D" | "L";
  gf: number;
  ga: number;
  goals: number;
  assists: number;
  yellow: boolean;
  red: boolean;
  injured: Injury | null;
  minutes: number;
  playerName: string;
  position: Position;
}): MatchEvent[] {
  const { rng, preview, clubName, gf, ga, goals, assists, yellow, red, injured, minutes, playerName } = opts;
  const events: MatchEvent[] = [{ minute: 1, text: `Apito inicial. ${clubName} ${preview.home ? "em casa" : "fora"} contra ${preview.opponentName}.`, kind: "whistle" }];
  if (minutes < 8) {
    events.push({ minute: 12, text: `${playerName} comeca no banco. Poucos minutos hoje.`, kind: "play" });
  }

  const playerGoalMins: number[] = [];
  for (let i = 0; i < goals; i++) playerGoalMins.push(randInt(rng, 8, Math.max(10, minutes - 2)));
  playerGoalMins.sort((a, b) => a - b);
  const otherFor = Math.max(0, gf - goals);
  const forMins = [...playerGoalMins, ...Array.from({ length: otherFor }, () => randInt(rng, 6, 88))].sort((a, b) => a - b);
  const againstMins = Array.from({ length: ga }, () => randInt(rng, 7, 90)).sort((a, b) => a - b);

  for (const m of forMins) {
    const yours = playerGoalMins.includes(m);
    events.push({
      minute: m,
      text: yours ? `GOL DE ${playerName.toUpperCase()}! ${m}'` : `Gol de ${clubName}, ${m}'`,
      kind: yours ? "goal" : "play",
    });
  }
  if (assists > 0) {
    events.push({ minute: randInt(rng, 10, 80), text: `Assistencia de ${playerName}. Visao de jogo.`, kind: "assist" });
  }
  for (const m of againstMins) {
    events.push({ minute: m, text: `${preview.opponentName} empata o gol, ${m}'`, kind: "play" });
  }
  if (yellow) events.push({ minute: randInt(rng, 20, 85), text: `Cartao amarelo para ${playerName}.`, kind: "card" });
  if (red) events.push({ minute: randInt(rng, 40, 88), text: `Vermelho! ${playerName} expulso.`, kind: "card" });
  if (injured) events.push({ minute: randInt(rng, 15, 80), text: `${playerName} sente ${injured.name.toLowerCase()} e para.`, kind: "injury" });
  events.push({ minute: 90, text: `Fim de jogo. ${gf}–${ga}.`, kind: "whistle" });
  events.sort((a, b) => a.minute - b.minute);
  return events;
}

function applyMatchToState(state: GameState, match: MatchResult) {
  const s = state.seasonStats;
  if (match.minutes > 0) {
    s.appearances += 1;
    if (match.minutes >= 60) s.starts += 1;
    s.minutes += match.minutes;
    s.goals += match.goals;
    s.assists += match.assists;
    s.ratingSum += match.rating;
    s.avgRating = round1(s.ratingSum / s.appearances);
    if (match.yellow) s.yellows += 1;
    if (match.red) s.reds += 1;
    if (match.motm) s.motm += 1;
    if (match.goalsFor === 0 && match.minutes >= 60 && (state.player.position === "GK" || state.player.position === "CB")) {
      s.cleanSheets += 1;
    }
  }
  if (match.result === "W") s.wins += 1;
  else if (match.result === "D") s.draws += 1;
  else s.losses += 1;

  state.form = clamp(state.form + (match.rating - 6.6) * 3.2, 20, 99);
  state.morale = clamp(state.morale + (match.result === "W" ? 4 : match.result === "D" ? 0 : -4) + (match.motm ? 6 : 0), 15, 99);
  state.fitness = clamp(state.fitness - (match.minutes > 70 ? 8 : match.minutes > 20 ? 5 : 1), 25, 100);
  state.fame = clamp(
    state.fame + (match.goals * 1.4 + (match.motm ? 2 : 0) + (match.preview.importance === "final" && match.result === "W" ? 4 : 0)),
    0,
    100,
  );
  if (match.minutes >= 60) {
    growFromMatch(state, match.rating);
  }
  if (match.injured) {
    state.injury = match.injured;
    if (match.injured.chronic) {
      state.chronicPenalty += 1;
      state.player.attributes.physical = clamp(state.player.attributes.physical - 2, 25, 99);
      state.player.attributes.pace = clamp(state.player.attributes.pace - 1, 25, 99);
      recalcOvr(state);
    }
    pushNews(state, `Lesao: ${match.injured.name}. Previsao de ${match.injured.weeksTotal} semana(s).`, "bad");
    state.morale = clamp(state.morale - 8, 10, 99);
  }
  state.matchLoad.push(match.minutes >= 45 ? 1 : 0);
  if (state.matchLoad.length > 12) state.matchLoad.shift();
  state.lastMatch = match;
  state.pendingMatch = null;
  const notable = match.motm || match.goals >= 2 || match.injured || match.preview.importance === "final" || match.rating >= 8.2;
  if (notable) {
    state.highlights.unshift(match);
    state.highlights = state.highlights.slice(0, 16);
  }
  state.followers = clamp(
    state.followers + match.goals * 1800 + (match.motm ? 4000 : 0) + Math.round(match.rating * 80),
    0,
    80_000_000,
  );
}

function growFromMatch(state: GameState, rating: number) {
  if (state.mode === "complete") return;
  const age = state.player.age;
  const room = state.player.potential - state.player.overall;
  if (room <= 0 || age > 32) return;
  const rng = rngFrom(state);
  const speed = age <= 21 ? 1 : age <= 26 ? 0.55 : 0.22;
  if (rng() < 0.35 * speed * clamp(rating / 7.5, 0.6, 1.4)) {
    const w = POSITION_WEIGHTS[state.player.position];
    const keys = ATTR_KEYS.filter((k) => w[k] >= 0.1);
    const key = pick(rng, keys);
    state.player.attributes[key] = clamp(state.player.attributes[key] + 1, 25, 99);
    recalcOvr(state);
  }
}

export function recalcOvr(state: GameState) {
  state.player.overall = calcOverall(state.player.position, state.player.attributes);
  state.player.cardStyle = cardFromOverall(state.player.overall);
  state.peakOverall = Math.max(state.peakOverall, state.player.overall);
}

export function trainWeek(state: GameState, focus: TrainFocus) {
  const rng = rngFrom(state);
  if (focus === "rest") {
    state.fitness = clamp(state.fitness + 14, 25, 100);
    state.morale = clamp(state.morale + 2, 10, 99);
    pushNews(state, "Semana de recuperacao. O corpo agradece.", "neutral");
    return;
  }
  state.fitness = clamp(state.fitness - (focus === "extra" ? 10 : 5), 20, 100);
  const age = state.player.age;
  const room = state.player.potential + 1 - state.player.overall;
  const speed = age <= 21 ? 1.15 : age <= 26 ? 0.7 : age <= 30 ? 0.3 : 0.08;
  if (focus === "extra") {
    const inj = maybeInjury(state, 1.4);
    if (inj) {
      state.injury = inj;
      pushNews(state, `Treino pesado demais: ${inj.name}.`, "bad");
      return;
    }
  }
  if (room > 0 && rng() < 0.62 * speed) {
    const key: AttrKey = focus === "extra" ? pick(rng, ATTR_KEYS) : focus;
    const bump = rng() > 0.85 && age <= 20 ? 2 : 1;
    state.player.attributes[key] = clamp(state.player.attributes[key] + bump, 25, 99);
    recalcOvr(state);
    pushNews(state, `Evolucao em ${keyLabel(key)}. Overall ${state.player.overall}.`, "good");
  } else {
    state.form = clamp(state.form + 2, 20, 99);
  }
}

function keyLabel(k: AttrKey): string {
  const map: Record<AttrKey, string> = {
    pace: "ritmo",
    shooting: "finalizacao",
    passing: "passe",
    dribbling: "drible",
    defending: "defesa",
    physical: "fisico",
    vision: "QI de jogo",
  };
  return map[k];
}

function payWeek(state: GameState) {
  const sponsor = state.sponsorships.reduce((s, x) => s + x.weekly, 0);
  state.money += state.weeklyWage + sponsor;
}

function tickInjury(state: GameState) {
  if (!state.injury) return;
  state.injury.weeksLeft -= 1;
  state.fitness = clamp(state.fitness + 4, 20, 90);
  if (state.injury.weeksLeft <= 0) {
    pushNews(state, `Alta medica. ${state.injury.name} ficou para tras.`, "good");
    state.injury = null;
    state.morale = clamp(state.morale + 6, 10, 99);
  }
}

function estimatePlace(rep: number, playerSwing: number): number {
  const quality = rep + playerSwing;
  const place = Math.round(18 - (quality - 64) / 2.1);
  return clamp(place, 1, 20);
}

function seasonTitles(state: GameState): Title[] {
  const club = clubById(state.clubId);
  const rng = rngFrom(state);
  const swing = (state.seasonStats.avgRating - 6.5) * (state.seasonStats.appearances / 30) * 7;
  const place = estimatePlace(club.reputation, swing + (rng() - 0.5) * 4);
  state.leaguePlace = place;
  const titles: Title[] = [];
  const mk = (name: string, type: Title["type"]): Title => ({
    id: `${state.season}-${name}`,
    season: state.season,
    name,
    clubId: club.id,
    type,
  });
  if (place === 1) titles.push(mk(club.league, "liga"));
  if (place <= 2 && club.countryCode === "BRA" && rng() > 0.65) titles.push(mk("Libertadores", "continental"));
  if (place <= 2 && club.reputation >= 90 && rng() > 0.7) titles.push(mk("Champions League", "continental"));
  if (place <= 4 && rng() > 0.72) titles.push(mk(club.countryCode === "BRA" ? "Copa do Brasil" : "Copa nacional", "copa"));
  if (state.seasonStats.goals >= 20 && state.player.position === "ST") titles.push(mk("Artilheiro", "individual"));
  if (state.seasonStats.avgRating >= 7.6 && state.seasonStats.appearances >= 22) titles.push(mk("Craque da temporada", "individual"));
  return titles;
}

export function generateOffers(state: GameState, window: "meio" | "fim"): TransferOffer[] {
  const rng = rngFrom(state);
  const ovr = state.player.overall;
  const pot = state.player.potential;
  const fame = state.fame;
  const current = clubById(state.clubId);
  const attracted = CLUBS.filter((c) => c.id !== current.id).filter((c) => {
    const want = ovr + (pot - ovr) * 0.35 + fame * 0.08;
    if (c.reputation > want + 10) return false;
    if (c.reputation + 16 < ovr) return rng() > 0.7;
    return rng() > 0.42;
  });
  const shuffled = attracted.sort(() => rng() - 0.5).slice(0, randInt(rng, 1, 4));
  return shuffled.map((c) => {
    const role = roleFromGap(ovr, c.reputation);
    const wageMul = role === "estrela" ? 0.55 : role === "titular" ? 0.32 : role === "rotacao" ? 0.16 : 0.07;
    const wage = clamp(Math.round(c.wageBudget * wageMul * (0.8 + rng() * 0.5)), 400, c.wageBudget);
    return {
      id: `off-${c.id}-${state.season}-${window}-${state.rngCount}-${rng()}`,
      clubId: c.id,
      wage,
      years: randInt(rng, 2, 5),
      shirtNumber: state.player.shirtNumber,
      role,
      signingBonus: Math.round(wage * randInt(rng, 8, 22)),
      window,
      releaseClause: Math.round(wage * randInt(rng, 70, 200)),
    };
  });
}

function mergeCareerStats(state: GameState) {
  const c = state.stats;
  const s = state.seasonStats;
  c.appearances += s.appearances;
  c.starts += s.starts;
  c.minutes += s.minutes;
  c.goals += s.goals;
  c.assists += s.assists;
  c.cleanSheets += s.cleanSheets;
  c.yellows += s.yellows;
  c.reds += s.reds;
  c.motm += s.motm;
  c.wins += s.wins;
  c.draws += s.draws;
  c.losses += s.losses;
  const totalApp = c.appearances;
  c.ratingSum += s.ratingSum;
  c.avgRating = totalApp ? round1(c.ratingSum / totalApp) : 0;
  c.seasons += 1;
}

function agePlayer(state: GameState) {
  state.player.age += 1;
  const rng = rngFrom(state);
  const age = state.player.age;
  if (age >= 29) {
    const drop = age >= 34 ? 2 : 1;
    if (rng() > 0.35) state.player.attributes.pace = clamp(state.player.attributes.pace - drop, 25, 99);
    if (rng() > 0.5) state.player.attributes.physical = clamp(state.player.attributes.physical - 1, 25, 99);
    recalcOvr(state);
  }
  if (age >= 38 || (age >= 35 && state.player.overall < 62 && rng() > 0.4)) {
    state.retired = true;
    state.retireReason = age >= 38 ? "O corpo pediu a aposentadoria aos 38." : "Os clubes pararam de ligar. Fim de linha.";
  }
}

export function endSeason(state: GameState): SeasonRecap {
  const club = clubById(state.clubId);
  const cardFrom = state.player.cardStyle;
  const followersFrom = state.followers;
  const titles = seasonTitles(state);
  state.titles.push(...titles);
  for (const t of titles) {
    pushNews(state, `Titulo: ${t.name}.`, "good");
    state.fame = clamp(state.fame + (t.type === "individual" ? 5 : 8), 0, 100);
    state.money += t.type === "continental" ? 400000 : t.type === "liga" ? 180000 : 60000;
    state.followers += t.type === "continental" ? 250000 : t.type === "liga" ? 80000 : 25000;
  }

  const points = seasonPointsFor(state.seasonStats, titles.length);
  if (state.mode === "complete") state.seasonPoints += points;
  else autoSpend(state, points);

  recalcOvr(state);

  const rng = rngFrom(state);
  const under =
    (state.seasonStats.avgRating < 6.15 && state.seasonStats.appearances >= 10 && club.reputation >= state.player.overall + 5) ||
    (state.seasonStats.appearances < 8 && state.player.age >= 19 && club.reputation > 82);
  const sacked = !state.retired && under && rng() > 0.42;
  if (sacked) {
    state.sacked = true;
    state.contractYearsLeft = 0;
    pushNews(state, `${club.name} rescindiu por baixo rendimento.`, "bad");
    state.morale = clamp(state.morale - 12, 10, 99);
  } else {
    state.sacked = false;
  }

  let raiseOffer: number | null = null;
  if (!sacked && state.seasonStats.avgRating >= 7.1 && rng() > 0.35) {
    raiseOffer = Math.round(state.weeklyWage * (1.12 + rng() * 0.2));
    state.pendingRaise = raiseOffer;
  } else {
    state.pendingRaise = null;
  }

  let brandOffer: Sponsorship | null = null;
  if (state.fame >= 20 && state.sponsorships.length < 2 && rng() > 0.45) {
    brandOffer = {
      id: `br-${state.rngCount}`,
      brand: pick(rng, SPONSOR_BRANDS),
      weekly: Math.round(180 + state.fame * 45 * (0.7 + rng() * 0.9)),
      seasonsLeft: 2,
      followersBoost: Math.round(8000 + state.fame * 900),
    };
    state.pendingBrand = brandOffer;
  } else {
    state.pendingBrand = null;
  }

  const seasonHighlights = state.highlights.filter((h) => h.preview.week >= 1);
  const recap: SeasonRecap = {
    season: state.season,
    year: state.year,
    clubName: club.name,
    stats: { ...state.seasonStats },
    titles,
    overallFrom: state.overallAtSeasonStart,
    overallTo: state.player.overall,
    leaguePlace: state.leaguePlace,
    nextOffers: generateOffers(state, "fim"),
    points,
    highlights: seasonHighlights.slice(0, 6),
    sacked,
    raiseOffer,
    brandOffer,
    followersFrom,
    followersTo: Math.round(state.followers),
    cardFrom,
    cardTo: state.player.cardStyle,
  };
  state.offers = recap.nextOffers;
  mergeCareerStats(state);
  state.seasonStats = emptySeasonStats();
  if (!sacked) state.contractYearsLeft -= 1;
  for (const sp of state.sponsorships) sp.seasonsLeft -= 1;
  state.sponsorships = state.sponsorships.filter((s) => s.seasonsLeft > 0);
  agePlayer(state);
  state.season += 1;
  state.year += 1;
  state.week = 1;
  state.overallAtSeasonStart = state.player.overall;
  state.fitness = 88;
  state.form = clamp(state.form, 40, 80);
  if ((state.contractYearsLeft <= 0 || sacked) && !state.retired) {
    pushNews(state, sacked ? "Voce esta livre. Escolhe o proximo clube." : "Contrato acabou. Escolhe a proxima camisa.", "transfer");
    if (state.offers.length === 0) state.offers = generateOffers(state, "fim");
    if (state.offers.length === 0) {
      const smaller = CLUBS.filter((c) => c.reputation <= state.player.overall + 4).sort((a, b) => b.reputation - a.reputation)[0];
      if (smaller) {
        acceptOffer(state, {
          id: "free",
          clubId: smaller.id,
          wage: startingWage(state.player.overall, smaller),
          years: 2,
          shirtNumber: state.player.shirtNumber,
          role: "rotacao",
          signingBonus: 0,
          window: "fim",
          releaseClause: startingWage(state.player.overall, smaller) * 80,
        });
      }
    }
  }
  if (state.mode === "fast" && state.offers.length && !state.retired) {
    const current = clubById(state.clubId);
    const best = [...state.offers].sort((a, b) => clubById(b.clubId).reputation - clubById(a.clubId).reputation)[0];
    if (best && (sacked || state.contractYearsLeft <= 0 || clubById(best.clubId).reputation > current.reputation + 1)) {
      acceptOffer(state, best);
    }
  }
  state.highlights = [];
  if (state.retired) state.historyRank = careerRank(state);
  return recap;
}

export function acceptOffer(state: GameState, offer: TransferOffer) {
  const from = clubById(state.clubId);
  const to = clubById(offer.clubId);
  state.clubId = to.id;
  state.weeklyWage = offer.wage;
  state.contractYearsLeft = offer.years;
  state.contractYearsTotal = offer.years;
  state.releaseClause = offer.releaseClause;
  state.sacked = false;
  state.player.shirtNumber = offer.shirtNumber;
  state.money += offer.signingBonus;
  state.fame = clamp(state.fame + Math.max(0, (to.reputation - from.reputation) / 4), 0, 100);
  state.morale = clamp(state.morale + 8, 10, 99);
  if (!state.stats.clubs.includes(to.id)) state.stats.clubs.push(to.id);
  state.offers = [];
  pushNews(
    state,
    `Transferencia: ${from.name} → ${to.name}. ${offer.years} anos, ${formatMoney(offer.wage, to.countryCode)}/sem.`,
    "transfer",
  );
}

export function rejectOffers(state: GameState) {
  state.offers = [];
  state.agentMood = clamp(state.agentMood - 4, 10, 99);
}

export function playWeek(state: GameState, choice: MatchChoiceId | null): { match: MatchResult | null; recap: SeasonRecap | null } {
  if (state.retired) return { match: null, recap: null };
  tickInjury(state);
  payWeek(state);
  let match: MatchResult | null = null;
  if (!state.injury) {
    if (!state.pendingMatch) state.pendingMatch = buildFixture(state);
    match = simulateMatch(state, choice);
    applyMatchToState(state, match);
  } else {
    state.pendingMatch = null;
    state.form = clamp(state.form - 2, 20, 99);
  }
  if (state.week === 20 && state.offers.length === 0) {
    const mid = generateOffers(state, "meio");
    if (mid.length) {
      state.offers = mid;
      pushNews(state, `${mid.length} proposta(s) na janela do meio da temporada.`, "transfer");
    }
  }
  state.week += 1;
  if (state.week > 38) {
    const recap = endSeason(state);
    return { match, recap };
  }
  return { match, recap: null };
}

export function simulateSeasons(state: GameState, years: number): FastRecap {
  const overallFrom = state.player.overall;
  const fameFrom = state.fame;
  const money0 = state.money;
  const lines: FastSeasonLine[] = [];
  for (let y = 0; y < years; y++) {
    if (state.retired) break;
    const seasonNo = state.season;
    const year = state.year;
    const clubId = state.clubId;
    const ovr = state.player.overall;
    let injuryWeeks = 0;
    while (state.season === seasonNo && !state.retired) {
      const before = state.week;
      if (state.injury) injuryWeeks += 1;
      const focus: TrainFocus = state.fitness < 55 ? "rest" : pick(rngFrom(state), ["shooting", "passing", "dribbling", "pace", "defending", "physical", "vision", "rest"]);
      if (!state.injury) trainWeek(state, focus);
      playWeek(state, null);
      if (state.week === before && state.season === seasonNo) break;
    }
    const club = clubById(clubId);
    const recapTitles = state.titles.filter((t) => t.season === seasonNo).map((t) => t.name);
    lines.push({
      season: seasonNo,
      year,
      clubId,
      clubName: club.name,
      position: state.player.position,
      overall: ovr,
      appearances: 0,
      goals: 0,
      assists: 0,
      avgRating: 0,
      titles: recapTitles,
      wage: state.weeklyWage,
      fame: state.fame,
      injuryWeeks,
    });
    // seasonStats already merged; pull last recap from career increment is hard — store on line from titles only
  }
  // Fill stats from career delta is lossy; recompute last seasons from titles/news is fine.
  // Better: capture seasonStats before merge. We already merged inside endSeason.
  // Patch lines using titles and remaining offers.
  return {
    years: lines.length,
    lines,
    moneyGained: state.money - money0,
    overallFrom,
    overallTo: state.player.overall,
    fameFrom,
    fameTo: state.fame,
    nextOffers: state.offers,
  };
}

export function simulateSeasonsTracked(state: GameState, years: number): FastRecap {
  const overallFrom = state.player.overall;
  const fameFrom = state.fame;
  const money0 = state.money;
  const lines: FastSeasonLine[] = [];
  for (let y = 0; y < years; y++) {
    if (state.retired) break;
    const clubId = state.clubId;
    const clubName = clubById(clubId).name;
    const year = state.year;
    const seasonNo = state.season;
    const pos = state.player.position;
    let injuryWeeks = 0;
    while (state.week <= 38 && state.season === seasonNo && !state.retired) {
      if (state.injury) injuryWeeks += 1;
      const rng = rngFrom(state);
      const focus: TrainFocus =
        state.fitness < 58 ? "rest" : pick(rng, ["shooting", "passing", "dribbling", "pace", "defending", "physical", "vision"]);
      if (!state.injury && state.week % 2 === 1) trainWeek(state, focus);
      const { recap } = playWeek(state, null);
      if (recap) {
        lines.push({
          season: recap.season,
          year: recap.year,
          clubId,
          clubName,
          position: pos,
          overall: recap.overallTo,
          appearances: recap.stats.appearances,
          goals: recap.stats.goals,
          assists: recap.stats.assists,
          avgRating: recap.stats.avgRating,
          titles: recap.titles.map((t) => t.name),
          wage: state.weeklyWage,
          fame: state.fame,
          injuryWeeks,
        });
        break;
      }
    }
  }
  return {
    years: lines.length,
    lines,
    moneyGained: state.money - money0,
    overallFrom,
    overallTo: state.player.overall,
    fameFrom,
    fameTo: state.fame,
    nextOffers: state.offers,
  };
}

export function agentReply(state: GameState, intent: "raise" | "transfer" | "sponsor" | "loan" | "number" | "resign" | "position"): string {
  const rng = rngFrom(state);
  const club = clubById(state.clubId);
  switch (intent) {
    case "raise": {
      const deserved = state.seasonStats.avgRating >= 7.2 || state.fame > 45;
      if (deserved && rng() < 0.55 + state.agentMood / 400) {
        const bump = Math.round(state.weeklyWage * (0.12 + rng() * 0.18));
        state.weeklyWage += bump;
        state.agentMood = clamp(state.agentMood + 4, 10, 99);
        pushNews(state, `Aumento aprovado: +${formatMoney(bump, club.countryCode)}/sem.`, "good");
        return `Fechei. O clube topou ${formatMoney(state.weeklyWage, club.countryCode)} por semana. Nao estraga o momento.`;
      }
      state.agentMood = clamp(state.agentMood - 3, 10, 99);
      return "Agora nao. Joga tres partidas boas e eu volto na diretoria.";
    }
    case "transfer": {
      const offers = generateOffers(state, state.week < 20 ? "meio" : "fim");
      state.offers = offers;
      if (!offers.length) return "Ninguem do seu nivel ligou. Espera a janela.";
      return `${offers.length} clube(s) na mesa. Voce so escolhe sim ou nao.`;
    }
    case "sponsor": {
      if (state.fame < 22) return "Patrocinio pesado exige fama. Marca gols, aparece, depois a gente cobra a Nike.";
      if (state.sponsorships.length >= 2) return "Ja temos contratos no limite. Cumpre esses primeiro.";
      const brand = pick(rng, SPONSOR_BRANDS);
      const weekly = Math.round(200 + state.fame * 40 * (0.7 + rng() * 0.8));
      const sp: Sponsorship = { id: `sp-${state.rngCount}`, brand, weekly, seasonsLeft: 2, followersBoost: Math.round(5000 + state.fame * 700) };
      state.sponsorships.push(sp);
      state.followers += sp.followersBoost;
      pushNews(state, `${brand} no peito. ${formatMoney(weekly, club.countryCode)}/sem.`, "good");
      return `${brand} fechou. ${formatMoney(weekly, club.countryCode)} por semana, duas temporadas.`;
    }
    case "loan": {
      const smaller = CLUBS.filter((c) => c.id !== club.id && c.reputation < club.reputation - 6 && c.reputation > state.player.overall - 12);
      if (!smaller.length) return "Nao tem emprestimo que faça sentido agora.";
      const dest = pick(rng, smaller);
      const offer: TransferOffer = {
        id: `loan-${dest.id}`,
        clubId: dest.id,
        wage: Math.round(state.weeklyWage * 0.85),
        years: 1,
        shirtNumber: state.player.shirtNumber,
        role: "titular",
        signingBonus: 0,
        window: "meio",
        releaseClause: Math.round(state.weeklyWage * 40),
      };
      state.offers = [offer];
      return `${dest.name} topa te pegar por uma temporada para jogar toda semana. E um emprestimo na pratica.`;
    }
    case "number":
      return "Numero e vaidade, mas vaidade vende camisa. Escolhe ai que eu resolvo com o departamento.";
    case "position": {
      const chance = (state.player.age <= 21 ? 0.72 : 0.42) + (state.player.overall >= 78 ? 0.12 : 0) + state.agentMood / 500;
      if (rng() > chance) {
        state.agentMood = clamp(state.agentMood - 2, 10, 99);
        return "O tecnico nao topa agora. Joga onde ele mandar mais um pouco.";
      }
      return "Ele aceita conversar. Confirma a nova posicao ai embaixo que eu fecho.";
    }
    case "resign": {
      const cost = Math.round(state.releaseClause * 0.35);
      if (state.money < cost) return `Rescisao custa ${formatMoney(cost, club.countryCode)}. Sem fortuna para isso.`;
      if (rng() < 0.35) return "O clube nao abre a porta agora.";
      state.money -= cost;
      state.contractYearsLeft = 0;
      state.offers = generateOffers(state, "fim");
      pushNews(state, "Rescisao paga. Voce esta livre.", "transfer");
      return "Paguei a multa. Escolhe o proximo clube.";
    }
  }
}

export function tryChangePosition(state: GameState, position: Position): string {
  if (position === state.player.position) return "Ja e essa posicao.";
  const rng = rngFrom(state);
  const chance = (state.player.age <= 22 ? 0.7 : 0.38) + (state.player.overall >= 78 ? 0.12 : 0);
  if (rng() > chance) {
    state.agentMood = clamp(state.agentMood - 3, 10, 99);
    pushNews(state, "Pedido de nova posicao recusado.", "neutral");
    return "O tecnico recusou. Sorte nao veio. Tenta de novo depois de uma temporada boa.";
  }
  changePosition(state, position);
  return `Fechado. Voce vira ${position}. Overall agora ${state.player.overall}.`;
}

export function changePosition(state: GameState, position: Position) {
  if (position === state.player.position) return;
  state.player.position = position;
  recalcOvr(state);
  state.morale = clamp(state.morale - 4, 10, 99);
  pushNews(state, `Nova posicao: ${position}. Overall agora ${state.player.overall}.`, "neutral");
}

export function changeNumber(state: GameState, n: number) {
  state.player.shirtNumber = clamp(Math.round(n), 1, 99);
  pushNews(state, `Camisa ${state.player.shirtNumber} nas costas.`, "neutral");
}

export function cloneState(state: GameState): GameState {
  return structuredClone(state);
}

export function seasonPointsFor(stats: SeasonStats, titles: number): number {
  const raw =
    stats.appearances * 0.12 +
    stats.goals * 0.55 +
    stats.assists * 0.45 +
    Math.max(0, stats.avgRating - 6) * 7 +
    stats.motm * 1.2 +
    titles * 5;
  return clamp(Math.round(raw), 4, 26);
}

export function spendPoint(state: GameState, attr: AttrKey): boolean {
  if (state.seasonPoints <= 0) return false;
  const cap = Math.min(99, state.player.potential + 3);
  if (state.player.attributes[attr] >= cap) return false;
  state.player.attributes[attr] += 1;
  state.seasonPoints -= 1;
  recalcOvr(state);
  return true;
}

export function autoSpend(state: GameState, points: number) {
  const w = POSITION_WEIGHTS[state.player.position];
  const ranked = [...ATTR_KEYS].sort((a, b) => w[b] - w[a]);
  let left = points;
  let guard = 0;
  while (left > 0 && guard < 80) {
    guard += 1;
    const key = ranked[guard % ranked.length] as AttrKey;
    const cap = Math.min(99, state.player.potential + 3);
    if (state.player.attributes[key] >= cap) {
      left -= 1;
      continue;
    }
    state.player.attributes[key] += 1;
    left -= 1;
  }
  recalcOvr(state);
}

export function acceptRaise(state: GameState) {
  if (!state.pendingRaise) return;
  state.weeklyWage = state.pendingRaise;
  state.pendingRaise = null;
  pushNews(state, "Aumento aceito.", "good");
}

export function rejectRaise(state: GameState) {
  state.pendingRaise = null;
}

export function acceptBrand(state: GameState) {
  if (!state.pendingBrand) return;
  state.sponsorships.push(state.pendingBrand);
  state.followers += state.pendingBrand.followersBoost;
  pushNews(state, `Publi: ${state.pendingBrand.brand}.`, "good");
  state.pendingBrand = null;
}

export function rejectBrand(state: GameState) {
  state.pendingBrand = null;
}

export function simulateSeason(state: GameState): SeasonRecap | null {
  if (state.retired) return null;
  const start = state.season;
  let last: SeasonRecap | null = null;
  for (let i = 0; i < 42; i++) {
    const { recap } = playWeek(state, null);
    if (recap) {
      last = recap;
      break;
    }
    if (state.season !== start) break;
  }
  return last;
}

export function careerRank(state: GameState): HistoryRank {
  const titles = state.titles.length;
  const champs = state.titles.filter((t) => t.type === "continental").length;
  const peak = state.peakOverall;
  const fame = state.fame;
  if (peak >= 90 || titles >= 8 || champs >= 2) {
    return { id: "lenda", label: "Lenda", copy: "Nome gravado. Os moleques vao copiar a comemoracao." };
  }
  if (peak >= 86 || titles >= 5) {
    return { id: "fenomeno", label: "Fenomeno", copy: "Pico absurdo. Uma geracao inteira discute voce." };
  }
  if (peak >= 80 || titles >= 3 || fame >= 72) {
    return { id: "craque", label: "Craque", copy: "Decide jogo grande. Camisa pesada, carreira limpa." };
  }
  if (peak >= 74 || titles >= 1 || fame >= 50) {
    return { id: "astro", label: "Astro", copy: "Virou cara de cartaz. Nao e eterno, mas brilhou." };
  }
  if (state.stats.appearances >= 180) {
    return { id: "profissional", label: "Profissional", copy: "Comeu po, cumpriu contrato, construiu fortuna." };
  }
  return { id: "promessa", label: "Promessa", copy: "O talento existia. A carreira nao fechou a conta." };
}

export function coachRankOf(titles: number, years: number): CoachRank {
  if (titles >= 8 || (titles >= 5 && years <= 10)) {
    return { id: "lenda-banco", label: "Lenda do banco", copy: "Virou escola. Outros tecnicos copiam o seu quadro." };
  }
  if (titles >= 4) {
    return { id: "vencedor", label: "Tecnico vencedor", copy: "Ganhou o que tinha que ganhar. Ninguem discute o curriculo." };
  }
  if (titles >= 1) {
    return { id: "competente", label: "Tecnico competente", copy: "Entregou titulo e sobreviveu a janela. Carreira honesta." };
  }
  return { id: "passagem", label: "Passagem", copy: "Rodou clubes, quase levantou taca. O banco nao perdoou." };
}

export function lifeVerdictOf(state: GameState): string {
  const p = state.historyRank?.id ?? careerRank(state).id;
  const c = state.coach?.rank.id;
  if (!c) {
    if (p === "lenda" || p === "fenomeno") return "Jogador para a historia. Nao quis o banco.";
    if (p === "craque" || p === "astro") return "Brilhou em campo. A segunda carreira ficou em branco.";
    return "A chuteira falou mais alto que o apito. Historia incompleta no banco.";
  }
  if ((p === "lenda" || p === "fenomeno") && (c === "lenda-banco" || c === "vencedor")) {
    return "Lenda em campo e lenda no banco. Carreira completa.";
  }
  if ((p === "lenda" || p === "fenomeno") && c === "passagem") {
    return "Genio com a bola, comum com o apito. O campo foi maior.";
  }
  if ((p === "promessa" || p === "profissional") && (c === "lenda-banco" || c === "vencedor")) {
    return "O jogador foi honesto. O tecnico foi grande.";
  }
  if (p === "craque" && (c === "vencedor" || c === "lenda-banco")) {
    return "Craque que ainda mandou no vestiario. Dois curriculos pesados.";
  }
  if (c === "passagem") return "Jogou, treinou, passou. Falta uma taca que feche o livro.";
  return "Boa vida nos dois lados da linha. Nem lenda eterna, nem esquecido.";
}

export function simulateCoachCareer(state: GameState): CoachState {
  const rng = rngFrom(state);
  const years = randInt(rng, 8, 14);
  const lines: CoachLine[] = [];
  let titles = 0;
  let club = clubById(state.clubId);
  const famePull = 60 + state.fame * 0.35 + Math.max(0, state.peakOverall - 72);
  const pool = [...CLUBS].sort((a, b) => Math.abs(a.reputation - famePull) - Math.abs(b.reputation - famePull));
  for (let i = 0; i < years; i++) {
    if (i === 0 || rng() > 0.62) club = pick(rng, pool.slice(0, 14));
    const boost = clamp(state.peakOverall - 70, 0, 18) + (state.historyRank?.id === "lenda" ? 4 : 0);
    const place = clamp(Math.round(10 - boost / 4 + (rng() - 0.5) * 8), 1, 18);
    const won: string[] = [];
    if (place === 1) {
      won.push(club.league);
      titles += 1;
    }
    if (place <= 3 && rng() > 0.7) {
      won.push(club.countryCode === "BRA" ? "Copa do Brasil" : "Copa nacional");
      titles += 1;
    }
    if (place === 1 && club.reputation >= 88 && rng() > 0.75) {
      won.push(club.countryCode === "BRA" ? "Libertadores" : "Champions League");
      titles += 1;
    }
    lines.push({ year: state.year + i, clubName: club.name, place, titles: won });
  }
  const rank = coachRankOf(titles, years);
  const coach: CoachState = { active: true, years, lines, titles, rank };
  state.coach = coach;
  if (!state.historyRank) state.historyRank = careerRank(state);
  state.lifeVerdict = lifeVerdictOf(state);
  return coach;
}

export function retireNow(state: GameState) {
  state.retired = true;
  state.retireReason = `Pendurou as chuteiras aos ${state.player.age}.`;
  state.historyRank = careerRank(state);
}
