export const SAVE_VERSION = 3;

export type Position =
  | "GK"
  | "CB"
  | "LB"
  | "RB"
  | "CDM"
  | "CM"
  | "CAM"
  | "LM"
  | "RM"
  | "LW"
  | "RW"
  | "ST";

export type AttrKey =
  | "pace"
  | "shooting"
  | "passing"
  | "dribbling"
  | "defending"
  | "physical"
  | "vision";

export type Attributes = Record<AttrKey, number>;

export type CardStyle = "bronze" | "silver" | "gold" | "rare" | "fenomeno";

export type GameMode = "complete" | "fast";

export type InjurySeverity = "leve" | "media" | "grave" | "cronica";

export type Injury = {
  id: string;
  name: string;
  severity: InjurySeverity;
  weeksLeft: number;
  weeksTotal: number;
  chronic: boolean;
};

export type Club = {
  id: string;
  name: string;
  shortName: string;
  country: string;
  countryCode: string;
  league: string;
  reputation: number;
  wageBudget: number;
  colors: [string, string];
};

export type Nation = {
  id: string;
  name: string;
  code: string;
};

export type Appearance = {
  skin: number;
  hair: "buzz" | "short" | "fade" | "long" | "curly";
  facial: "none" | "stubble" | "beard";
  photo: string | null;
};

export type SkillSteal = {
  legend: string;
  attr: AttrKey;
  rare: boolean;
};

export type TransferOffer = {
  id: string;
  clubId: string;
  wage: number;
  years: number;
  shirtNumber: number;
  role: "promessa" | "rotacao" | "titular" | "estrela";
  signingBonus: number;
  window: "meio" | "fim";
  releaseClause: number;
};

export type Sponsorship = {
  id: string;
  brand: string;
  weekly: number;
  seasonsLeft: number;
  followersBoost: number;
};

export type Title = {
  id: string;
  season: number;
  name: string;
  clubId: string;
  type: "liga" | "copa" | "continental" | "individual";
};

export type SeasonStats = {
  appearances: number;
  starts: number;
  minutes: number;
  goals: number;
  assists: number;
  cleanSheets: number;
  yellows: number;
  reds: number;
  avgRating: number;
  ratingSum: number;
  motm: number;
  wins: number;
  draws: number;
  losses: number;
};

export type CareerStats = SeasonStats & {
  seasons: number;
  clubs: string[];
};

export type NewsItem = {
  id: string;
  week: number;
  season: number;
  text: string;
  tone: "good" | "bad" | "neutral" | "transfer";
};

export type MatchEvent = {
  minute: number;
  text: string;
  kind: "play" | "goal" | "assist" | "card" | "injury" | "whistle";
};

export type MatchChoiceId = "safe" | "hero" | "war" | "pass" | "shoot";

export type MatchPreview = {
  opponentName: string;
  opponentRep: number;
  competition: string;
  home: boolean;
  importance: "normal" | "big" | "final";
  week: number;
};

export type MatchResult = {
  preview: MatchPreview;
  playerTeam: string;
  opponent: string;
  home: boolean;
  goalsFor: number;
  goalsAgainst: number;
  result: "W" | "D" | "L";
  rating: number;
  minutes: number;
  goals: number;
  assists: number;
  yellow: boolean;
  red: boolean;
  motm: boolean;
  events: MatchEvent[];
  choice: MatchChoiceId | null;
  injured: Injury | null;
  competition: string;
};

export type FastSeasonLine = {
  season: number;
  year: number;
  clubId: string;
  clubName: string;
  position: Position;
  overall: number;
  appearances: number;
  goals: number;
  assists: number;
  avgRating: number;
  titles: string[];
  wage: number;
  fame: number;
  injuryWeeks: number;
};

export type FastRecap = {
  years: number;
  lines: FastSeasonLine[];
  moneyGained: number;
  overallFrom: number;
  overallTo: number;
  fameFrom: number;
  fameTo: number;
  nextOffers: TransferOffer[];
};

export type SeasonRecap = {
  season: number;
  year: number;
  clubName: string;
  stats: SeasonStats;
  titles: Title[];
  overallFrom: number;
  overallTo: number;
  leaguePlace: number;
  nextOffers: TransferOffer[];
  points: number;
  highlights: MatchResult[];
  sacked: boolean;
  raiseOffer: number | null;
  brandOffer: Sponsorship | null;
  followersFrom: number;
  followersTo: number;
  cardFrom: CardStyle;
  cardTo: CardStyle;
};

export type AgentMessage = {
  id: string;
  from: "you" | "agent";
  text: string;
};

export type HistoryRank = {
  id: "lenda" | "fenomeno" | "craque" | "astro" | "profissional" | "promessa";
  label: string;
  copy: string;
};

export type CoachRank = {
  id: "lenda-banco" | "vencedor" | "competente" | "passagem";
  label: string;
  copy: string;
};

export type CoachLine = {
  year: number;
  clubName: string;
  place: number;
  titles: string[];
};

export type CoachState = {
  active: boolean;
  years: number;
  lines: CoachLine[];
  titles: number;
  rank: CoachRank;
};

export type Player = {
  name: string;
  nationId: string;
  position: Position;
  shirtNumber: number;
  age: number;
  overall: number;
  potential: number;
  attributes: Attributes;
  cardStyle: CardStyle;
  playStyle: string;
  idolId: string;
  idolName: string;
  steals: SkillSteal[];
  appearance: Appearance;
};

export type GameState = {
  version: number;
  mode: GameMode;
  seed: number;
  rngCount: number;
  player: Player;
  clubId: string;
  week: number;
  season: number;
  year: number;
  money: number;
  weeklyWage: number;
  fame: number;
  morale: number;
  form: number;
  fitness: number;
  aggression: number;
  injury: Injury | null;
  chronicPenalty: number;
  contractYearsLeft: number;
  contractYearsTotal: number;
  releaseClause: number;
  stats: CareerStats;
  seasonStats: SeasonStats;
  titles: Title[];
  news: NewsItem[];
  offers: TransferOffer[];
  sponsorships: Sponsorship[];
  agentMood: number;
  matchLoad: number[];
  pendingMatch: MatchPreview | null;
  lastMatch: MatchResult | null;
  retired: boolean;
  retireReason: string | null;
  overallAtSeasonStart: number;
  leaguePlace: number;
  followers: number;
  seasonPoints: number;
  peakOverall: number;
  highlights: MatchResult[];
  pendingRaise: number | null;
  pendingBrand: Sponsorship | null;
  sacked: boolean;
  coach: CoachState | null;
  historyRank: HistoryRank | null;
  lifeVerdict: string | null;
};

export type Screen =
  | "landing"
  | "create"
  | "hub"
  | "match"
  | "agent"
  | "training"
  | "career"
  | "offers"
  | "season-recap"
  | "fast-recap"
  | "retired"
  | "coach";

export type TrainFocus = AttrKey | "rest" | "extra";

export type CreatePayload = {
  name: string;
  nationId: string;
  position: Position;
  shirtNumber: number;
  clubId: string;
  mode: GameMode;
  player: Player;
};

export type AgentIntent = "raise" | "transfer" | "sponsor" | "loan" | "offers" | "number" | "resign" | "position";

export type Legend = {
  id: string;
  name: string;
  positions: Position[];
  signature: Partial<Attributes>;
  blurb: string;
  nation: string;
  era: string;
  number: number;
  colors: [string, string];
  iconic: boolean;
};
