import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  acceptBrand,
  acceptOffer,
  acceptRaise,
  agentReply,
  cloneState,
  createCareer,
  rejectBrand,
  rejectRaise,
  rollPlayer,
  simulateCoachCareer,
  simulateSeason,
  simulateSeasonsTracked,
  spendPoint,
  retireNow,
  tryChangePosition,
} from "@/lib/career/engine";
import type {
  AgentIntent,
  AgentMessage,
  AttrKey,
  CreatePayload,
  FastRecap,
  GameState,
  Position,
  Screen,
  SeasonRecap,
  TransferOffer,
} from "@/lib/career/types";
import { SAVE_VERSION } from "@/lib/career/types";

type CareerStore = {
  game: GameState | null;
  screen: Screen;
  recap: SeasonRecap | null;
  fastRecap: FastRecap | null;
  agentLog: AgentMessage[];
  toast: string | null;
  createCareer: (payload: CreatePayload) => void;
  setScreen: (screen: Screen) => void;
  simulateSeason: () => void;
  simulateCareer: () => void;
  spend: (attr: AttrKey) => void;
  accept: (offer: TransferOffer) => void;
  rejectAll: () => void;
  yesRaise: () => void;
  noRaise: () => void;
  yesBrand: () => void;
  noBrand: () => void;
  talkAgent: (intent: AgentIntent) => void;
  setNumber: (n: number) => void;
  requestPosition: (p: Position) => void;
  becomeCoach: () => void;
  hangBoots: () => void;
  newGame: () => void;
  clearToast: () => void;
};

const YOU_TEXT: Record<Exclude<AgentIntent, "offers" | "position">, string> = {
  raise: "Quero aumento.",
  transfer: "Me coloca no mercado. Eu so aceito ou recuso clube.",
  sponsor: "Busca uma marca. Publi e seguidor.",
  loan: "Se eu nao jogo, me empresta.",
  number: "Quero trocar o numero da camisa.",
  resign: "Quero a rescisao. Pago a multa se precisar.",
};

export const useCareer = create<CareerStore>()(
  persist(
    (set, get) => ({
      game: null,
      screen: "landing",
      recap: null,
      fastRecap: null,
      agentLog: [],
      toast: null,

      createCareer: (payload) => {
        const game = createCareer(payload);
        set({
          game,
          screen: "hub",
          recap: null,
          fastRecap: null,
          agentLog: [
            {
              id: "hello",
              from: "agent",
              text: `Fala, ${payload.name.split(" ")[0]}. Eu fecho contrato. Voce so diz sim ou nao.`,
            },
          ],
          toast: "Base sorteada. Cartinha bronze. Agora e trabalho.",
        });
      },

      setScreen: (screen) => set({ screen }),

      playNextMatch: () => {
        const game = get().game;
        if (!game || game.retired) return;
        const next = cloneState(game);
        const { match, recap } = playWeek(next, null);
        if (recap) {
          set({ game: next, recap, screen: next.retired ? "retired" : "season-recap" });
        } else if (match) {
          set({ game: next, screen: "match" });
        } else {
          set({ game: next, screen: "hub", toast: next.injury ? `Fora por ${next.injury.weeksLeft} semana(s).` : "Semana avançada." });
        }
      },

      simulateSeason: () => {
        const game = get().game;
        if (!game || game.retired) return;
        const next = cloneState(game);
        const recap = simulateSeason(next);
        if (next.retired) {
          set({ game: next, screen: "retired", recap, toast: next.retireReason });
          return;
        }
        if (recap) {
          set({ game: next, recap, screen: "season-recap" });
          return;
        }
        set({ game: next, screen: "hub" });
      },

      simulateCareer: () => {
        const game = get().game;
        if (!game || game.retired) return;
        const next = cloneState(game);
        const years = Math.max(1, 38 - next.player.age);
        const fastRecap = simulateSeasonsTracked(next, years);
        set({
          game: next,
          fastRecap,
          screen: next.retired ? "retired" : "fast-recap",
        });
      },

      spend: (attr) => {
        const game = get().game;
        if (!game) return;
        const next = cloneState(game);
        if (!spendPoint(next, attr)) return;
        set({ game: next });
      },

      accept: (offer) => {
        const game = get().game;
        if (!game) return;
        const next = cloneState(game);
        acceptOffer(next, offer);
        set({ game: next, screen: "hub", toast: next.news[0]?.text ?? "Transferencia fechada." });
      },

      rejectAll: () => {
        const game = get().game;
        if (!game) return;
        const next = cloneState(game);
        next.offers = [];
        set({ game: next, screen: "hub", toast: "Propostas recusadas." });
      },

      yesRaise: () => {
        const game = get().game;
        if (!game) return;
        const next = cloneState(game);
        acceptRaise(next);
        set({ game: next, toast: "Aumento aceito." });
      },

      noRaise: () => {
        const game = get().game;
        if (!game) return;
        const next = cloneState(game);
        rejectRaise(next);
        set({ game: next });
      },

      yesBrand: () => {
        const game = get().game;
        if (!game) return;
        const next = cloneState(game);
        acceptBrand(next);
        set({ game: next, toast: "Publi fechada." });
      },

      noBrand: () => {
        const game = get().game;
        if (!game) return;
        const next = cloneState(game);
        rejectBrand(next);
        set({ game: next });
      },

      talkAgent: (intent) => {
        const game = get().game;
        if (!game) return;
        if (intent === "offers") {
          set({ screen: "offers" });
          return;
        }
        if (intent === "position") return;
        const next = cloneState(game);
        const reply = agentReply(next, intent);
        const log = [
          ...get().agentLog,
          { id: `y-${next.rngCount}`, from: "you" as const, text: YOU_TEXT[intent] },
          { id: `a-${next.rngCount}`, from: "agent" as const, text: reply },
        ].slice(-16);
        const screen: Screen =
          intent === "transfer" || intent === "loan" || intent === "resign"
            ? next.offers.length
              ? "offers"
              : "agent"
            : "agent";
        set({ game: next, agentLog: log, screen, toast: next.news[0]?.text });
      },

      setNumber: (n: number) => {
        const game = get().game;
        if (!game) return;
        const next = cloneState(game);
        next.player.shirtNumber = Math.max(1, Math.min(99, Math.round(n)));
        set({ game: next, toast: `Camisa ${next.player.shirtNumber}.` });
      },

      requestPosition: (p: Position) => {
        const game = get().game;
        if (!game) return;
        const next = cloneState(game);
        const reply = tryChangePosition(next, p);
        const log = [
          ...get().agentLog,
          { id: `y-${next.rngCount}`, from: "you" as const, text: `Quero jogar de ${p}.` },
          { id: `a-${next.rngCount}`, from: "agent" as const, text: reply },
        ].slice(-16);
        set({ game: next, agentLog: log, toast: reply });
      },

      becomeCoach: () => {
        const game = get().game;
        if (!game) return;
        const next = cloneState(game);
        if (!next.retired) retireNow(next);
        simulateCoachCareer(next);
        set({ game: next, screen: "coach" });
      },

      hangBoots: () => {
        const game = get().game;
        if (!game) return;
        const next = cloneState(game);
        retireNow(next);
        set({ game: next, screen: "retired" });
      },

      newGame: () =>
        set({
          game: null,
          screen: "create",
          recap: null,
          fastRecap: null,
          agentLog: [],
          toast: null,
        }),

      clearToast: () => set({ toast: null }),
    }),
    {
      name: "lenda-career-v3",
      version: SAVE_VERSION,
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({ game: s.game, screen: s.screen, agentLog: s.agentLog }),
      skipHydration: true,
    },
  ),
);

export { rollPlayer };
